# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dispatcher.spec.ts >> the Dispatcher wakes a connected agent with a message and sleeps it again
- Location: e2e\dispatcher.spec.ts:383:5

# Error details

```
Error: expect(received).toBeTruthy()

Received: undefined
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e8]:
    - navigation "Main toolbar" [ref=e9]:
      - toolbar [ref=e10]:
        - generic "Select an element in the page to inspect it" [ref=e11]:
          - button "Select an element in the page to inspect it - Ctrl + Shift + C" [ref=e12]
      - generic:
        - tablist "Panels":
          - tab "Elements" [selected] [ref=e15]
          - tab "Console" [ref=e17]
          - tab "Sources" [ref=e19]
          - tab "Network" [ref=e21]
          - tab "Performance" [ref=e23]
          - tab "Memory" [ref=e25]
          - tab "Application" [ref=e27]
          - tab "Security" [ref=e29]
        - button "More tabs" [ref=e32]
      - toolbar [ref=e34]:
        - generic:
          - generic "Open Console to view 4 warnings" [ref=e37]:
            - button "Open Console to view 4 warnings" [ref=e38]:
              - generic [ref=e40]: "4"
          - generic "Settings" [ref=e42]:
            - button "Settings - F1 - Shift + ?" [ref=e43]
          - button "Customize and control DevTools" [ref=e45]:
            - button "Customize and control DevTools" [ref=e46]
    - tabpanel "Elements panel" [ref=e49]:
      - generic "elements" [ref=e50]:
        - generic [ref=e52]:
          - generic [ref=e55]:
            - generic:
              - main "DOM tree explorer" [ref=e57]:
                - tree "Page DOM" [ref=e62]:
                  - treeitem "<!DOCTYPE html>" [ref=e63]
                  - treeitem [expanded] [ref=e70]:
                    - generic [ref=e73]:
                      - generic [ref=e75]:
                        - text: <
                        - generic [ref=e76]: html
                        - generic [ref=e77]:
                          - generic [ref=e78]: class
                          - text: ="
                          - generic [ref=e79]: h-full
                          - text: "\""
                        - generic [ref=e80]:
                          - generic [ref=e81]: style
                          - text: ="
                          - generic [ref=e82]: "--ctp-base: 30 30 46; --ctp-mantle: 24 24 37; --ctp-crust: 17 17 27; --ctp-text: 205 214 244; --ctp-subtext0: 166 173 200; --ctp-subtext1: 186 194 222; --ctp-surface0: 49 50 68; --ctp-surface1: 69 71 90; --ctp-surface2: 88 91 112; --ctp-accent: 137 180 250; --ctp-link: 137 180 250; --ctp-warning: 249 226 175; --ctp-error: 243 139 168; --ctp-info: 137 180 250; --ctp-success: 166 227 161; --ctp-accent2: 116 199 236; --ctp-overlay: 127 132 156; --ctp-overlay0: 108 112 134; --ctp-overlay1: 127 132 156; --ctp-on-accent: 17 17 27; --select-chevron: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2012%2012'%3E%3Cpath%20d%3D'M3%204.5%206%207.5%209%204.5'%20fill%3D'none'%20stroke%3D'rgb(127%2C132%2C156)'%20stroke-width%3D'1.5'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3C%2Fsvg%3E\"); --hljs-keyword: #cba6f7; --hljs-string: #a6e3a1; --hljs-number: #fab387; --hljs-comment: #6c7086; --hljs-function: #89b4fa; --hljs-type: #f9e2af; --hljs-variable: #f38ba8; --hljs-regexp: #f5c2e7; --hljs-tag: #89b4fa; --hljs-attribute: #f9e2af; --hljs-symbol: #f38ba8; --hljs-meta: #fab387; --hljs-addition: #a6e3a1; --hljs-deletion: #f38ba8; --hljs-property: #94e2d5; --hljs-punctuation: #9399b2; --shadow-depth: 0 4px 24px rgba(0, 0, 0, 0.5); --shadow-elevation: 0 12px 40px rgba(0, 0, 0, 0.6); --grid-dot-color: rgba(255, 255, 255, 0.1);"
                          - text: "\""
                        - text: ">"
                      - button "View source code" [ref=e85]:
                        - generic [ref=e86]: view-source
                  - group [ref=e88]:
                    - treeitem "<head> Expand …</head>" [ref=e89]:
                      - generic [ref=e93]:
                        - generic "<head>" [ref=e94]:
                          - text: <
                          - generic [ref=e95]: head
                          - text: ">"
                        - button "Expand" [ref=e97]
                        - text: …
                        - generic "</head>" [ref=e99]:
                          - text: <
                          - generic [ref=e100]: /head
                          - text: ">"
                    - treeitem [expanded] [selected] [ref=e102]:
                      - generic [ref=e106]:
                        - generic "<body class=\"h-full m-0 p-0 overflow-hidden\">" [ref=e108]:
                          - text: <
                          - generic [ref=e109]: body
                          - generic [ref=e110]:
                            - generic [ref=e111]: class
                            - text: ="
                            - generic [ref=e112]: h-full m-0 p-0 overflow-hidden
                            - text: "\""
                          - text: ">"
                        - generic [aria-hidden] [ref=e115]: == $0
                    - group [ref=e116]:
                      - treeitem "<div id=\"root\" class=\"h-full\"> Expand …</div>" [ref=e117]:
                        - generic [ref=e121]:
                          - generic "<div id=\"root\" class=\"h-full\">" [ref=e122]:
                            - text: <
                            - generic [ref=e123]: div
                            - generic [ref=e124]:
                              - generic [ref=e125]: id
                              - text: ="
                              - generic [ref=e126]: root
                              - text: "\""
                            - generic [ref=e127]:
                              - generic [ref=e128]: class
                              - text: ="
                              - generic [ref=e129]: h-full
                              - text: "\""
                            - text: ">"
                          - button "Expand" [ref=e131]
                          - text: …
                          - generic "</div>" [ref=e133]:
                            - text: <
                            - generic [ref=e134]: /div
                            - text: ">"
                      - treeitem "</body>" [ref=e136]:
                        - generic "</body>" [ref=e141]:
                          - text: <
                          - generic [ref=e142]: /body
                          - text: ">"
                    - treeitem "</html>" [ref=e144]:
                      - generic "</html>" [ref=e149]:
                        - text: <
                        - generic [ref=e150]: /html
                        - text: ">"
              - navigation "DOM tree breadcrumbs" [ref=e154]:
                - list [ref=e156]:
                  - listitem [ref=e157]:
                    - link "html.h-full" [ref=e158] [cursor=pointer]:
                      - /url: "#"
                      - generic [ref=e159]:
                        - generic [ref=e160]: html
                        - generic [ref=e161]: .h-full
                  - listitem [ref=e162]:
                    - link "body.h-full.m-0.p-0.overflow-hidden" [ref=e163] [cursor=pointer]:
                      - /url: "#"
                      - generic [ref=e164]:
                        - generic [ref=e165]: body
                        - generic [ref=e166]: .h-full.m-0.p-0.overflow-hidden
          - generic [ref=e169]:
            - navigation "Side panel toolbar" [ref=e170]:
              - generic:
                - tablist:
                  - tab "Styles" [selected] [ref=e171]
                  - tab "Computed" [ref=e173]
                  - tab "Layout" [ref=e175]
                  - tab "Event Listeners" [ref=e177]
                - button "More tabs" [ref=e180]
            - complementary "Side panel content" [ref=e182]:
              - tabpanel "Styles panel" [ref=e183]:
                - generic [ref=e188]:
                  - generic [ref=e190]:
                    - toolbar [ref=e191]:
                      - generic [ref=e192]:
                        - generic:
                          - generic [ref=e193]:
                            - textbox "Filter" [ref=e197]
                            - generic "Use regular expression" [ref=e198]:
                              - button "Use regular expression" [ref=e199]
                          - generic "Toggle CSS layers view" [ref=e201]:
                            - button "Toggle CSS layers view" [ref=e202]
                          - generic "Toggle element state" [ref=e204]:
                            - button "Toggle element state" [ref=e205]
                          - generic "Element classes" [ref=e207]:
                            - button "Element classes" [ref=e208]
                          - generic "New style rule" [ref=e210]:
                            - button "New style rule" [ref=e211]
                          - generic "Toggle common rendering emulations" [ref=e214]:
                            - button "Toggle common rendering emulations" [ref=e215]
                          - generic "Show Computed styles sidebar" [ref=e217]:
                            - button "Show Computed styles sidebar" [ref=e218]
                    - list [ref=e220]:
                      - listitem "element.style, css selector" [ref=e221]:
                        - generic [ref=e223]:
                          - generic [ref=e224]: "element.style {"
                          - generic [ref=e226]:
                            - generic:
                              - tree
                          - generic [ref=e227]: "}"
                      - generic [ref=e228]:
                        - generic [ref=e229]: Layer
                        - button "utilities" [ref=e230] [cursor=pointer]
                      - listitem ".p-0, css selector" [ref=e231]:
                        - link "index.css:949" [ref=e233] [cursor=pointer]
                        - generic [ref=e234]:
                          - generic [ref=e236]:
                            - generic "CSS selector" [ref=e237]: .p-0
                            - text: "{"
                          - tree [ref=e240]:
                            - 'treeitem "CSS property name: padding : CSS property value: 0px;" [ref=e241]':
                              - text: padding
                              - generic [ref=e242]: ":"
                              - 'generic "CSS property value: 0px" [ref=e244]': 0px
                              - text: ;
                          - generic [ref=e245]: "}"
                      - generic [ref=e246]:
                        - generic [ref=e247]: Layer
                        - button "utilities" [ref=e248] [cursor=pointer]
                      - listitem ".overflow-hidden, css selector" [ref=e249]:
                        - link "index.css:949" [ref=e251] [cursor=pointer]
                        - generic [ref=e252]:
                          - generic [ref=e254]:
                            - generic "CSS selector" [ref=e255]: .overflow-hidden
                            - text: "{"
                          - tree [ref=e258]:
                            - 'treeitem "CSS property name: overflow : CSS property value: hidden;" [ref=e259]':
                              - text: overflow
                              - generic [ref=e260]: ":"
                              - 'generic "CSS property value: hidden" [ref=e262]': hidden
                              - text: ;
                          - generic [ref=e263]: "}"
                      - generic [ref=e264]:
                        - generic [ref=e265]: Layer
                        - button "utilities" [ref=e266] [cursor=pointer]
                      - listitem ".h-full, css selector" [ref=e267]:
                        - link "index.css:949" [ref=e269] [cursor=pointer]
                        - generic [ref=e270]:
                          - generic [ref=e272]:
                            - generic "CSS selector" [ref=e273]: .h-full
                            - text: "{"
                          - tree [ref=e276]:
                            - 'treeitem "CSS property name: height : CSS property value: 100%;" [ref=e277]':
                              - text: height
                              - generic [ref=e278]: ":"
                              - 'generic "CSS property value: 100%" [ref=e279]': 100%
                              - text: ;
                          - generic [ref=e280]: "}"
                      - generic [ref=e281]:
                        - generic [ref=e282]: Layer
                        - button "utilities" [ref=e283] [cursor=pointer]
                      - listitem ".m-0, css selector" [ref=e284]:
                        - link "index.css:949" [ref=e286] [cursor=pointer]
                        - generic [ref=e287]:
                          - generic [ref=e289]:
                            - generic "CSS selector" [ref=e290]: .m-0
                            - text: "{"
                          - tree [ref=e293]:
                            - 'treeitem "CSS property name: margin : CSS property value: 0px;" [ref=e294]':
                              - text: margin
                              - generic [ref=e295]: ":"
                              - 'generic "CSS property value: 0px" [ref=e297]': 0px
                              - text: ;
                          - generic [ref=e298]: "}"
                      - generic [ref=e299]:
                        - generic [ref=e300]: Layer
                        - button "base" [ref=e301] [cursor=pointer]
                      - listitem "body, css selector" [ref=e302]:
                        - link "index.css:180" [ref=e304] [cursor=pointer]
                        - generic [ref=e305]:
                          - generic [ref=e307]:
                            - generic "CSS selector" [ref=e308]: body
                            - text: "{"
                          - tree [ref=e311]:
                            - 'treeitem "CSS property name: background-color : CSS property value: rgb(var(--ctp-base));" [ref=e312]':
                              - text: background-color
                              - generic [ref=e313]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-base))" [ref=e314]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e316]:
                                  - generic [ref=e317] [cursor=pointer]
                                - generic [ref=e318]:
                                  - generic [ref=e319]: rgb
                                  - text: (
                                  - generic [ref=e321]:
                                    - generic [ref=e322]: var
                                    - text: (
                                    - link "--ctp-base" [ref=e324] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: color : CSS property value: rgb(var(--ctp-text));" [ref=e325]':
                              - text: color
                              - generic [ref=e326]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-text))" [ref=e327]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e329]:
                                  - generic [ref=e330] [cursor=pointer]
                                - generic [ref=e331]:
                                  - generic [ref=e332]: rgb
                                  - text: (
                                  - generic [ref=e334]:
                                    - generic [ref=e335]: var
                                    - text: (
                                    - link "--ctp-text" [ref=e337] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: font-family : CSS property value: -apple-system, BlinkMacSystemFont, ''Segoe UI'', Roboto, sans-serif;" [ref=e338]':
                              - text: font-family
                              - generic [ref=e339]: ":"
                              - 'generic "CSS property value: -apple-system, BlinkMacSystemFont, ''Segoe UI'', Roboto, sans-serif" [ref=e340]': "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-font-smoothing : CSS property value: antialiased;" [ref=e341]':
                              - text: "-webkit-font-smoothing"
                              - generic [ref=e342]: ":"
                              - 'generic "CSS property value: antialiased" [ref=e343]': antialiased
                              - text: ;
                          - generic [ref=e344]: "}"
                      - generic [ref=e345]:
                        - generic [ref=e346]: Layer
                        - button "base" [ref=e347] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e348]:
                        - link "index.css:144" [ref=e350] [cursor=pointer]
                        - generic [ref=e351]:
                          - generic [ref=e353]:
                            - generic "CSS selector" [ref=e354]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e357]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e358]':
                              - text: box-sizing
                              - generic [ref=e359]: ":"
                              - 'generic "CSS property value: border-box" [ref=e360]': border-box
                              - text: ;
                          - generic [ref=e361]: "}"
                      - generic [ref=e362]:
                        - generic [ref=e363]: Layer
                        - button "base" [ref=e364] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e365]:
                        - link "index.css:542" [ref=e367] [cursor=pointer]
                        - generic [ref=e368]:
                          - generic [ref=e370]:
                            - generic "CSS selector" [ref=e371]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e374]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e375]':
                              - text: box-sizing
                              - generic [ref=e376]: ":"
                              - 'generic "CSS property value: border-box" [ref=e377]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e378]':
                              - text: margin
                              - generic [ref=e379]: ":"
                              - 'generic "CSS property value: 0" [ref=e381]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e382]':
                              - text: padding
                              - generic [ref=e383]: ":"
                              - 'generic "CSS property value: 0" [ref=e385]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e386]':
                              - text: border
                              - generic [ref=e387]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e389]': 0 solid
                              - text: ;
                          - generic [ref=e390]: "}"
                      - generic [ref=e391]:
                        - generic [ref=e392]: Layer
                        - generic [ref=e393]: user agent stylesheet
                      - listitem "body, css selector" [ref=e394]:
                        - generic [ref=e395]: user agent stylesheet
                        - generic [ref=e396]:
                          - generic [ref=e398]:
                            - generic "CSS selector" [ref=e399]: body
                            - text: "{"
                          - tree [ref=e402]:
                            - 'treeitem "CSS property name: display : CSS property value: block;" [ref=e403]':
                              - text: display
                              - generic [ref=e404]: ":"
                              - 'generic "CSS property value: block" [ref=e405]': block
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 8px;" [ref=e406]':
                              - text: margin
                              - generic [ref=e407]: ":"
                              - 'generic "CSS property value: 8px" [ref=e409]': 8px
                              - text: ;
                          - generic [ref=e410]: "}"
                      - generic [ref=e411]:
                        - text: Inherited from
                        - button "html.h-full" [ref=e415] [cursor=pointer]:
                          - generic [ref=e416]: html
                          - generic [ref=e417]: .h-full
                      - listitem "style attribute, css selector" [ref=e418]:
                        - generic [ref=e420]:
                          - generic [ref=e421]: "style attribute {"
                          - tree [ref=e425]:
                            - 'treeitem "CSS property name: --ctp-base : CSS property value: 30 30 46;" [ref=e426]':
                              - text: "--ctp-base"
                              - generic [ref=e427]: ":"
                              - 'generic "CSS property value: 30 30 46" [ref=e428]': 30 30 46
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-mantle : CSS property value: 24 24 37;" [ref=e429]':
                              - text: "--ctp-mantle"
                              - generic [ref=e430]: ":"
                              - 'generic "CSS property value: 24 24 37" [ref=e431]': 24 24 37
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-crust : CSS property value: 17 17 27;" [ref=e432]':
                              - text: "--ctp-crust"
                              - generic [ref=e433]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e434]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-text : CSS property value: 205 214 244;" [ref=e435]':
                              - text: "--ctp-text"
                              - generic [ref=e436]: ":"
                              - 'generic "CSS property value: 205 214 244" [ref=e437]': 205 214 244
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext0 : CSS property value: 166 173 200;" [ref=e438]':
                              - text: "--ctp-subtext0"
                              - generic [ref=e439]: ":"
                              - 'generic "CSS property value: 166 173 200" [ref=e440]': 166 173 200
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext1 : CSS property value: 186 194 222;" [ref=e441]':
                              - text: "--ctp-subtext1"
                              - generic [ref=e442]: ":"
                              - 'generic "CSS property value: 186 194 222" [ref=e443]': 186 194 222
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface0 : CSS property value: 49 50 68;" [ref=e444]':
                              - text: "--ctp-surface0"
                              - generic [ref=e445]: ":"
                              - 'generic "CSS property value: 49 50 68" [ref=e446]': 49 50 68
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface1 : CSS property value: 69 71 90;" [ref=e447]':
                              - text: "--ctp-surface1"
                              - generic [ref=e448]: ":"
                              - 'generic "CSS property value: 69 71 90" [ref=e449]': 69 71 90
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface2 : CSS property value: 88 91 112;" [ref=e450]':
                              - text: "--ctp-surface2"
                              - generic [ref=e451]: ":"
                              - 'generic "CSS property value: 88 91 112" [ref=e452]': 88 91 112
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent : CSS property value: 137 180 250;" [ref=e453]':
                              - text: "--ctp-accent"
                              - generic [ref=e454]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e455]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-link : CSS property value: 137 180 250;" [ref=e456]':
                              - text: "--ctp-link"
                              - generic [ref=e457]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e458]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-warning : CSS property value: 249 226 175;" [ref=e459]':
                              - text: "--ctp-warning"
                              - generic [ref=e460]: ":"
                              - 'generic "CSS property value: 249 226 175" [ref=e461]': 249 226 175
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-error : CSS property value: 243 139 168;" [ref=e462]':
                              - text: "--ctp-error"
                              - generic [ref=e463]: ":"
                              - 'generic "CSS property value: 243 139 168" [ref=e464]': 243 139 168
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-info : CSS property value: 137 180 250;" [ref=e465]':
                              - text: "--ctp-info"
                              - generic [ref=e466]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e467]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-success : CSS property value: 166 227 161;" [ref=e468]':
                              - text: "--ctp-success"
                              - generic [ref=e469]: ":"
                              - 'generic "CSS property value: 166 227 161" [ref=e470]': 166 227 161
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent2 : CSS property value: 116 199 236;" [ref=e471]':
                              - text: "--ctp-accent2"
                              - generic [ref=e472]: ":"
                              - 'generic "CSS property value: 116 199 236" [ref=e473]': 116 199 236
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay : CSS property value: 127 132 156;" [ref=e474]':
                              - text: "--ctp-overlay"
                              - generic [ref=e475]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e476]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay0 : CSS property value: 108 112 134;" [ref=e477]':
                              - text: "--ctp-overlay0"
                              - generic [ref=e478]: ":"
                              - 'generic "CSS property value: 108 112 134" [ref=e479]': 108 112 134
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay1 : CSS property value: 127 132 156;" [ref=e480]':
                              - text: "--ctp-overlay1"
                              - generic [ref=e481]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e482]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-on-accent : CSS property value: 17 17 27;" [ref=e483]':
                              - text: "--ctp-on-accent"
                              - generic [ref=e484]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e485]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --select-chevron : CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D''http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg''%20viewBox%3D''0%200%2012%2012''%3E%3Cpath%20d%3D''M3%204.5%206%207.5%209%204.5''%20fill%3D''none''%20stroke%3D''rgb(127%2C132%2C156)''%20stroke-width%3D''1.5''%20stroke-linecap%3D''round''%20stroke-linejoin%3D''round''%2F%3E%3C%2Fsvg%3E\");" [ref=e486]':
                              - text: "--select-chevron"
                              - generic [ref=e487]: ":"
                              - 'generic "CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D''http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg''%20viewBox%3D''0%200%2012%2012''%3E%3Cpath%20d%3D''M3%204.5%206%207.5%209%204.5''%20fill%3D''none''%20stroke%3D''rgb(127%2C132%2C156)''%20stroke-width%3D''1.5''%20stroke-linecap%3D''round''%20stroke-linejoin%3D''round''%2F%3E%3C%2Fsvg%3E\")" [ref=e488]':
                                - text: url(
                                - link "data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2012%2012'%3E%3Cpath%20d%3D'M3%204.5%206%207.5%209%204.5'%20fill%3D'none'%20stroke%3D'rgb(127%2C132%2C156)'%20stroke-width%3D'1.5'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3C%2Fsvg%3E" [ref=e489] [cursor=pointer]
                                - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-keyword : CSS property value: #cba6f7;" [ref=e490]':
                              - text: "--hljs-keyword"
                              - generic [ref=e491]: ":"
                              - 'generic "CSS property value: #cba6f7" [ref=e492]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e494]:
                                  - generic [ref=e495] [cursor=pointer]
                                - text: "#cba6f7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-string : CSS property value: #a6e3a1;" [ref=e496]':
                              - text: "--hljs-string"
                              - generic [ref=e497]: ":"
                              - 'generic "CSS property value: #a6e3a1" [ref=e498]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e500]:
                                  - generic [ref=e501] [cursor=pointer]
                                - text: "#a6e3a1"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-number : CSS property value: #fab387;" [ref=e502]':
                              - text: "--hljs-number"
                              - generic [ref=e503]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e504]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e506]:
                                  - generic [ref=e507] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-comment : CSS property value: #6c7086;" [ref=e508]':
                              - text: "--hljs-comment"
                              - generic [ref=e509]: ":"
                              - 'generic "CSS property value: #6c7086" [ref=e510]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e512]:
                                  - generic [ref=e513] [cursor=pointer]
                                - text: "#6c7086"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-function : CSS property value: #89b4fa;" [ref=e514]':
                              - text: "--hljs-function"
                              - generic [ref=e515]: ":"
                              - 'generic "CSS property value: #89b4fa" [ref=e516]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e518]:
                                  - generic [ref=e519] [cursor=pointer]
                                - text: "#89b4fa"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-type : CSS property value: #f9e2af;" [ref=e520]':
                              - text: "--hljs-type"
                              - generic [ref=e521]: ":"
                              - 'generic "CSS property value: #f9e2af" [ref=e522]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e524]:
                                  - generic [ref=e525] [cursor=pointer]
                                - text: "#f9e2af"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-variable : CSS property value: #f38ba8;" [ref=e526]':
                              - text: "--hljs-variable"
                              - generic [ref=e527]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e528]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e530]:
                                  - generic [ref=e531] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-regexp : CSS property value: #f5c2e7;" [ref=e532]':
                              - text: "--hljs-regexp"
                              - generic [ref=e533]: ":"
                              - 'generic "CSS property value: #f5c2e7" [ref=e534]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e536]:
                                  - generic [ref=e537] [cursor=pointer]
                                - text: "#f5c2e7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-tag : CSS property value: #89b4fa;" [ref=e538]':
                              - text: "--hljs-tag"
                              - generic [ref=e539]: ":"
                              - 'generic "CSS property value: #89b4fa" [ref=e540]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e542]:
                                  - generic [ref=e543] [cursor=pointer]
                                - text: "#89b4fa"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-attribute : CSS property value: #f9e2af;" [ref=e544]':
                              - text: "--hljs-attribute"
                              - generic [ref=e545]: ":"
                              - 'generic "CSS property value: #f9e2af" [ref=e546]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e548]:
                                  - generic [ref=e549] [cursor=pointer]
                                - text: "#f9e2af"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-symbol : CSS property value: #f38ba8;" [ref=e550]':
                              - text: "--hljs-symbol"
                              - generic [ref=e551]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e552]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e554]:
                                  - generic [ref=e555] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-meta : CSS property value: #fab387;" [ref=e556]':
                              - text: "--hljs-meta"
                              - generic [ref=e557]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e558]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e560]:
                                  - generic [ref=e561] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-addition : CSS property value: #a6e3a1;" [ref=e562]':
                              - text: "--hljs-addition"
                              - generic [ref=e563]: ":"
                              - 'generic "CSS property value: #a6e3a1" [ref=e564]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e566]:
                                  - generic [ref=e567] [cursor=pointer]
                                - text: "#a6e3a1"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-deletion : CSS property value: #f38ba8;" [ref=e568]':
                              - text: "--hljs-deletion"
                              - generic [ref=e569]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e570]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e572]:
                                  - generic [ref=e573] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-property : CSS property value: #94e2d5;" [ref=e574]':
                              - text: "--hljs-property"
                              - generic [ref=e575]: ":"
                              - 'generic "CSS property value: #94e2d5" [ref=e576]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e578]:
                                  - generic [ref=e579] [cursor=pointer]
                                - text: "#94e2d5"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-punctuation : CSS property value: #9399b2;" [ref=e580]':
                              - text: "--hljs-punctuation"
                              - generic [ref=e581]: ":"
                              - 'generic "CSS property value: #9399b2" [ref=e582]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e584]:
                                  - generic [ref=e585] [cursor=pointer]
                                - text: "#9399b2"
                              - text: ;
                            - 'treeitem "CSS property name: --shadow-depth : CSS property value: 0 4px 24px rgba(0, 0, 0, 0.5);" [ref=e586]':
                              - text: "--shadow-depth"
                              - generic [ref=e587]: ":"
                              - 'generic "CSS property value: 0 4px 24px rgba(0, 0, 0, 0.5)" [ref=e588]':
                                - text: 0 4px 24px
                                - generic "Open color picker. Shift + Click to change color format" [ref=e590]:
                                  - generic [ref=e591] [cursor=pointer]
                                - generic [ref=e592]:
                                  - generic [ref=e593]: rgba
                                  - text: (0, 0, 0, 0.5)
                              - text: ;
                            - 'treeitem "CSS property name: --shadow-elevation : CSS property value: 0 12px 40px rgba(0, 0, 0, 0.6);" [ref=e594]':
                              - text: "--shadow-elevation"
                              - generic [ref=e595]: ":"
                              - 'generic "CSS property value: 0 12px 40px rgba(0, 0, 0, 0.6)" [ref=e596]':
                                - text: 0 12px 40px
                                - generic "Open color picker. Shift + Click to change color format" [ref=e598]:
                                  - generic [ref=e599] [cursor=pointer]
                                - generic [ref=e600]:
                                  - generic [ref=e601]: rgba
                                  - text: (0, 0, 0, 0.6)
                              - text: ;
                            - 'treeitem "CSS property name: --grid-dot-color : CSS property value: rgba(255, 255, 255, 0.1);" [ref=e602]':
                              - text: "--grid-dot-color"
                              - generic [ref=e603]: ":"
                              - 'generic "CSS property value: rgba(255, 255, 255, 0.1)" [ref=e604]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e606]:
                                  - generic [ref=e607] [cursor=pointer]
                                - generic [ref=e608]:
                                  - generic [ref=e609]: rgba
                                  - text: (255, 255, 255, 0.1)
                              - text: ;
                          - generic [ref=e610]: "}"
                      - generic [ref=e611]:
                        - generic [ref=e612]: Layer
                        - button "Click to reveal layer in layer tree" [ref=e613] [cursor=pointer]
                      - listitem ":root, css selector" [ref=e614]:
                        - link "index.css:63" [ref=e616] [cursor=pointer]
                        - generic [ref=e617]:
                          - generic [ref=e619]:
                            - generic "CSS selector" [ref=e620]: :root
                            - text: "{"
                          - tree [ref=e623]:
                            - 'treeitem "CSS property name: --ctp-base : CSS property value: 30 30 46;" [ref=e624]':
                              - text: "--ctp-base"
                              - generic [ref=e625]: ":"
                              - 'generic "CSS property value: 30 30 46" [ref=e626]': 30 30 46
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-mantle : CSS property value: 24 24 37;" [ref=e627]':
                              - text: "--ctp-mantle"
                              - generic [ref=e628]: ":"
                              - 'generic "CSS property value: 24 24 37" [ref=e629]': 24 24 37
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-crust : CSS property value: 17 17 27;" [ref=e630]':
                              - text: "--ctp-crust"
                              - generic [ref=e631]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e632]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-text : CSS property value: 205 214 244;" [ref=e633]':
                              - text: "--ctp-text"
                              - generic [ref=e634]: ":"
                              - 'generic "CSS property value: 205 214 244" [ref=e635]': 205 214 244
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext1 : CSS property value: 186 194 222;" [ref=e636]':
                              - text: "--ctp-subtext1"
                              - generic [ref=e637]: ":"
                              - 'generic "CSS property value: 186 194 222" [ref=e638]': 186 194 222
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext0 : CSS property value: 166 173 200;" [ref=e639]':
                              - text: "--ctp-subtext0"
                              - generic [ref=e640]: ":"
                              - 'generic "CSS property value: 166 173 200" [ref=e641]': 166 173 200
                              - text: ;
                            - 'treeitem "CSS property name: --select-chevron : CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E\");" [ref=e642]':
                              - text: "--select-chevron"
                              - generic [ref=e643]: ":"
                              - 'generic "CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E\")" [ref=e644]':
                                - text: url(
                                - link "data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E" [ref=e645] [cursor=pointer]
                                - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface0 : CSS property value: 49 50 68;" [ref=e646]':
                              - text: "--ctp-surface0"
                              - generic [ref=e647]: ":"
                              - 'generic "CSS property value: 49 50 68" [ref=e648]': 49 50 68
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface1 : CSS property value: 69 71 90;" [ref=e649]':
                              - text: "--ctp-surface1"
                              - generic [ref=e650]: ":"
                              - 'generic "CSS property value: 69 71 90" [ref=e651]': 69 71 90
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface2 : CSS property value: 88 91 112;" [ref=e652]':
                              - text: "--ctp-surface2"
                              - generic [ref=e653]: ":"
                              - 'generic "CSS property value: 88 91 112" [ref=e654]': 88 91 112
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent : CSS property value: 137 180 250;" [ref=e655]':
                              - text: "--ctp-accent"
                              - generic [ref=e656]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e657]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-on-accent : CSS property value: 17 17 27;" [ref=e658]':
                              - text: "--ctp-on-accent"
                              - generic [ref=e659]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e660]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-link : CSS property value: 137 180 250;" [ref=e661]':
                              - text: "--ctp-link"
                              - generic [ref=e662]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e663]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-warning : CSS property value: 249 226 175;" [ref=e664]':
                              - text: "--ctp-warning"
                              - generic [ref=e665]: ":"
                              - 'generic "CSS property value: 249 226 175" [ref=e666]': 249 226 175
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-error : CSS property value: 243 139 168;" [ref=e667]':
                              - text: "--ctp-error"
                              - generic [ref=e668]: ":"
                              - 'generic "CSS property value: 243 139 168" [ref=e669]': 243 139 168
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-info : CSS property value: 137 180 250;" [ref=e670]':
                              - text: "--ctp-info"
                              - generic [ref=e671]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e672]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-success : CSS property value: 166 227 161;" [ref=e673]':
                              - text: "--ctp-success"
                              - generic [ref=e674]: ":"
                              - 'generic "CSS property value: 166 227 161" [ref=e675]': 166 227 161
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay0 : CSS property value: 108 112 134;" [ref=e676]':
                              - text: "--ctp-overlay0"
                              - generic [ref=e677]: ":"
                              - 'generic "CSS property value: 108 112 134" [ref=e678]': 108 112 134
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay1 : CSS property value: 127 132 156;" [ref=e679]':
                              - text: "--ctp-overlay1"
                              - generic [ref=e680]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e681]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-orange : CSS property value: 249 115 22;" [ref=e682]':
                              - text: "--ctp-badge-orange"
                              - generic [ref=e683]: ":"
                              - 'generic "CSS property value: 249 115 22" [ref=e684]': 249 115 22
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-blue : CSS property value: 59 130 246;" [ref=e685]':
                              - text: "--ctp-badge-blue"
                              - generic [ref=e686]: ":"
                              - 'generic "CSS property value: 59 130 246" [ref=e687]': 59 130 246
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-grey : CSS property value: 148 163 184;" [ref=e688]':
                              - text: "--ctp-badge-grey"
                              - generic [ref=e689]: ":"
                              - 'generic "CSS property value: 148 163 184" [ref=e690]': 148 163 184
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-purple : CSS property value: 168 85 247;" [ref=e691]':
                              - text: "--ctp-badge-purple"
                              - generic [ref=e692]: ":"
                              - 'generic "CSS property value: 168 85 247" [ref=e693]': 168 85 247
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-teal : CSS property value: 20 184 166;" [ref=e694]':
                              - text: "--ctp-badge-teal"
                              - generic [ref=e695]: ":"
                              - 'generic "CSS property value: 20 184 166" [ref=e696]': 20 184 166
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-pink : CSS property value: 236 72 153;" [ref=e697]':
                              - text: "--ctp-badge-pink"
                              - generic [ref=e698]: ":"
                              - 'generic "CSS property value: 236 72 153" [ref=e699]': 236 72 153
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-green : CSS property value: 34 197 94;" [ref=e700]':
                              - text: "--ctp-badge-green"
                              - generic [ref=e701]: ":"
                              - 'generic "CSS property value: 34 197 94" [ref=e702]': 34 197 94
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-amber : CSS property value: 251 191 36;" [ref=e703]':
                              - text: "--ctp-badge-amber"
                              - generic [ref=e704]: ":"
                              - 'generic "CSS property value: 251 191 36" [ref=e705]': 251 191 36
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-indigo : CSS property value: 99 102 241;" [ref=e706]':
                              - text: "--ctp-badge-indigo"
                              - generic [ref=e707]: ":"
                              - 'generic "CSS property value: 99 102 241" [ref=e708]': 99 102 241
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-sky : CSS property value: 14 165 233;" [ref=e709]':
                              - text: "--ctp-badge-sky"
                              - generic [ref=e710]: ":"
                              - 'generic "CSS property value: 14 165 233" [ref=e711]': 14 165 233
                              - text: ;
                            - 'treeitem "CSS property name: --brand-claude : CSS property value: 217 119 87;" [ref=e712]':
                              - text: "--brand-claude"
                              - generic [ref=e713]: ":"
                              - 'generic "CSS property value: 217 119 87" [ref=e714]': 217 119 87
                              - text: ;
                            - 'treeitem "CSS property name: --brand-claude-ink : CSS property value: 48 26 19;" [ref=e715]':
                              - text: "--brand-claude-ink"
                              - generic [ref=e716]: ":"
                              - 'generic "CSS property value: 48 26 19" [ref=e717]': 48 26 19
                              - text: ;
                            - 'treeitem "CSS property name: --brand-copilot : CSS property value: 137 87 229;" [ref=e718]':
                              - text: "--brand-copilot"
                              - generic [ref=e719]: ":"
                              - 'generic "CSS property value: 137 87 229" [ref=e720]': 137 87 229
                              - text: ;
                            - 'treeitem "CSS property name: --brand-codex : CSS property value: var(--ctp-text);" [ref=e721]':
                              - text: "--brand-codex"
                              - generic [ref=e722]: ":"
                              - 'generic "CSS property value: var(--ctp-text)" [ref=e723]':
                                - generic [ref=e725]:
                                  - generic [ref=e726]: var
                                  - text: (
                                  - link "--ctp-text" [ref=e728] [cursor=pointer]
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-keyword : CSS property value: rgb(var(--ctp-accent2));" [ref=e729]':
                              - text: "--hljs-keyword"
                              - generic [ref=e730]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent2))" [ref=e731]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e733]:
                                  - generic [ref=e734] [cursor=pointer]
                                - generic [ref=e735]:
                                  - generic [ref=e736]: rgb
                                  - text: (
                                  - generic [ref=e738]:
                                    - generic [ref=e739]: var
                                    - text: (
                                    - link "--ctp-accent2" [ref=e741] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-string : CSS property value: rgb(var(--ctp-success));" [ref=e742]':
                              - text: "--hljs-string"
                              - generic [ref=e743]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-success))" [ref=e744]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e746]:
                                  - generic [ref=e747] [cursor=pointer]
                                - generic [ref=e748]:
                                  - generic [ref=e749]: rgb
                                  - text: (
                                  - generic [ref=e751]:
                                    - generic [ref=e752]: var
                                    - text: (
                                    - link "--ctp-success" [ref=e754] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-number : CSS property value: #fab387;" [ref=e755]':
                              - text: "--hljs-number"
                              - generic [ref=e756]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e757]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e759]:
                                  - generic [ref=e760] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-comment : CSS property value: rgb(var(--ctp-overlay0));" [ref=e761]':
                              - text: "--hljs-comment"
                              - generic [ref=e762]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-overlay0))" [ref=e763]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e765]:
                                  - generic [ref=e766] [cursor=pointer]
                                - generic [ref=e767]:
                                  - generic [ref=e768]: rgb
                                  - text: (
                                  - generic [ref=e770]:
                                    - generic [ref=e771]: var
                                    - text: (
                                    - link "--ctp-overlay0" [ref=e773] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-function : CSS property value: rgb(var(--ctp-accent));" [ref=e774]':
                              - text: "--hljs-function"
                              - generic [ref=e775]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent))" [ref=e776]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e778]:
                                  - generic [ref=e779] [cursor=pointer]
                                - generic [ref=e780]:
                                  - generic [ref=e781]: rgb
                                  - text: (
                                  - generic [ref=e783]:
                                    - generic [ref=e784]: var
                                    - text: (
                                    - link "--ctp-accent" [ref=e786] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-type : CSS property value: rgb(var(--ctp-warning));" [ref=e787]':
                              - text: "--hljs-type"
                              - generic [ref=e788]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-warning))" [ref=e789]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e791]:
                                  - generic [ref=e792] [cursor=pointer]
                                - generic [ref=e793]:
                                  - generic [ref=e794]: rgb
                                  - text: (
                                  - generic [ref=e796]:
                                    - generic [ref=e797]: var
                                    - text: (
                                    - link "--ctp-warning" [ref=e799] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-variable : CSS property value: rgb(var(--ctp-error));" [ref=e800]':
                              - text: "--hljs-variable"
                              - generic [ref=e801]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e802]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e804]:
                                  - generic [ref=e805] [cursor=pointer]
                                - generic [ref=e806]:
                                  - generic [ref=e807]: rgb
                                  - text: (
                                  - generic [ref=e809]:
                                    - generic [ref=e810]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e812] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-regexp : CSS property value: #f5c2e7;" [ref=e813]':
                              - text: "--hljs-regexp"
                              - generic [ref=e814]: ":"
                              - 'generic "CSS property value: #f5c2e7" [ref=e815]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e817]:
                                  - generic [ref=e818] [cursor=pointer]
                                - text: "#f5c2e7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-tag : CSS property value: rgb(var(--ctp-accent));" [ref=e819]':
                              - text: "--hljs-tag"
                              - generic [ref=e820]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent))" [ref=e821]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e823]:
                                  - generic [ref=e824] [cursor=pointer]
                                - generic [ref=e825]:
                                  - generic [ref=e826]: rgb
                                  - text: (
                                  - generic [ref=e828]:
                                    - generic [ref=e829]: var
                                    - text: (
                                    - link "--ctp-accent" [ref=e831] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-attribute : CSS property value: rgb(var(--ctp-warning));" [ref=e832]':
                              - text: "--hljs-attribute"
                              - generic [ref=e833]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-warning))" [ref=e834]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e836]:
                                  - generic [ref=e837] [cursor=pointer]
                                - generic [ref=e838]:
                                  - generic [ref=e839]: rgb
                                  - text: (
                                  - generic [ref=e841]:
                                    - generic [ref=e842]: var
                                    - text: (
                                    - link "--ctp-warning" [ref=e844] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-symbol : CSS property value: rgb(var(--ctp-error));" [ref=e845]':
                              - text: "--hljs-symbol"
                              - generic [ref=e846]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e847]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e849]:
                                  - generic [ref=e850] [cursor=pointer]
                                - generic [ref=e851]:
                                  - generic [ref=e852]: rgb
                                  - text: (
                                  - generic [ref=e854]:
                                    - generic [ref=e855]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e857] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-meta : CSS property value: #fab387;" [ref=e858]':
                              - text: "--hljs-meta"
                              - generic [ref=e859]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e860]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e862]:
                                  - generic [ref=e863] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-addition : CSS property value: rgb(var(--ctp-success));" [ref=e864]':
                              - text: "--hljs-addition"
                              - generic [ref=e865]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-success))" [ref=e866]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e868]:
                                  - generic [ref=e869] [cursor=pointer]
                                - generic [ref=e870]:
                                  - generic [ref=e871]: rgb
                                  - text: (
                                  - generic [ref=e873]:
                                    - generic [ref=e874]: var
                                    - text: (
                                    - link "--ctp-success" [ref=e876] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-deletion : CSS property value: rgb(var(--ctp-error));" [ref=e877]':
                              - text: "--hljs-deletion"
                              - generic [ref=e878]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e879]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e881]:
                                  - generic [ref=e882] [cursor=pointer]
                                - generic [ref=e883]:
                                  - generic [ref=e884]: rgb
                                  - text: (
                                  - generic [ref=e886]:
                                    - generic [ref=e887]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e889] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-property : CSS property value: #94e2d5;" [ref=e890]':
                              - text: "--hljs-property"
                              - generic [ref=e891]: ":"
                              - 'generic "CSS property value: #94e2d5" [ref=e892]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e894]:
                                  - generic [ref=e895] [cursor=pointer]
                                - text: "#94e2d5"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-punctuation : CSS property value: rgb(var(--ctp-overlay1));" [ref=e896]':
                              - text: "--hljs-punctuation"
                              - generic [ref=e897]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-overlay1))" [ref=e898]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e900]:
                                  - generic [ref=e901] [cursor=pointer]
                                - generic [ref=e902]:
                                  - generic [ref=e903]: rgb
                                  - text: (
                                  - generic [ref=e905]:
                                    - generic [ref=e906]: var
                                    - text: (
                                    - link "--ctp-overlay1" [ref=e908] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e909]: "}"
                      - generic [ref=e910]:
                        - generic [ref=e911]: Layer
                        - button "base" [ref=e912] [cursor=pointer]
                      - listitem "html, :host, css selector" [ref=e913]:
                        - link "index.css:563" [ref=e915] [cursor=pointer]
                        - generic [ref=e916]:
                          - generic [ref=e918]:
                            - generic "CSS selector" [ref=e919]: html, :host
                            - text: "{"
                          - tree [ref=e922]:
                            - 'treeitem "CSS property name: line-height : CSS property value: 1.5;" [ref=e923]':
                              - text: line-height
                              - generic [ref=e924]: ":"
                              - 'generic "CSS property value: 1.5" [ref=e925]': "1.5"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-text-size-adjust : CSS property value: 100%;" [ref=e926]':
                              - text: "-webkit-text-size-adjust"
                              - generic [ref=e927]: ":"
                              - 'generic "CSS property value: 100%" [ref=e928]': 100%
                              - text: ;
                            - 'treeitem "CSS property name: tab-size : CSS property value: 4;" [ref=e929]':
                              - text: tab-size
                              - generic [ref=e930]: ":"
                              - 'generic "CSS property value: 4" [ref=e931]': "4"
                              - text: ;
                            - 'treeitem "CSS property name: font-family : CSS property value: var(--default-font-family, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\");" [ref=e932]':
                              - text: font-family
                              - generic [ref=e933]: ":"
                              - 'generic "CSS property value: var(--default-font-family, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\")" [ref=e934]':
                                - generic [ref=e936]:
                                  - generic [ref=e937]: var
                                  - text: (
                                  - link "--default-font-family" [ref=e939] [cursor=pointer]
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: font-feature-settings : CSS property value: var(--default-font-feature-settings, normal);" [ref=e940]':
                              - text: font-feature-settings
                              - generic [ref=e941]: ":"
                              - 'generic "CSS property value: var(--default-font-feature-settings, normal)" [ref=e942]':
                                - generic [ref=e944]:
                                  - generic [ref=e945]: var
                                  - text: (
                                  - link "--default-font-feature-settings" [disabled] [ref=e947] [cursor=pointer]
                                  - text: ", normal)"
                              - text: ;
                            - 'treeitem "CSS property name: font-variation-settings : CSS property value: var(--default-font-variation-settings, normal);" [ref=e948]':
                              - text: font-variation-settings
                              - generic [ref=e949]: ":"
                              - 'generic "CSS property value: var(--default-font-variation-settings, normal)" [ref=e950]':
                                - generic [ref=e952]:
                                  - generic [ref=e953]: var
                                  - text: (
                                  - link "--default-font-variation-settings" [disabled] [ref=e955] [cursor=pointer]
                                  - text: ", normal)"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-tap-highlight-color : CSS property value: transparent;" [ref=e956]':
                              - text: "-webkit-tap-highlight-color"
                              - generic [ref=e957]: ":"
                              - 'generic "CSS property value: transparent" [ref=e958]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e960]:
                                  - generic [ref=e961] [cursor=pointer]
                                - text: transparent
                              - text: ;
                          - generic [ref=e962]: "}"
                      - generic [ref=e963]:
                        - generic [ref=e964]: Layer
                        - button "theme" [ref=e965] [cursor=pointer]
                      - listitem ":root, :host, css selector" [ref=e966]:
                        - link "index.css:4" [ref=e968] [cursor=pointer]
                        - generic [ref=e969]:
                          - generic [ref=e971]:
                            - generic "CSS selector" [ref=e972]: :root, :host
                            - text: "{"
                          - tree [ref=e975]:
                            - 'treeitem "CSS property name: --font-sans : CSS property value: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";" [ref=e976]':
                              - text: "--font-sans"
                              - generic [ref=e977]: ":"
                              - 'generic "CSS property value: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"" [ref=e978]': "-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\""
                              - text: ;
                            - 'treeitem "CSS property name: --font-mono : CSS property value: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;" [ref=e979]':
                              - text: "--font-mono"
                              - generic [ref=e980]: ":"
                              - 'generic "CSS property value: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace" [ref=e981]': ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace
                              - text: ;
                            - 'treeitem "CSS property name: --color-orange-500 : CSS property value: oklch(70.5% 0.213 47.604);" [ref=e982]':
                              - text: "--color-orange-500"
                              - generic [ref=e983]: ":"
                              - 'generic "CSS property value: oklch(70.5% 0.213 47.604)" [ref=e984]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e986]:
                                  - generic [ref=e987] [cursor=pointer]
                                - generic [ref=e988]:
                                  - generic [ref=e989]: oklch
                                  - text: (70.5% 0.213 47.604)
                              - text: ;
                            - 'treeitem "CSS property name: --color-amber-500 : CSS property value: oklch(76.9% 0.188 70.08);" [ref=e990]':
                              - text: "--color-amber-500"
                              - generic [ref=e991]: ":"
                              - 'generic "CSS property value: oklch(76.9% 0.188 70.08)" [ref=e992]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e994]:
                                  - generic [ref=e995] [cursor=pointer]
                                - generic [ref=e996]:
                                  - generic [ref=e997]: oklch
                                  - text: (76.9% 0.188 70.08)
                              - text: ;
                            - 'treeitem "CSS property name: --color-green-500 : CSS property value: oklch(72.3% 0.219 149.579);" [ref=e998]':
                              - text: "--color-green-500"
                              - generic [ref=e999]: ":"
                              - 'generic "CSS property value: oklch(72.3% 0.219 149.579)" [ref=e1000]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1002]:
                                  - generic [ref=e1003] [cursor=pointer]
                                - generic [ref=e1004]:
                                  - generic [ref=e1005]: oklch
                                  - text: (72.3% 0.219 149.579)
                              - text: ;
                            - 'treeitem "CSS property name: --color-emerald-500 : CSS property value: oklch(69.6% 0.17 162.48);" [ref=e1006]':
                              - text: "--color-emerald-500"
                              - generic [ref=e1007]: ":"
                              - 'generic "CSS property value: oklch(69.6% 0.17 162.48)" [ref=e1008]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1010]:
                                  - generic [ref=e1011] [cursor=pointer]
                                - generic [ref=e1012]:
                                  - generic [ref=e1013]: oklch
                                  - text: (69.6% 0.17 162.48)
                              - text: ;
                            - 'treeitem "CSS property name: --color-teal-500 : CSS property value: oklch(70.4% 0.14 182.503);" [ref=e1014]':
                              - text: "--color-teal-500"
                              - generic [ref=e1015]: ":"
                              - 'generic "CSS property value: oklch(70.4% 0.14 182.503)" [ref=e1016]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1018]:
                                  - generic [ref=e1019] [cursor=pointer]
                                - generic [ref=e1020]:
                                  - generic [ref=e1021]: oklch
                                  - text: (70.4% 0.14 182.503)
                              - text: ;
                            - 'treeitem "CSS property name: --color-cyan-500 : CSS property value: oklch(71.5% 0.143 215.221);" [ref=e1022]':
                              - text: "--color-cyan-500"
                              - generic [ref=e1023]: ":"
                              - 'generic "CSS property value: oklch(71.5% 0.143 215.221)" [ref=e1024]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1026]:
                                  - generic [ref=e1027] [cursor=pointer]
                                - generic [ref=e1028]:
                                  - generic [ref=e1029]: oklch
                                  - text: (71.5% 0.143 215.221)
                              - text: ;
                            - 'treeitem "CSS property name: --color-indigo-500 : CSS property value: oklch(58.5% 0.233 277.117);" [ref=e1030]':
                              - text: "--color-indigo-500"
                              - generic [ref=e1031]: ":"
                              - 'generic "CSS property value: oklch(58.5% 0.233 277.117)" [ref=e1032]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1034]:
                                  - generic [ref=e1035] [cursor=pointer]
                                - generic [ref=e1036]:
                                  - generic [ref=e1037]: oklch
                                  - text: (58.5% 0.233 277.117)
                              - text: ;
                            - 'treeitem "CSS property name: --color-violet-500 : CSS property value: oklch(60.6% 0.25 292.717);" [ref=e1038]':
                              - text: "--color-violet-500"
                              - generic [ref=e1039]: ":"
                              - 'generic "CSS property value: oklch(60.6% 0.25 292.717)" [ref=e1040]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1042]:
                                  - generic [ref=e1043] [cursor=pointer]
                                - generic [ref=e1044]:
                                  - generic [ref=e1045]: oklch
                                  - text: (60.6% 0.25 292.717)
                              - text: ;
                            - 'treeitem "CSS property name: --color-purple-400 : CSS property value: oklch(71.4% 0.203 305.504);" [ref=e1046]':
                              - text: "--color-purple-400"
                              - generic [ref=e1047]: ":"
                              - 'generic "CSS property value: oklch(71.4% 0.203 305.504)" [ref=e1048]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1050]:
                                  - generic [ref=e1051] [cursor=pointer]
                                - generic [ref=e1052]:
                                  - generic [ref=e1053]: oklch
                                  - text: (71.4% 0.203 305.504)
                              - text: ;
                            - 'treeitem "CSS property name: --color-purple-500 : CSS property value: oklch(62.7% 0.265 303.9);" [ref=e1054]':
                              - text: "--color-purple-500"
                              - generic [ref=e1055]: ":"
                              - 'generic "CSS property value: oklch(62.7% 0.265 303.9)" [ref=e1056]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1058]:
                                  - generic [ref=e1059] [cursor=pointer]
                                - generic [ref=e1060]:
                                  - generic [ref=e1061]: oklch
                                  - text: (62.7% 0.265 303.9)
                              - text: ;
                            - 'treeitem "CSS property name: --color-rose-500 : CSS property value: oklch(64.5% 0.246 16.439);" [ref=e1062]':
                              - text: "--color-rose-500"
                              - generic [ref=e1063]: ":"
                              - 'generic "CSS property value: oklch(64.5% 0.246 16.439)" [ref=e1064]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1066]:
                                  - generic [ref=e1067] [cursor=pointer]
                                - generic [ref=e1068]:
                                  - generic [ref=e1069]: oklch
                                  - text: (64.5% 0.246 16.439)
                              - text: ;
                            - 'treeitem "CSS property name: --color-gray-300 : CSS property value: oklch(87.2% 0.01 258.338);" [ref=e1070]':
                              - text: "--color-gray-300"
                              - generic [ref=e1071]: ":"
                              - 'generic "CSS property value: oklch(87.2% 0.01 258.338)" [ref=e1072]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1074]:
                                  - generic [ref=e1075] [cursor=pointer]
                                - generic [ref=e1076]:
                                  - generic [ref=e1077]: oklch
                                  - text: (87.2% 0.01 258.338)
                              - text: ;
                            - 'treeitem "CSS property name: --color-gray-500 : CSS property value: oklch(55.1% 0.027 264.364);" [ref=e1078]':
                              - text: "--color-gray-500"
                              - generic [ref=e1079]: ":"
                              - 'generic "CSS property value: oklch(55.1% 0.027 264.364)" [ref=e1080]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1082]:
                                  - generic [ref=e1083] [cursor=pointer]
                                - generic [ref=e1084]:
                                  - generic [ref=e1085]: oklch
                                  - text: (55.1% 0.027 264.364)
                              - text: ;
                            - 'treeitem "CSS property name: --color-black : CSS property value: #000;" [ref=e1086]':
                              - text: "--color-black"
                              - generic [ref=e1087]: ":"
                              - 'generic "CSS property value: #000" [ref=e1088]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1090]:
                                  - generic [ref=e1091] [cursor=pointer]
                                - text: "#000"
                              - text: ;
                            - 'treeitem "CSS property name: --color-white : CSS property value: #fff;" [ref=e1092]':
                              - text: "--color-white"
                              - generic [ref=e1093]: ":"
                              - 'generic "CSS property value: #fff" [ref=e1094]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1096]:
                                  - generic [ref=e1097] [cursor=pointer]
                                - text: "#fff"
                              - text: ;
                            - 'treeitem "CSS property name: --spacing : CSS property value: 0.25rem;" [ref=e1098]':
                              - text: "--spacing"
                              - generic [ref=e1099]: ":"
                              - 'generic "CSS property value: 0.25rem" [ref=e1100]': 0.25rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-xs : CSS property value: 20rem;" [ref=e1101]':
                              - text: "--container-xs"
                              - generic [ref=e1102]: ":"
                              - 'generic "CSS property value: 20rem" [ref=e1103]': 20rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-sm : CSS property value: 24rem;" [ref=e1104]':
                              - text: "--container-sm"
                              - generic [ref=e1105]: ":"
                              - 'generic "CSS property value: 24rem" [ref=e1106]': 24rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-md : CSS property value: 28rem;" [ref=e1107]':
                              - text: "--container-md"
                              - generic [ref=e1108]: ":"
                              - 'generic "CSS property value: 28rem" [ref=e1109]': 28rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-lg : CSS property value: 32rem;" [ref=e1110]':
                              - text: "--container-lg"
                              - generic [ref=e1111]: ":"
                              - 'generic "CSS property value: 32rem" [ref=e1112]': 32rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-2xl : CSS property value: 42rem;" [ref=e1113]':
                              - text: "--container-2xl"
                              - generic [ref=e1114]: ":"
                              - 'generic "CSS property value: 42rem" [ref=e1115]': 42rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-3xl : CSS property value: 48rem;" [ref=e1116]':
                              - text: "--container-3xl"
                              - generic [ref=e1117]: ":"
                              - 'generic "CSS property value: 48rem" [ref=e1118]': 48rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xs : CSS property value: 0.75rem;" [ref=e1119]':
                              - text: "--text-xs"
                              - generic [ref=e1120]: ":"
                              - 'generic "CSS property value: 0.75rem" [ref=e1121]': 0.75rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xs--line-height : CSS property value: calc(1 / 0.75);" [ref=e1122]':
                              - text: "--text-xs--line-height"
                              - generic [ref=e1123]: ":"
                              - 'generic "CSS property value: calc(1 / 0.75)" [ref=e1124]':
                                - generic [ref=e1125]:
                                  - generic [ref=e1126]: calc
                                  - text: (
                                  - generic [ref=e1127]:
                                    - generic [ref=e1128]: "1"
                                    - generic [ref=e1129]: /
                                    - generic [ref=e1130]: "0.75"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-sm : CSS property value: 0.875rem;" [ref=e1131]':
                              - text: "--text-sm"
                              - generic [ref=e1132]: ":"
                              - 'generic "CSS property value: 0.875rem" [ref=e1133]': 0.875rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-sm--line-height : CSS property value: calc(1.25 / 0.875);" [ref=e1134]':
                              - text: "--text-sm--line-height"
                              - generic [ref=e1135]: ":"
                              - 'generic "CSS property value: calc(1.25 / 0.875)" [ref=e1136]':
                                - generic [ref=e1137]:
                                  - generic [ref=e1138]: calc
                                  - text: (
                                  - generic [ref=e1139]:
                                    - generic [ref=e1140]: "1.25"
                                    - generic [ref=e1141]: /
                                    - generic [ref=e1142]: "0.875"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-base : CSS property value: 1rem;" [ref=e1143]':
                              - text: "--text-base"
                              - generic [ref=e1144]: ":"
                              - 'generic "CSS property value: 1rem" [ref=e1145]': 1rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-base--line-height : CSS property value: calc(1.5 / 1);" [ref=e1146]':
                              - text: "--text-base--line-height"
                              - generic [ref=e1147]: ":"
                              - 'generic "CSS property value: calc(1.5 / 1)" [ref=e1148]':
                                - generic [ref=e1149]:
                                  - generic [ref=e1150]: calc
                                  - text: (
                                  - generic [ref=e1151]:
                                    - generic [ref=e1152]: "1.5"
                                    - generic [ref=e1153]: /
                                    - generic [ref=e1154]: "1"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-lg : CSS property value: 1.125rem;" [ref=e1155]':
                              - text: "--text-lg"
                              - generic [ref=e1156]: ":"
                              - 'generic "CSS property value: 1.125rem" [ref=e1157]': 1.125rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-lg--line-height : CSS property value: calc(1.75 / 1.125);" [ref=e1158]':
                              - text: "--text-lg--line-height"
                              - generic [ref=e1159]: ":"
                              - 'generic "CSS property value: calc(1.75 / 1.125)" [ref=e1160]':
                                - generic [ref=e1161]:
                                  - generic [ref=e1162]: calc
                                  - text: (
                                  - generic [ref=e1163]:
                                    - generic [ref=e1164]: "1.75"
                                    - generic [ref=e1165]: /
                                    - generic [ref=e1166]: "1.125"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-xl : CSS property value: 1.25rem;" [ref=e1167]':
                              - text: "--text-xl"
                              - generic [ref=e1168]: ":"
                              - 'generic "CSS property value: 1.25rem" [ref=e1169]': 1.25rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xl--line-height : CSS property value: calc(1.75 / 1.25);" [ref=e1170]':
                              - text: "--text-xl--line-height"
                              - generic [ref=e1171]: ":"
                              - 'generic "CSS property value: calc(1.75 / 1.25)" [ref=e1172]':
                                - generic [ref=e1173]:
                                  - generic [ref=e1174]: calc
                                  - text: (
                                  - generic [ref=e1175]:
                                    - generic [ref=e1176]: "1.75"
                                    - generic [ref=e1177]: /
                                    - generic [ref=e1178]: "1.25"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-2xl : CSS property value: 1.5rem;" [ref=e1179]':
                              - text: "--text-2xl"
                              - generic [ref=e1180]: ":"
                              - 'generic "CSS property value: 1.5rem" [ref=e1181]': 1.5rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-2xl--line-height : CSS property value: calc(2 / 1.5);" [ref=e1182]':
                              - text: "--text-2xl--line-height"
                              - generic [ref=e1183]: ":"
                              - 'generic "CSS property value: calc(2 / 1.5)" [ref=e1184]':
                                - generic [ref=e1185]:
                                  - generic [ref=e1186]: calc
                                  - text: (
                                  - generic [ref=e1187]:
                                    - generic [ref=e1188]: "2"
                                    - generic [ref=e1189]: /
                                    - generic [ref=e1190]: "1.5"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-3xl : CSS property value: 1.875rem;" [ref=e1191]':
                              - text: "--text-3xl"
                              - generic [ref=e1192]: ":"
                              - 'generic "CSS property value: 1.875rem" [ref=e1193]': 1.875rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-3xl--line-height : CSS property value: calc(2.25 / 1.875);" [ref=e1194]':
                              - text: "--text-3xl--line-height"
                              - generic [ref=e1195]: ":"
                              - 'generic "CSS property value: calc(2.25 / 1.875)" [ref=e1196]':
                                - generic [ref=e1197]:
                                  - generic [ref=e1198]: calc
                                  - text: (
                                  - generic [ref=e1199]:
                                    - generic [ref=e1200]: "2.25"
                                    - generic [ref=e1201]: /
                                    - generic [ref=e1202]: "1.875"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-normal : CSS property value: 400;" [ref=e1203]':
                              - text: "--font-weight-normal"
                              - generic [ref=e1204]: ":"
                              - 'generic "CSS property value: 400" [ref=e1205]': "400"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-medium : CSS property value: 500;" [ref=e1206]':
                              - text: "--font-weight-medium"
                              - generic [ref=e1207]: ":"
                              - 'generic "CSS property value: 500" [ref=e1208]': "500"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-semibold : CSS property value: 600;" [ref=e1209]':
                              - text: "--font-weight-semibold"
                              - generic [ref=e1210]: ":"
                              - 'generic "CSS property value: 600" [ref=e1211]': "600"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-bold : CSS property value: 700;" [ref=e1212]':
                              - text: "--font-weight-bold"
                              - generic [ref=e1213]: ":"
                              - 'generic "CSS property value: 700" [ref=e1214]': "700"
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-normal : CSS property value: 0em;" [ref=e1215]':
                              - text: "--tracking-normal"
                              - generic [ref=e1216]: ":"
                              - 'generic "CSS property value: 0em" [ref=e1217]': 0em
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-wider : CSS property value: 0.05em;" [ref=e1218]':
                              - text: "--tracking-wider"
                              - generic [ref=e1219]: ":"
                              - 'generic "CSS property value: 0.05em" [ref=e1220]': 0.05em
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-widest : CSS property value: 0.1em;" [ref=e1221]':
                              - text: "--tracking-widest"
                              - generic [ref=e1222]: ":"
                              - 'generic "CSS property value: 0.1em" [ref=e1223]': 0.1em
                              - text: ;
                            - 'treeitem "CSS property name: --leading-tight : CSS property value: 1.25;" [ref=e1224]':
                              - text: "--leading-tight"
                              - generic [ref=e1225]: ":"
                              - 'generic "CSS property value: 1.25" [ref=e1226]': "1.25"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-snug : CSS property value: 1.375;" [ref=e1227]':
                              - text: "--leading-snug"
                              - generic [ref=e1228]: ":"
                              - 'generic "CSS property value: 1.375" [ref=e1229]': "1.375"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-normal : CSS property value: 1.5;" [ref=e1230]':
                              - text: "--leading-normal"
                              - generic [ref=e1231]: ":"
                              - 'generic "CSS property value: 1.5" [ref=e1232]': "1.5"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-relaxed : CSS property value: 1.625;" [ref=e1233]':
                              - text: "--leading-relaxed"
                              - generic [ref=e1234]: ":"
                              - 'generic "CSS property value: 1.625" [ref=e1235]': "1.625"
                              - text: ;
                            - 'treeitem "CSS property name: --radius-sm : CSS property value: 0.25rem;" [ref=e1236]':
                              - text: "--radius-sm"
                              - generic [ref=e1237]: ":"
                              - 'generic "CSS property value: 0.25rem" [ref=e1238]': 0.25rem
                              - text: ;
                          - button "Show all properties (15 more)" [ref=e1239]
                          - generic [ref=e1240]: "}"
                      - generic [ref=e1241]: Pseudo ::before element
                      - generic [ref=e1242]:
                        - generic [ref=e1243]: Layer
                        - button "base" [ref=e1244] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e1245]:
                        - link "index.css:144" [ref=e1247] [cursor=pointer]
                        - generic [ref=e1248]:
                          - generic [ref=e1250]:
                            - generic "CSS selector" [ref=e1251]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e1254]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1255]':
                              - text: box-sizing
                              - generic [ref=e1256]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1257]': border-box
                              - text: ;
                          - generic [ref=e1258]: "}"
                      - generic [ref=e1259]:
                        - generic [ref=e1260]: Layer
                        - button "base" [ref=e1261] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1262]:
                        - link "index.css:542" [ref=e1264] [cursor=pointer]
                        - generic [ref=e1265]:
                          - generic [ref=e1267]:
                            - generic "CSS selector" [ref=e1268]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1271]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1272]':
                              - text: box-sizing
                              - generic [ref=e1273]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1274]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1275]':
                              - text: margin
                              - generic [ref=e1276]: ":"
                              - 'generic "CSS property value: 0" [ref=e1278]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1279]':
                              - text: padding
                              - generic [ref=e1280]: ":"
                              - 'generic "CSS property value: 0" [ref=e1282]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1283]':
                              - text: border
                              - generic [ref=e1284]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1286]': 0 solid
                              - text: ;
                          - generic [ref=e1287]: "}"
                      - generic [ref=e1288]: Pseudo ::after element
                      - generic [ref=e1289]:
                        - generic [ref=e1290]: Layer
                        - button "base" [ref=e1291] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e1292]:
                        - link "index.css:144" [ref=e1294] [cursor=pointer]
                        - generic [ref=e1295]:
                          - generic [ref=e1297]:
                            - generic "CSS selector" [ref=e1298]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e1301]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1302]':
                              - text: box-sizing
                              - generic [ref=e1303]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1304]': border-box
                              - text: ;
                          - generic [ref=e1305]: "}"
                      - generic [ref=e1306]:
                        - generic [ref=e1307]: Layer
                        - button "base" [ref=e1308] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1309]:
                        - link "index.css:542" [ref=e1311] [cursor=pointer]
                        - generic [ref=e1312]:
                          - generic [ref=e1314]:
                            - generic "CSS selector" [ref=e1315]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1318]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1319]':
                              - text: box-sizing
                              - generic [ref=e1320]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1321]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1322]':
                              - text: margin
                              - generic [ref=e1323]: ":"
                              - 'generic "CSS property value: 0" [ref=e1325]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1326]':
                              - text: padding
                              - generic [ref=e1327]: ":"
                              - 'generic "CSS property value: 0" [ref=e1329]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1330]':
                              - text: border
                              - generic [ref=e1331]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1333]': 0 solid
                              - text: ;
                          - generic [ref=e1334]: "}"
                      - generic [ref=e1335]: Pseudo ::backdrop element
                      - generic [ref=e1336]:
                        - generic [ref=e1337]: Layer
                        - button "base" [ref=e1338] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1339]:
                        - link "index.css:542" [ref=e1341] [cursor=pointer]
                        - generic [ref=e1342]:
                          - generic [ref=e1344]:
                            - generic "CSS selector" [ref=e1345]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1348]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1349]':
                              - text: box-sizing
                              - generic [ref=e1350]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1351]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1352]':
                              - text: margin
                              - generic [ref=e1353]: ":"
                              - 'generic "CSS property value: 0" [ref=e1355]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1356]':
                              - text: padding
                              - generic [ref=e1357]: ":"
                              - 'generic "CSS property value: 0" [ref=e1359]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1360]':
                              - text: border
                              - generic [ref=e1361]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1363]': 0 solid
                              - text: ;
                          - generic [ref=e1364]: "}"
                      - generic [ref=e1365]: Pseudo ::scrollbar element
                      - generic [ref=e1366]:
                        - generic [ref=e1367]: Layer
                        - button "base" [ref=e1368] [cursor=pointer]
                      - listitem "::-webkit-scrollbar, css selector" [ref=e1369]:
                        - link "index.css:231" [ref=e1371] [cursor=pointer]
                        - generic [ref=e1372]:
                          - generic [ref=e1374]:
                            - generic "CSS selector" [ref=e1375]: ::-webkit-scrollbar
                            - text: "{"
                          - tree [ref=e1378]:
                            - 'treeitem "CSS property name: width : CSS property value: 6px;" [ref=e1379]':
                              - text: width
                              - generic [ref=e1380]: ":"
                              - 'generic "CSS property value: 6px" [ref=e1381]': 6px
                              - text: ;
                            - 'treeitem "CSS property name: height : CSS property value: 6px;" [ref=e1382]':
                              - text: height
                              - generic [ref=e1383]: ":"
                              - 'generic "CSS property value: 6px" [ref=e1384]': 6px
                              - text: ;
                          - generic [ref=e1385]: "}"
                      - generic [ref=e1386]: Pseudo ::scrollbar-thumb element
                      - generic [ref=e1387]:
                        - generic [ref=e1388]: Layer
                        - button "base" [ref=e1389] [cursor=pointer]
                      - listitem ":hover::-webkit-scrollbar-thumb:hover, css selector" [ref=e1390]:
                        - link "index.css:250" [ref=e1392] [cursor=pointer]
                        - generic [ref=e1393]:
                          - generic [ref=e1395]:
                            - generic "CSS selector" [ref=e1396]: :hover::-webkit-scrollbar-thumb:hover
                            - text: "{"
                          - tree [ref=e1399]:
                            - 'treeitem "CSS property name: background : CSS property value: rgb(var(--ctp-surface2));" [ref=e1400]':
                              - text: background
                              - generic [ref=e1401]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-surface2))" [ref=e1403]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1405]:
                                  - generic [ref=e1406] [cursor=pointer]
                                - generic [ref=e1407]:
                                  - generic [ref=e1408]: rgb
                                  - text: (
                                  - generic [ref=e1410]:
                                    - generic [ref=e1411]: var
                                    - text: (
                                    - link "--ctp-surface2" [ref=e1413] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e1414]: "}"
                      - generic [ref=e1415]:
                        - generic [ref=e1416]: Layer
                        - button "base" [ref=e1417] [cursor=pointer]
                      - listitem ":hover::-webkit-scrollbar-thumb, css selector" [ref=e1418]:
                        - link "index.css:246" [ref=e1420] [cursor=pointer]
                        - generic [ref=e1421]:
                          - generic [ref=e1423]:
                            - generic "CSS selector" [ref=e1424]: :hover::-webkit-scrollbar-thumb
                            - text: "{"
                          - tree [ref=e1427]:
                            - 'treeitem "CSS property name: background : CSS property value: rgb(var(--ctp-surface1));" [ref=e1428]':
                              - text: background
                              - generic [ref=e1429]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-surface1))" [ref=e1431]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1433]:
                                  - generic [ref=e1434] [cursor=pointer]
                                - generic [ref=e1435]:
                                  - generic [ref=e1436]: rgb
                                  - text: (
                                  - generic [ref=e1438]:
                                    - generic [ref=e1439]: var
                                    - text: (
                                    - link "--ctp-surface1" [ref=e1441] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e1442]: "}"
                      - generic [ref=e1443]:
                        - generic [ref=e1444]: Layer
                        - button "base" [ref=e1445] [cursor=pointer]
                      - listitem "::-webkit-scrollbar-thumb, css selector" [ref=e1446]:
                        - link "index.css:240" [ref=e1448] [cursor=pointer]
                        - generic [ref=e1449]:
                          - generic [ref=e1451]:
                            - generic "CSS selector" [ref=e1452]: ::-webkit-scrollbar-thumb
                            - text: "{"
                          - tree [ref=e1455]:
                            - 'treeitem "CSS property name: background : CSS property value: transparent;" [ref=e1456]':
                              - text: background
                              - generic [ref=e1457]: ":"
                              - 'generic "CSS property value: transparent" [ref=e1459]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1461]:
                                  - generic [ref=e1462] [cursor=pointer]
                                - text: transparent
                              - text: ;
                            - 'treeitem "CSS property name: border-radius : CSS property value: 3px;" [ref=e1463]':
                              - text: border-radius
                              - generic [ref=e1464]: ":"
                              - 'generic "CSS property value: 3px" [ref=e1466]': 3px
                              - text: ;
                            - 'treeitem "CSS property name: transition : CSS property value: background 0.2s ease;" [ref=e1467]':
                              - text: transition
                              - generic [ref=e1468]: ":"
                              - 'generic "CSS property value: background 0.2s ease" [ref=e1470]':
                                - text: background 0.2s
                                - generic [ref=e1471]:
                                  - generic "Open cubic bezier editor" [ref=e1472]
                                  - text: ease
                              - text: ;
                          - generic [ref=e1474]: "}"
                      - generic [ref=e1475]: Pseudo ::scrollbar-track element
                      - generic [ref=e1476]:
                        - generic [ref=e1477]: Layer
                        - button "base" [ref=e1478] [cursor=pointer]
                      - listitem "::-webkit-scrollbar-track, css selector" [ref=e1479]:
                        - link "index.css:236" [ref=e1481] [cursor=pointer]
                        - generic [ref=e1482]:
                          - generic [ref=e1484]:
                            - generic "CSS selector" [ref=e1485]: ::-webkit-scrollbar-track
                            - text: "{"
                          - tree [ref=e1488]:
                            - 'treeitem "CSS property name: background : CSS property value: transparent;" [ref=e1489]':
                              - text: background
                              - generic [ref=e1490]: ":"
                              - 'generic "CSS property value: transparent" [ref=e1492]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1494]:
                                  - generic [ref=e1495] [cursor=pointer]
                                - text: transparent
                              - text: ;
                          - generic [ref=e1496]: "}"
                      - generic [ref=e1497]: "@property"
                  - generic [ref=e1501]:
                    - generic [ref=e1502]: margin
                    - generic [ref=e1503]: "0"
                    - generic [ref=e1504]: "0"
                    - generic [ref=e1505]:
                      - generic [ref=e1506]: border
                      - generic [ref=e1507]: "0"
                      - generic [ref=e1508]: "0"
                      - generic [ref=e1509]:
                        - generic [ref=e1510]: padding
                        - generic [ref=e1511]: "0"
                        - generic [ref=e1512]: "0"
                        - generic [ref=e1513]:
                          - generic [ref=e1514]: "1024"
                          - generic [ref=e1515]: ×
                          - generic [ref=e1516]: "728"
                        - generic [ref=e1517]: "0"
                        - generic [ref=e1518]: "0"
                      - generic [ref=e1519]: "0"
                      - generic [ref=e1520]: "0"
                    - generic [ref=e1521]: "0"
                    - generic [ref=e1522]: "0"
  - alert [ref=e1524]: DevTools is undocked
  - status
```

# Test source

```ts
  308 |   const connect = w.locator('[data-testid="dispatcher-card-switch"]');
  309 |   await expect(connect).toBeVisible();
  310 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  311 |   await connect.click();
  312 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(false);
  313 |   await connect.click();
  314 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  315 | 
  316 |   // The wire comes back after a restart.
  317 |   await app!.electronApp.close();
  318 |   w = (await launch()).window;
  319 |   await expect(row(w)).toBeVisible({ timeout: 15_000 });
  320 |   await expect.poll(() => hasWire(w, dispatcherId), { timeout: 15_000 }).toBe(true);
  321 | 
  322 |   // Turning the setting off drops the row and wires and keeps the folder and its memory.
  323 |   fs.writeFileSync(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'kept\n');
  324 |   // An old notes/ folder, as the agent kept before memory (#3038).
  325 |   fs.mkdirSync(path.join(dispatcherDir(), 'notes'), { recursive: true });
  326 |   fs.writeFileSync(path.join(dispatcherDir(), 'notes', 'release.md'), 'old note\n');
  327 |   await openSettingsPage(w, 'Dispatcher');
  328 |   await w.locator('[data-testid="dispatcher-enabled"]').click();
  329 |   await expect(row(w)).toHaveCount(0);
  330 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(false);
  331 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'utf8')).toBe('kept\n');
  332 |   await w.locator('[data-testid="dispatcher-enabled"]').click();
  333 |   await expect(row(w)).toBeVisible();
  334 |   // Turning it on sorts the old notes into memory once and keeps the folder, renamed.
  335 |   await expect.poll(() => fs.existsSync(path.join(dispatcherDir(), 'notes'))).toBe(false);
  336 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'notes-archive', 'release.md'), 'utf8')).toBe('old note\n');
  337 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'release.md'), 'utf8')).toMatch(/old note\n$/);
  338 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'utf8')).toBe('kept\n');
  339 |   expect(await dispatcherIds()).toEqual([dispatcherId]);
  340 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  341 | 
  342 |   // Start it from its view.
  343 |   await closeSettings(w);
  344 |   await rowItem(w).click();
  345 |   await w.locator('[data-testid="dispatcher-view"] [data-testid="wake-button"]').click();
  346 |   await expect.poll(startedAs, { timeout: 20_000 }).toBe((await chatConfigs())[0].id);
  347 |   // Waking it from its view keeps the view, with its chat, and no project in the title (#2563).
  348 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible({ timeout: 15_000 });
  349 |   await expect(w.locator('[data-testid="title-bar"]')).toContainText('Dispatcher');
  350 |   await expect(w.locator('[data-testid="title-bar"]')).not.toContainText('dispatcher-e2e-');
  351 | 
  352 |   // Its composer has one Behavior chip in place of the model and permission pickers (#3045).
  353 |   const view = w.locator('[data-testid="dispatcher-view"]');
  354 |   const chip = view.locator('[data-testid="dispatcher-behavior-chip"]');
  355 |   await expect(chip).toHaveAttribute('data-level', 'standard', { timeout: 15_000 });
  356 |   await expect(view.locator('[data-testid="chat-model-pill"]')).toHaveCount(0);
  357 |   await expect(view.locator('[data-testid="chat-level-pill"]')).toHaveCount(0);
  358 |   // Thorough keeps the chat on the same tier as Standard, so the running chat
  359 |   // isn't switched: this fixture replays a strict script with no model change here.
  360 |   await chip.click();
  361 |   await view.locator('[data-testid="dispatcher-behavior-thorough"]').click();
  362 |   await expect(chip).toHaveAttribute('data-level', 'thorough');
  363 |   await expect(view.locator('[data-testid="dispatcher-behavior-menu"]')).toHaveCount(0);
  364 |   // Settings shows the same choice.
  365 |   await openSettingsPage(w, 'Dispatcher');
  366 |   await expect(w.locator('[data-testid="dispatcher-behavior"]')).toHaveValue('thorough');
  367 | 
  368 |   // Clear chat (#3043) from its menu asks first, starts the conversation over and leaves memory alone.
  369 |   await closeSettings(w);
  370 |   await rowItem(w).click();
  371 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible({ timeout: 15_000 });
  372 |   const memoryFiles = ['index.md', 'topics/plan.md', 'topics/release.md'].map((f) => path.join(dispatcherDir(), 'memory', f));
  373 |   const memoryBefore = await Promise.all(memoryFiles.map((f) => fs.promises.readFile(f, 'utf8')));
  374 |   await rowItem(w).click({ button: 'right' });
  375 |   await w.locator('[data-testid="agent-context-menu"] [data-testid="ctx-clear-chat"]').click();
  376 |   await expect(w.locator('[data-testid="dispatcher-clear-chat-confirm"]')).toBeVisible();
  377 |   await w.locator('[data-testid="dispatcher-clear-chat-confirm-button"]').click();
  378 |   await expect(w.locator('[data-testid="dispatcher-clear-chat-confirm"]')).toHaveCount(0, { timeout: 15_000 });
  379 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible();
  380 |   expect(await Promise.all(memoryFiles.map((f) => fs.promises.readFile(f, 'utf8')))).toEqual(memoryBefore);
  381 | });
  382 | 
  383 | test('the Dispatcher wakes a connected agent with a message and sleeps it again', async () => {
  384 |   projectDir = makeProject();
  385 |   const fixtureDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dispatcher-e2e-fixture-'));
  386 |   try {
  387 |     fakes = await installFakeClis({ claude: await writeQuietFixture(fixtureDir) });
  388 |     profile = createDisposableProfile({ label: 'dispatcher-wake' });
  389 |     const w = (await launch()).window;
  390 | 
  391 |     await expect(row(w)).toBeVisible({ timeout: 15_000 });
  392 |     await expect.poll(async () => (await dispatcherConfigs()).length).toBe(1);
  393 |     const dispatcherId = (await dispatcherConfigs())[0].id;
  394 | 
  395 |     await addProject(app!.electronApp, w, projectDir);
  396 |     // An orchestrator is connected by default (#2578).
  397 |     await openDispatcherCard(w);
  398 |     await expect(w.locator('[data-testid="dispatcher-card-switch"]')).toHaveAttribute('aria-checked', 'true');
  399 |     await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  400 | 
  401 |     // Start the Dispatcher. The fake reports the bridge credentials it was given.
  402 |     const { mcp } = await startDispatcher(w, dispatcherId);
  403 | 
  404 |     const toolFor = (names: string[], suffix: string) => names.find((n) => n.endsWith(`__${suffix}`) && n.includes('conductor'));
  405 | 
  406 |     // #3656 item 4: a sleeping LOCAL wire lists send_message, but sending never auto-wakes it.
  407 |     const asleep = await mcp.toolNames();
> 408 |     expect(toolFor(asleep, 'get_status')).toBeTruthy();
      |                                           ^ Error: expect(received).toBeTruthy()
  409 |     expect(toolFor(asleep, 'send_message')).toBeTruthy();
  410 |     expect(toolFor(asleep, 'sleep_agent')).toBeUndefined();
  411 |     const sleepingSend = await mcp.callText(toolFor(asleep, 'send_message')!, { message: 'stay asleep until explicitly woken' });
  412 |     expect(sleepingSend.isError).toBe(true);
  413 |     expect(sleepingSend.text).toContain(`Agent ${ORCHESTRATOR_ID} is sleeping.`);
  414 |     expect((await mcp.call(toolFor(asleep, 'get_status')!)).body).toMatchObject({ status: 'sleeping', running: false });
  415 |     expect(await startedAs()).toBe(dispatcherId); // No target CLI was started by send_message.
  416 | 
  417 |     // Wake with a message, which reaches the CLI as the first prompt.
  418 |     const woken = await mcp.call(toolFor(asleep, 'wake_agent')!, { message: 'first prompt from dispatcher' });
  419 |     expect(woken.isError).toBe(false);
  420 |     expect(woken.body).toMatchObject({ status: 'running', messageDelivered: true });
  421 |     await expect.poll(async () => {
  422 |       const report = await fakes!.report('claude').catch((): undefined => undefined);
  423 |       return report?.env.CLUBHOUSE_AGENT_ID === ORCHESTRATOR_ID && JSON.stringify(report.unexpected).includes('first prompt from dispatcher');
  424 |     }, { timeout: 20_000 }).toBe(true);
  425 | 
  426 |     // Awake: sleep_agent instead of wake_agent.
  427 |     const awake = await mcp.toolNames();
  428 |     expect(toolFor(awake, 'wake_agent')).toBeUndefined();
  429 |     const sleepTool = toolFor(awake, 'sleep_agent')!;
  430 |     expect(sleepTool).toBeTruthy();
  431 | 
  432 |     // The fake never answers, so it is mid-turn: refused without force.
  433 |     const refused = await mcp.call(sleepTool);
  434 |     expect(refused.isError).toBe(true);
  435 |     expect(refused.body).toMatchObject({ status: 'refused', reason: 'mid_turn' });
  436 |     expect(((await mcp.call(toolFor(awake, 'get_status')!)).body as { running: boolean }).running).toBe(true);
  437 | 
  438 |     const slept = await mcp.call(sleepTool, { force: true });
  439 |     expect((slept.body as { status: string }).status).toBe('sleeping');
  440 |     expect(((await mcp.call(toolFor(awake, 'get_status')!)).body as { running: boolean }).running).toBe(false);
  441 |     expect(toolFor(await mcp.toolNames(), 'wake_agent')).toBeTruthy();
  442 |   } finally {
  443 |     await fs.promises.rm(fixtureDir, { recursive: true, force: true, maxRetries: 20, retryDelay: 100 });
  444 |   }
  445 | });
  446 | 
  447 | test('an Ask-first call waits in Needs you, and goes through once the user allows it (#2970)', async () => {
  448 |   const fixtureDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dispatcher-e2e-fixture-'));
  449 |   try {
  450 |     fakes = await installFakeClis({ claude: await writeQuietFixture(fixtureDir) });
  451 |     profile = createDisposableProfile({ label: 'dispatcher-ask-first' });
  452 |     const w = (await launch()).window;
  453 | 
  454 |     await expect(row(w)).toBeVisible({ timeout: 15_000 });
  455 |     await expect.poll(async () => (await dispatcherConfigs()).length).toBe(1);
  456 |     const dispatcherId = (await dispatcherConfigs())[0].id;
  457 | 
  458 |     const { chatId, mcp } = await startDispatcher(w, dispatcherId);
  459 | 
  460 |     // Changing app settings is Ask first for the Dispatcher: the tool is offered, and the call asks.
  461 |     expect(await mcp.toolNames()).toContain('set_helper_presets');
  462 |     const { revision } = (await mcp.call('read_helper_presets')).body as { revision: number };
  463 |     const args = { revision, reset: {} };
  464 |     const asked = await mcp.callText('set_helper_presets', args);
  465 |     expect(asked.isError).toBe(true);
  466 |     expect(asked.text).toContain('needs the user\'s approval');
  467 | 
  468 |     // It waits in Needs you, on the Dispatcher's own row; selecting it opens the request, and the user allows it.
  469 |     await expect(w.locator(`[data-testid="needs-you-row-${dispatcherId}"]`)).toHaveCount(0);
  470 |     const needsRow = w.locator(`[data-testid="needs-you-row-${chatId}"]`);
  471 |     await expect(needsRow).toBeVisible({ timeout: 10_000 });
  472 |     await expect(needsRow).toContainText('Change app settings');
  473 |     await needsRow.click();
  474 |     const dialog = w.locator('[data-testid="grant-request-dialog"]');
  475 |     await expect(dialog).toContainText('set_helper_presets');
  476 |     await dialog.locator('[data-testid="grant-request-allow"]').click();
  477 |     await expect(dialog).toBeHidden();
  478 |     await expect(needsRow).toBeHidden();
  479 | 
  480 |     // The same call now goes through, once.
  481 |     const done = await mcp.call('set_helper_presets', args);
  482 |     expect(done.isError).toBe(false);
  483 |     expect(done.body).toMatchObject({ ok: true });
  484 |     expect((await mcp.callText('set_helper_presets', { revision: (done.body as { revision: number }).revision, reset: {} })).text).toContain('needs the user\'s approval');
  485 |   } finally {
  486 |     await fs.promises.rm(fixtureDir, { recursive: true, force: true, maxRetries: 20, retryDelay: 100 });
  487 |   }
  488 | });
  489 | 
  490 | /**
  491 |  * The popout window the next createPopout opens. Unpackaged builds may open
  492 |  * DevTools first, so a window without the popout's root is skipped.
  493 |  */
  494 | async function nextPopout(electronApp: ElectronApp, open: () => Promise<void>): Promise<Page> {
  495 |   const seen = new Set(electronApp.windows());
  496 |   const first = electronApp.waitForEvent('window', { predicate: (p) => !seen.has(p), timeout: 15_000 });
  497 |   await open();
  498 |   let page = await first;
  499 |   await page.waitForLoadState('load');
  500 |   if (!(await page.locator('[data-testid="popout-window"]').isVisible({ timeout: 5_000 }).catch(() => false))) {
  501 |     seen.add(page);
  502 |     page = await electronApp.waitForEvent('window', { predicate: (p) => !seen.has(p), timeout: 10_000 });
  503 |     await page.waitForLoadState('load');
  504 |   }
  505 |   return page;
  506 | }
  507 | 
  508 | test('Pop Out shows its chat in its own window, where the user keeps talking to it (#3235)', async () => {
```