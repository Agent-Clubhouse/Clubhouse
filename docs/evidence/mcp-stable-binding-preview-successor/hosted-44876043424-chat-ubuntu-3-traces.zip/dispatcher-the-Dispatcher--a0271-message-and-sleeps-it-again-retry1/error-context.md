# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dispatcher.spec.ts >> the Dispatcher wakes a connected agent with a message and sleeps it again
- Location: e2e/dispatcher.spec.ts:383:5

# Error details

```
Error: expect(received).toBeTruthy()

Received: undefined
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e8]:
    - navigation "Main toolbar" [ref=e9]:
      - toolbar [ref=e10]:
        - generic "Select an element in the page to inspect it" [ref=e11]:
          - button "Select an element in the page to inspect it - Ctrl + Shift + C" [ref=e12]
      - generic:
        - tablist "Panels":
          - tab "Elements" [selected] [ref=e15]
          - tab "Console" [ref=e17]
          - tab "Sources" [ref=e19]
          - tab "Network" [ref=e21]
          - tab "Performance" [ref=e23]
          - tab "Memory" [ref=e25]
          - tab "Application" [ref=e27]
          - tab "Security" [ref=e29]
        - button "More tabs" [ref=e32]
      - toolbar [ref=e34]:
        - generic:
          - generic "Open Console to view 4 warnings" [ref=e37]:
            - button "Open Console to view 4 warnings" [ref=e38]:
              - generic [ref=e40]: "4"
          - generic "Settings" [ref=e42]:
            - button "Settings - F1 - Shift + ?" [ref=e43]
          - button "Customize and control DevTools" [ref=e45]:
            - button "Customize and control DevTools" [ref=e46]
    - tabpanel "Elements panel" [ref=e49]:
      - generic "elements" [ref=e50]:
        - generic [ref=e52]:
          - generic [ref=e55]:
            - generic:
              - main "DOM tree explorer" [ref=e57]:
                - tree "Page DOM" [ref=e62]:
                  - treeitem "<!DOCTYPE html>" [ref=e63]
                  - treeitem [expanded] [ref=e70]:
                    - generic [ref=e73]:
                      - generic [ref=e75]:
                        - text: <
                        - generic [ref=e76]: html
                        - generic [ref=e77]:
                          - generic [ref=e78]: class
                          - text: ="
                          - generic [ref=e79]: h-full
                          - text: "\""
                        - generic [ref=e80]:
                          - generic [ref=e81]: style
                          - text: ="
                          - generic [ref=e82]: "--ctp-base: 30 30 46; --ctp-mantle: 24 24 37; --ctp-crust: 17 17 27; --ctp-text: 205 214 244; --ctp-subtext0: 166 173 200; --ctp-subtext1: 186 194 222; --ctp-surface0: 49 50 68; --ctp-surface1: 69 71 90; --ctp-surface2: 88 91 112; --ctp-accent: 137 180 250; --ctp-link: 137 180 250; --ctp-warning: 249 226 175; --ctp-error: 243 139 168; --ctp-info: 137 180 250; --ctp-success: 166 227 161; --ctp-accent2: 116 199 236; --ctp-overlay: 127 132 156; --ctp-overlay0: 108 112 134; --ctp-overlay1: 127 132 156; --ctp-on-accent: 17 17 27; --select-chevron: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2012%2012'%3E%3Cpath%20d%3D'M3%204.5%206%207.5%209%204.5'%20fill%3D'none'%20stroke%3D'rgb(127%2C132%2C156)'%20stroke-width%3D'1.5'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3C%2Fsvg%3E\"); --hljs-keyword: #cba6f7; --hljs-string: #a6e3a1; --hljs-number: #fab387; --hljs-comment: #6c7086; --hljs-function: #89b4fa; --hljs-type: #f9e2af; --hljs-variable: #f38ba8; --hljs-regexp: #f5c2e7; --hljs-tag: #89b4fa; --hljs-attribute: #f9e2af; --hljs-symbol: #f38ba8; --hljs-meta: #fab387; --hljs-addition: #a6e3a1; --hljs-deletion: #f38ba8; --hljs-property: #94e2d5; --hljs-punctuation: #9399b2; --shadow-depth: 0 4px 24px rgba(0, 0, 0, 0.5); --shadow-elevation: 0 12px 40px rgba(0, 0, 0, 0.6); --grid-dot-color: rgba(255, 255, 255, 0.1);"
                          - text: "\""
                        - text: ">"
                      - button "View source code" [ref=e85]:
                        - generic [ref=e86]: view-source
                  - group [ref=e88]:
                    - treeitem "<head> Expand …</head>" [ref=e89]:
                      - generic [ref=e93]:
                        - generic "<head>" [ref=e94]:
                          - text: <
                          - generic [ref=e95]: head
                          - text: ">"
                        - button "Expand" [ref=e97]
                        - text: …
                        - generic "</head>" [ref=e99]:
                          - text: <
                          - generic [ref=e100]: /head
                          - text: ">"
                    - treeitem [expanded] [selected] [ref=e102]:
                      - generic [ref=e106]:
                        - generic "<body class=\"h-full m-0 p-0 overflow-hidden\">" [ref=e108]:
                          - text: <
                          - generic [ref=e109]: body
                          - generic [ref=e110]:
                            - generic [ref=e111]: class
                            - text: ="
                            - generic [ref=e112]: h-full m-0 p-0 overflow-hidden
                            - text: "\""
                          - text: ">"
                        - generic [aria-hidden] [ref=e115]: == $0
                    - group [ref=e116]:
                      - treeitem "<div id=\"root\" class=\"h-full\"> Expand …</div>" [ref=e117]:
                        - generic [ref=e121]:
                          - generic "<div id=\"root\" class=\"h-full\">" [ref=e122]:
                            - text: <
                            - generic [ref=e123]: div
                            - generic [ref=e124]:
                              - generic [ref=e125]: id
                              - text: ="
                              - generic [ref=e126]: root
                              - text: "\""
                            - generic [ref=e127]:
                              - generic [ref=e128]: class
                              - text: ="
                              - generic [ref=e129]: h-full
                              - text: "\""
                            - text: ">"
                          - button "Expand" [ref=e131]
                          - text: …
                          - generic "</div>" [ref=e133]:
                            - text: <
                            - generic [ref=e134]: /div
                            - text: ">"
                      - treeitem "</body>" [ref=e136]:
                        - generic "</body>" [ref=e141]:
                          - text: <
                          - generic [ref=e142]: /body
                          - text: ">"
                    - treeitem "</html>" [ref=e144]:
                      - generic "</html>" [ref=e149]:
                        - text: <
                        - generic [ref=e150]: /html
                        - text: ">"
              - navigation "DOM tree breadcrumbs" [ref=e154]:
                - list [ref=e156]:
                  - listitem [ref=e157]:
                    - link "html.h-full" [ref=e158] [cursor=pointer]:
                      - /url: "#"
                      - generic [ref=e159]:
                        - generic [ref=e160]: html
                        - generic [ref=e161]: .h-full
                  - listitem [ref=e162]:
                    - link "body.h-full.m-0.p-0.overflow-hidden" [ref=e163] [cursor=pointer]:
                      - /url: "#"
                      - generic [ref=e164]:
                        - generic [ref=e165]: body
                        - generic [ref=e166]: .h-full.m-0.p-0.overflow-hidden
          - generic [ref=e169]:
            - navigation "Side panel toolbar" [ref=e170]:
              - generic:
                - tablist:
                  - tab "Styles" [selected] [ref=e171]
                  - tab "Computed" [ref=e173]
                  - tab "Layout" [ref=e175]
                - button "More tabs" [ref=e178]
            - complementary "Side panel content" [ref=e180]:
              - tabpanel "Styles panel" [ref=e181]:
                - generic [ref=e186]:
                  - generic [ref=e188]:
                    - toolbar [ref=e189]:
                      - generic [ref=e190]:
                        - generic:
                          - generic [ref=e191]:
                            - textbox "Filter" [ref=e195]
                            - generic "Use regular expression" [ref=e196]:
                              - button "Use regular expression" [ref=e197]
                          - generic "Toggle CSS layers view" [ref=e199]:
                            - button "Toggle CSS layers view" [ref=e200]
                          - generic "Toggle element state" [ref=e202]:
                            - button "Toggle element state" [ref=e203]
                          - generic "Element classes" [ref=e205]:
                            - button "Element classes" [ref=e206]
                          - generic "New style rule" [ref=e208]:
                            - button "New style rule" [ref=e209]
                          - generic "Toggle common rendering emulations" [ref=e212]:
                            - button "Toggle common rendering emulations" [ref=e213]
                          - generic "Show Computed styles sidebar" [ref=e215]:
                            - button "Show Computed styles sidebar" [ref=e216]
                    - list [ref=e218]:
                      - listitem "element.style, css selector" [ref=e219]:
                        - generic [ref=e221]:
                          - generic [ref=e222]: "element.style {"
                          - generic [ref=e224]:
                            - generic:
                              - tree
                          - generic [ref=e225]: "}"
                      - generic [ref=e226]:
                        - generic [ref=e227]: Layer
                        - button "utilities" [ref=e228] [cursor=pointer]
                      - listitem ".p-0, css selector" [ref=e229]:
                        - link "index.css:949" [ref=e231] [cursor=pointer]
                        - generic [ref=e232]:
                          - generic [ref=e234]:
                            - generic "CSS selector" [ref=e235]: .p-0
                            - text: "{"
                          - tree [ref=e238]:
                            - 'treeitem "CSS property name: padding : CSS property value: 0px;" [ref=e239]':
                              - text: padding
                              - generic [ref=e240]: ":"
                              - 'generic "CSS property value: 0px" [ref=e242]': 0px
                              - text: ;
                          - generic [ref=e243]: "}"
                      - generic [ref=e244]:
                        - generic [ref=e245]: Layer
                        - button "utilities" [ref=e246] [cursor=pointer]
                      - listitem ".overflow-hidden, css selector" [ref=e247]:
                        - link "index.css:949" [ref=e249] [cursor=pointer]
                        - generic [ref=e250]:
                          - generic [ref=e252]:
                            - generic "CSS selector" [ref=e253]: .overflow-hidden
                            - text: "{"
                          - tree [ref=e256]:
                            - 'treeitem "CSS property name: overflow : CSS property value: hidden;" [ref=e257]':
                              - text: overflow
                              - generic [ref=e258]: ":"
                              - 'generic "CSS property value: hidden" [ref=e260]': hidden
                              - text: ;
                          - generic [ref=e261]: "}"
                      - generic [ref=e262]:
                        - generic [ref=e263]: Layer
                        - button "utilities" [ref=e264] [cursor=pointer]
                      - listitem ".h-full, css selector" [ref=e265]:
                        - link "index.css:949" [ref=e267] [cursor=pointer]
                        - generic [ref=e268]:
                          - generic [ref=e270]:
                            - generic "CSS selector" [ref=e271]: .h-full
                            - text: "{"
                          - tree [ref=e274]:
                            - 'treeitem "CSS property name: height : CSS property value: 100%;" [ref=e275]':
                              - text: height
                              - generic [ref=e276]: ":"
                              - 'generic "CSS property value: 100%" [ref=e277]': 100%
                              - text: ;
                          - generic [ref=e278]: "}"
                      - generic [ref=e279]:
                        - generic [ref=e280]: Layer
                        - button "utilities" [ref=e281] [cursor=pointer]
                      - listitem ".m-0, css selector" [ref=e282]:
                        - link "index.css:949" [ref=e284] [cursor=pointer]
                        - generic [ref=e285]:
                          - generic [ref=e287]:
                            - generic "CSS selector" [ref=e288]: .m-0
                            - text: "{"
                          - tree [ref=e291]:
                            - 'treeitem "CSS property name: margin : CSS property value: 0px;" [ref=e292]':
                              - text: margin
                              - generic [ref=e293]: ":"
                              - 'generic "CSS property value: 0px" [ref=e295]': 0px
                              - text: ;
                          - generic [ref=e296]: "}"
                      - generic [ref=e297]:
                        - generic [ref=e298]: Layer
                        - button "base" [ref=e299] [cursor=pointer]
                      - listitem "body, css selector" [ref=e300]:
                        - link "index.css:180" [ref=e302] [cursor=pointer]
                        - generic [ref=e303]:
                          - generic [ref=e305]:
                            - generic "CSS selector" [ref=e306]: body
                            - text: "{"
                          - tree [ref=e309]:
                            - 'treeitem "CSS property name: background-color : CSS property value: rgb(var(--ctp-base));" [ref=e310]':
                              - text: background-color
                              - generic [ref=e311]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-base))" [ref=e312]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e314]:
                                  - generic [ref=e315] [cursor=pointer]
                                - generic [ref=e316]:
                                  - generic [ref=e317]: rgb
                                  - text: (
                                  - generic [ref=e319]:
                                    - generic [ref=e320]: var
                                    - text: (
                                    - link "--ctp-base" [ref=e322] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: color : CSS property value: rgb(var(--ctp-text));" [ref=e323]':
                              - text: color
                              - generic [ref=e324]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-text))" [ref=e325]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e327]:
                                  - generic [ref=e328] [cursor=pointer]
                                - generic [ref=e329]:
                                  - generic [ref=e330]: rgb
                                  - text: (
                                  - generic [ref=e332]:
                                    - generic [ref=e333]: var
                                    - text: (
                                    - link "--ctp-text" [ref=e335] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: font-family : CSS property value: -apple-system, BlinkMacSystemFont, ''Segoe UI'', Roboto, sans-serif;" [ref=e336]':
                              - text: font-family
                              - generic [ref=e337]: ":"
                              - 'generic "CSS property value: -apple-system, BlinkMacSystemFont, ''Segoe UI'', Roboto, sans-serif" [ref=e338]': "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-font-smoothing : CSS property value: antialiased;" [ref=e339]':
                              - text: "-webkit-font-smoothing"
                              - generic [ref=e340]: ":"
                              - 'generic "CSS property value: antialiased" [ref=e341]': antialiased
                              - text: ;
                          - generic [ref=e342]: "}"
                      - generic [ref=e343]:
                        - generic [ref=e344]: Layer
                        - button "base" [ref=e345] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e346]:
                        - link "index.css:144" [ref=e348] [cursor=pointer]
                        - generic [ref=e349]:
                          - generic [ref=e351]:
                            - generic "CSS selector" [ref=e352]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e355]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e356]':
                              - text: box-sizing
                              - generic [ref=e357]: ":"
                              - 'generic "CSS property value: border-box" [ref=e358]': border-box
                              - text: ;
                          - generic [ref=e359]: "}"
                      - generic [ref=e360]:
                        - generic [ref=e361]: Layer
                        - button "base" [ref=e362] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e363]:
                        - link "index.css:542" [ref=e365] [cursor=pointer]
                        - generic [ref=e366]:
                          - generic [ref=e368]:
                            - generic "CSS selector" [ref=e369]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e372]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e373]':
                              - text: box-sizing
                              - generic [ref=e374]: ":"
                              - 'generic "CSS property value: border-box" [ref=e375]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e376]':
                              - text: margin
                              - generic [ref=e377]: ":"
                              - 'generic "CSS property value: 0" [ref=e379]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e380]':
                              - text: padding
                              - generic [ref=e381]: ":"
                              - 'generic "CSS property value: 0" [ref=e383]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e384]':
                              - text: border
                              - generic [ref=e385]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e387]': 0 solid
                              - text: ;
                          - generic [ref=e388]: "}"
                      - generic [ref=e389]:
                        - generic [ref=e390]: Layer
                        - generic [ref=e391]: user agent stylesheet
                      - listitem "body, css selector" [ref=e392]:
                        - generic [ref=e393]: user agent stylesheet
                        - generic [ref=e394]:
                          - generic [ref=e396]:
                            - generic "CSS selector" [ref=e397]: body
                            - text: "{"
                          - tree [ref=e400]:
                            - 'treeitem "CSS property name: display : CSS property value: block;" [ref=e401]':
                              - text: display
                              - generic [ref=e402]: ":"
                              - 'generic "CSS property value: block" [ref=e403]': block
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 8px;" [ref=e404]':
                              - text: margin
                              - generic [ref=e405]: ":"
                              - 'generic "CSS property value: 8px" [ref=e407]': 8px
                              - text: ;
                          - generic [ref=e408]: "}"
                      - generic [ref=e409]:
                        - text: Inherited from
                        - button "html.h-full" [ref=e413] [cursor=pointer]:
                          - generic [ref=e414]: html
                          - generic [ref=e415]: .h-full
                      - listitem "style attribute, css selector" [ref=e416]:
                        - generic [ref=e418]:
                          - generic [ref=e419]: "style attribute {"
                          - tree [ref=e423]:
                            - 'treeitem "CSS property name: --ctp-base : CSS property value: 30 30 46;" [ref=e424]':
                              - text: "--ctp-base"
                              - generic [ref=e425]: ":"
                              - 'generic "CSS property value: 30 30 46" [ref=e426]': 30 30 46
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-mantle : CSS property value: 24 24 37;" [ref=e427]':
                              - text: "--ctp-mantle"
                              - generic [ref=e428]: ":"
                              - 'generic "CSS property value: 24 24 37" [ref=e429]': 24 24 37
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-crust : CSS property value: 17 17 27;" [ref=e430]':
                              - text: "--ctp-crust"
                              - generic [ref=e431]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e432]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-text : CSS property value: 205 214 244;" [ref=e433]':
                              - text: "--ctp-text"
                              - generic [ref=e434]: ":"
                              - 'generic "CSS property value: 205 214 244" [ref=e435]': 205 214 244
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext0 : CSS property value: 166 173 200;" [ref=e436]':
                              - text: "--ctp-subtext0"
                              - generic [ref=e437]: ":"
                              - 'generic "CSS property value: 166 173 200" [ref=e438]': 166 173 200
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext1 : CSS property value: 186 194 222;" [ref=e439]':
                              - text: "--ctp-subtext1"
                              - generic [ref=e440]: ":"
                              - 'generic "CSS property value: 186 194 222" [ref=e441]': 186 194 222
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface0 : CSS property value: 49 50 68;" [ref=e442]':
                              - text: "--ctp-surface0"
                              - generic [ref=e443]: ":"
                              - 'generic "CSS property value: 49 50 68" [ref=e444]': 49 50 68
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface1 : CSS property value: 69 71 90;" [ref=e445]':
                              - text: "--ctp-surface1"
                              - generic [ref=e446]: ":"
                              - 'generic "CSS property value: 69 71 90" [ref=e447]': 69 71 90
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface2 : CSS property value: 88 91 112;" [ref=e448]':
                              - text: "--ctp-surface2"
                              - generic [ref=e449]: ":"
                              - 'generic "CSS property value: 88 91 112" [ref=e450]': 88 91 112
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent : CSS property value: 137 180 250;" [ref=e451]':
                              - text: "--ctp-accent"
                              - generic [ref=e452]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e453]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-link : CSS property value: 137 180 250;" [ref=e454]':
                              - text: "--ctp-link"
                              - generic [ref=e455]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e456]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-warning : CSS property value: 249 226 175;" [ref=e457]':
                              - text: "--ctp-warning"
                              - generic [ref=e458]: ":"
                              - 'generic "CSS property value: 249 226 175" [ref=e459]': 249 226 175
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-error : CSS property value: 243 139 168;" [ref=e460]':
                              - text: "--ctp-error"
                              - generic [ref=e461]: ":"
                              - 'generic "CSS property value: 243 139 168" [ref=e462]': 243 139 168
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-info : CSS property value: 137 180 250;" [ref=e463]':
                              - text: "--ctp-info"
                              - generic [ref=e464]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e465]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-success : CSS property value: 166 227 161;" [ref=e466]':
                              - text: "--ctp-success"
                              - generic [ref=e467]: ":"
                              - 'generic "CSS property value: 166 227 161" [ref=e468]': 166 227 161
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent2 : CSS property value: 116 199 236;" [ref=e469]':
                              - text: "--ctp-accent2"
                              - generic [ref=e470]: ":"
                              - 'generic "CSS property value: 116 199 236" [ref=e471]': 116 199 236
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay : CSS property value: 127 132 156;" [ref=e472]':
                              - text: "--ctp-overlay"
                              - generic [ref=e473]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e474]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay0 : CSS property value: 108 112 134;" [ref=e475]':
                              - text: "--ctp-overlay0"
                              - generic [ref=e476]: ":"
                              - 'generic "CSS property value: 108 112 134" [ref=e477]': 108 112 134
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay1 : CSS property value: 127 132 156;" [ref=e478]':
                              - text: "--ctp-overlay1"
                              - generic [ref=e479]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e480]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-on-accent : CSS property value: 17 17 27;" [ref=e481]':
                              - text: "--ctp-on-accent"
                              - generic [ref=e482]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e483]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --select-chevron : CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D''http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg''%20viewBox%3D''0%200%2012%2012''%3E%3Cpath%20d%3D''M3%204.5%206%207.5%209%204.5''%20fill%3D''none''%20stroke%3D''rgb(127%2C132%2C156)''%20stroke-width%3D''1.5''%20stroke-linecap%3D''round''%20stroke-linejoin%3D''round''%2F%3E%3C%2Fsvg%3E\");" [ref=e484]':
                              - text: "--select-chevron"
                              - generic [ref=e485]: ":"
                              - 'generic "CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D''http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg''%20viewBox%3D''0%200%2012%2012''%3E%3Cpath%20d%3D''M3%204.5%206%207.5%209%204.5''%20fill%3D''none''%20stroke%3D''rgb(127%2C132%2C156)''%20stroke-width%3D''1.5''%20stroke-linecap%3D''round''%20stroke-linejoin%3D''round''%2F%3E%3C%2Fsvg%3E\")" [ref=e486]':
                                - text: url(
                                - link "data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%2012%2012'%3E%3Cpath%20d%3D'M3%204.5%206%207.5%209%204.5'%20fill%3D'none'%20stroke%3D'rgb(127%2C132%2C156)'%20stroke-width%3D'1.5'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3C%2Fsvg%3E" [ref=e487] [cursor=pointer]
                                - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-keyword : CSS property value: #cba6f7;" [ref=e488]':
                              - text: "--hljs-keyword"
                              - generic [ref=e489]: ":"
                              - 'generic "CSS property value: #cba6f7" [ref=e490]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e492]:
                                  - generic [ref=e493] [cursor=pointer]
                                - text: "#cba6f7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-string : CSS property value: #a6e3a1;" [ref=e494]':
                              - text: "--hljs-string"
                              - generic [ref=e495]: ":"
                              - 'generic "CSS property value: #a6e3a1" [ref=e496]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e498]:
                                  - generic [ref=e499] [cursor=pointer]
                                - text: "#a6e3a1"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-number : CSS property value: #fab387;" [ref=e500]':
                              - text: "--hljs-number"
                              - generic [ref=e501]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e502]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e504]:
                                  - generic [ref=e505] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-comment : CSS property value: #6c7086;" [ref=e506]':
                              - text: "--hljs-comment"
                              - generic [ref=e507]: ":"
                              - 'generic "CSS property value: #6c7086" [ref=e508]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e510]:
                                  - generic [ref=e511] [cursor=pointer]
                                - text: "#6c7086"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-function : CSS property value: #89b4fa;" [ref=e512]':
                              - text: "--hljs-function"
                              - generic [ref=e513]: ":"
                              - 'generic "CSS property value: #89b4fa" [ref=e514]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e516]:
                                  - generic [ref=e517] [cursor=pointer]
                                - text: "#89b4fa"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-type : CSS property value: #f9e2af;" [ref=e518]':
                              - text: "--hljs-type"
                              - generic [ref=e519]: ":"
                              - 'generic "CSS property value: #f9e2af" [ref=e520]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e522]:
                                  - generic [ref=e523] [cursor=pointer]
                                - text: "#f9e2af"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-variable : CSS property value: #f38ba8;" [ref=e524]':
                              - text: "--hljs-variable"
                              - generic [ref=e525]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e526]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e528]:
                                  - generic [ref=e529] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-regexp : CSS property value: #f5c2e7;" [ref=e530]':
                              - text: "--hljs-regexp"
                              - generic [ref=e531]: ":"
                              - 'generic "CSS property value: #f5c2e7" [ref=e532]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e534]:
                                  - generic [ref=e535] [cursor=pointer]
                                - text: "#f5c2e7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-tag : CSS property value: #89b4fa;" [ref=e536]':
                              - text: "--hljs-tag"
                              - generic [ref=e537]: ":"
                              - 'generic "CSS property value: #89b4fa" [ref=e538]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e540]:
                                  - generic [ref=e541] [cursor=pointer]
                                - text: "#89b4fa"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-attribute : CSS property value: #f9e2af;" [ref=e542]':
                              - text: "--hljs-attribute"
                              - generic [ref=e543]: ":"
                              - 'generic "CSS property value: #f9e2af" [ref=e544]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e546]:
                                  - generic [ref=e547] [cursor=pointer]
                                - text: "#f9e2af"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-symbol : CSS property value: #f38ba8;" [ref=e548]':
                              - text: "--hljs-symbol"
                              - generic [ref=e549]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e550]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e552]:
                                  - generic [ref=e553] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-meta : CSS property value: #fab387;" [ref=e554]':
                              - text: "--hljs-meta"
                              - generic [ref=e555]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e556]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e558]:
                                  - generic [ref=e559] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-addition : CSS property value: #a6e3a1;" [ref=e560]':
                              - text: "--hljs-addition"
                              - generic [ref=e561]: ":"
                              - 'generic "CSS property value: #a6e3a1" [ref=e562]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e564]:
                                  - generic [ref=e565] [cursor=pointer]
                                - text: "#a6e3a1"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-deletion : CSS property value: #f38ba8;" [ref=e566]':
                              - text: "--hljs-deletion"
                              - generic [ref=e567]: ":"
                              - 'generic "CSS property value: #f38ba8" [ref=e568]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e570]:
                                  - generic [ref=e571] [cursor=pointer]
                                - text: "#f38ba8"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-property : CSS property value: #94e2d5;" [ref=e572]':
                              - text: "--hljs-property"
                              - generic [ref=e573]: ":"
                              - 'generic "CSS property value: #94e2d5" [ref=e574]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e576]:
                                  - generic [ref=e577] [cursor=pointer]
                                - text: "#94e2d5"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-punctuation : CSS property value: #9399b2;" [ref=e578]':
                              - text: "--hljs-punctuation"
                              - generic [ref=e579]: ":"
                              - 'generic "CSS property value: #9399b2" [ref=e580]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e582]:
                                  - generic [ref=e583] [cursor=pointer]
                                - text: "#9399b2"
                              - text: ;
                            - 'treeitem "CSS property name: --shadow-depth : CSS property value: 0 4px 24px rgba(0, 0, 0, 0.5);" [ref=e584]':
                              - text: "--shadow-depth"
                              - generic [ref=e585]: ":"
                              - 'generic "CSS property value: 0 4px 24px rgba(0, 0, 0, 0.5)" [ref=e586]':
                                - text: 0 4px 24px
                                - generic "Open color picker. Shift + Click to change color format" [ref=e588]:
                                  - generic [ref=e589] [cursor=pointer]
                                - generic [ref=e590]:
                                  - generic [ref=e591]: rgba
                                  - text: (0, 0, 0, 0.5)
                              - text: ;
                            - 'treeitem "CSS property name: --shadow-elevation : CSS property value: 0 12px 40px rgba(0, 0, 0, 0.6);" [ref=e592]':
                              - text: "--shadow-elevation"
                              - generic [ref=e593]: ":"
                              - 'generic "CSS property value: 0 12px 40px rgba(0, 0, 0, 0.6)" [ref=e594]':
                                - text: 0 12px 40px
                                - generic "Open color picker. Shift + Click to change color format" [ref=e596]:
                                  - generic [ref=e597] [cursor=pointer]
                                - generic [ref=e598]:
                                  - generic [ref=e599]: rgba
                                  - text: (0, 0, 0, 0.6)
                              - text: ;
                            - 'treeitem "CSS property name: --grid-dot-color : CSS property value: rgba(255, 255, 255, 0.1);" [ref=e600]':
                              - text: "--grid-dot-color"
                              - generic [ref=e601]: ":"
                              - 'generic "CSS property value: rgba(255, 255, 255, 0.1)" [ref=e602]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e604]:
                                  - generic [ref=e605] [cursor=pointer]
                                - generic [ref=e606]:
                                  - generic [ref=e607]: rgba
                                  - text: (255, 255, 255, 0.1)
                              - text: ;
                          - generic [ref=e608]: "}"
                      - generic [ref=e609]:
                        - generic [ref=e610]: Layer
                        - button "Click to reveal layer in layer tree" [ref=e611] [cursor=pointer]
                      - listitem ":root, css selector" [ref=e612]:
                        - link "index.css:63" [ref=e614] [cursor=pointer]
                        - generic [ref=e615]:
                          - generic [ref=e617]:
                            - generic "CSS selector" [ref=e618]: :root
                            - text: "{"
                          - tree [ref=e621]:
                            - 'treeitem "CSS property name: --ctp-base : CSS property value: 30 30 46;" [ref=e622]':
                              - text: "--ctp-base"
                              - generic [ref=e623]: ":"
                              - 'generic "CSS property value: 30 30 46" [ref=e624]': 30 30 46
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-mantle : CSS property value: 24 24 37;" [ref=e625]':
                              - text: "--ctp-mantle"
                              - generic [ref=e626]: ":"
                              - 'generic "CSS property value: 24 24 37" [ref=e627]': 24 24 37
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-crust : CSS property value: 17 17 27;" [ref=e628]':
                              - text: "--ctp-crust"
                              - generic [ref=e629]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e630]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-text : CSS property value: 205 214 244;" [ref=e631]':
                              - text: "--ctp-text"
                              - generic [ref=e632]: ":"
                              - 'generic "CSS property value: 205 214 244" [ref=e633]': 205 214 244
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext1 : CSS property value: 186 194 222;" [ref=e634]':
                              - text: "--ctp-subtext1"
                              - generic [ref=e635]: ":"
                              - 'generic "CSS property value: 186 194 222" [ref=e636]': 186 194 222
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-subtext0 : CSS property value: 166 173 200;" [ref=e637]':
                              - text: "--ctp-subtext0"
                              - generic [ref=e638]: ":"
                              - 'generic "CSS property value: 166 173 200" [ref=e639]': 166 173 200
                              - text: ;
                            - 'treeitem "CSS property name: --select-chevron : CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E\");" [ref=e640]':
                              - text: "--select-chevron"
                              - generic [ref=e641]: ":"
                              - 'generic "CSS property value: url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E\")" [ref=e642]':
                                - text: url(
                                - link "data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%2012%2012%27%3E%3Cpath%20d%3D%27M3%204.5%206%207.5%209%204.5%27%20fill%3D%27none%27%20stroke%3D%27rgb%28127%2C132%2C156%29%27%20stroke-width%3D%271.5%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E" [ref=e643] [cursor=pointer]
                                - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface0 : CSS property value: 49 50 68;" [ref=e644]':
                              - text: "--ctp-surface0"
                              - generic [ref=e645]: ":"
                              - 'generic "CSS property value: 49 50 68" [ref=e646]': 49 50 68
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface1 : CSS property value: 69 71 90;" [ref=e647]':
                              - text: "--ctp-surface1"
                              - generic [ref=e648]: ":"
                              - 'generic "CSS property value: 69 71 90" [ref=e649]': 69 71 90
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-surface2 : CSS property value: 88 91 112;" [ref=e650]':
                              - text: "--ctp-surface2"
                              - generic [ref=e651]: ":"
                              - 'generic "CSS property value: 88 91 112" [ref=e652]': 88 91 112
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-accent : CSS property value: 137 180 250;" [ref=e653]':
                              - text: "--ctp-accent"
                              - generic [ref=e654]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e655]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-on-accent : CSS property value: 17 17 27;" [ref=e656]':
                              - text: "--ctp-on-accent"
                              - generic [ref=e657]: ":"
                              - 'generic "CSS property value: 17 17 27" [ref=e658]': 17 17 27
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-link : CSS property value: 137 180 250;" [ref=e659]':
                              - text: "--ctp-link"
                              - generic [ref=e660]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e661]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-warning : CSS property value: 249 226 175;" [ref=e662]':
                              - text: "--ctp-warning"
                              - generic [ref=e663]: ":"
                              - 'generic "CSS property value: 249 226 175" [ref=e664]': 249 226 175
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-error : CSS property value: 243 139 168;" [ref=e665]':
                              - text: "--ctp-error"
                              - generic [ref=e666]: ":"
                              - 'generic "CSS property value: 243 139 168" [ref=e667]': 243 139 168
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-info : CSS property value: 137 180 250;" [ref=e668]':
                              - text: "--ctp-info"
                              - generic [ref=e669]: ":"
                              - 'generic "CSS property value: 137 180 250" [ref=e670]': 137 180 250
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-success : CSS property value: 166 227 161;" [ref=e671]':
                              - text: "--ctp-success"
                              - generic [ref=e672]: ":"
                              - 'generic "CSS property value: 166 227 161" [ref=e673]': 166 227 161
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay0 : CSS property value: 108 112 134;" [ref=e674]':
                              - text: "--ctp-overlay0"
                              - generic [ref=e675]: ":"
                              - 'generic "CSS property value: 108 112 134" [ref=e676]': 108 112 134
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-overlay1 : CSS property value: 127 132 156;" [ref=e677]':
                              - text: "--ctp-overlay1"
                              - generic [ref=e678]: ":"
                              - 'generic "CSS property value: 127 132 156" [ref=e679]': 127 132 156
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-orange : CSS property value: 249 115 22;" [ref=e680]':
                              - text: "--ctp-badge-orange"
                              - generic [ref=e681]: ":"
                              - 'generic "CSS property value: 249 115 22" [ref=e682]': 249 115 22
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-blue : CSS property value: 59 130 246;" [ref=e683]':
                              - text: "--ctp-badge-blue"
                              - generic [ref=e684]: ":"
                              - 'generic "CSS property value: 59 130 246" [ref=e685]': 59 130 246
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-grey : CSS property value: 148 163 184;" [ref=e686]':
                              - text: "--ctp-badge-grey"
                              - generic [ref=e687]: ":"
                              - 'generic "CSS property value: 148 163 184" [ref=e688]': 148 163 184
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-purple : CSS property value: 168 85 247;" [ref=e689]':
                              - text: "--ctp-badge-purple"
                              - generic [ref=e690]: ":"
                              - 'generic "CSS property value: 168 85 247" [ref=e691]': 168 85 247
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-teal : CSS property value: 20 184 166;" [ref=e692]':
                              - text: "--ctp-badge-teal"
                              - generic [ref=e693]: ":"
                              - 'generic "CSS property value: 20 184 166" [ref=e694]': 20 184 166
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-pink : CSS property value: 236 72 153;" [ref=e695]':
                              - text: "--ctp-badge-pink"
                              - generic [ref=e696]: ":"
                              - 'generic "CSS property value: 236 72 153" [ref=e697]': 236 72 153
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-green : CSS property value: 34 197 94;" [ref=e698]':
                              - text: "--ctp-badge-green"
                              - generic [ref=e699]: ":"
                              - 'generic "CSS property value: 34 197 94" [ref=e700]': 34 197 94
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-amber : CSS property value: 251 191 36;" [ref=e701]':
                              - text: "--ctp-badge-amber"
                              - generic [ref=e702]: ":"
                              - 'generic "CSS property value: 251 191 36" [ref=e703]': 251 191 36
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-indigo : CSS property value: 99 102 241;" [ref=e704]':
                              - text: "--ctp-badge-indigo"
                              - generic [ref=e705]: ":"
                              - 'generic "CSS property value: 99 102 241" [ref=e706]': 99 102 241
                              - text: ;
                            - 'treeitem "CSS property name: --ctp-badge-sky : CSS property value: 14 165 233;" [ref=e707]':
                              - text: "--ctp-badge-sky"
                              - generic [ref=e708]: ":"
                              - 'generic "CSS property value: 14 165 233" [ref=e709]': 14 165 233
                              - text: ;
                            - 'treeitem "CSS property name: --brand-claude : CSS property value: 217 119 87;" [ref=e710]':
                              - text: "--brand-claude"
                              - generic [ref=e711]: ":"
                              - 'generic "CSS property value: 217 119 87" [ref=e712]': 217 119 87
                              - text: ;
                            - 'treeitem "CSS property name: --brand-claude-ink : CSS property value: 48 26 19;" [ref=e713]':
                              - text: "--brand-claude-ink"
                              - generic [ref=e714]: ":"
                              - 'generic "CSS property value: 48 26 19" [ref=e715]': 48 26 19
                              - text: ;
                            - 'treeitem "CSS property name: --brand-copilot : CSS property value: 137 87 229;" [ref=e716]':
                              - text: "--brand-copilot"
                              - generic [ref=e717]: ":"
                              - 'generic "CSS property value: 137 87 229" [ref=e718]': 137 87 229
                              - text: ;
                            - 'treeitem "CSS property name: --brand-codex : CSS property value: var(--ctp-text);" [ref=e719]':
                              - text: "--brand-codex"
                              - generic [ref=e720]: ":"
                              - 'generic "CSS property value: var(--ctp-text)" [ref=e721]':
                                - generic [ref=e723]:
                                  - generic [ref=e724]: var
                                  - text: (
                                  - link "--ctp-text" [ref=e726] [cursor=pointer]
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-keyword : CSS property value: rgb(var(--ctp-accent2));" [ref=e727]':
                              - text: "--hljs-keyword"
                              - generic [ref=e728]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent2))" [ref=e729]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e731]:
                                  - generic [ref=e732] [cursor=pointer]
                                - generic [ref=e733]:
                                  - generic [ref=e734]: rgb
                                  - text: (
                                  - generic [ref=e736]:
                                    - generic [ref=e737]: var
                                    - text: (
                                    - link "--ctp-accent2" [ref=e739] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-string : CSS property value: rgb(var(--ctp-success));" [ref=e740]':
                              - text: "--hljs-string"
                              - generic [ref=e741]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-success))" [ref=e742]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e744]:
                                  - generic [ref=e745] [cursor=pointer]
                                - generic [ref=e746]:
                                  - generic [ref=e747]: rgb
                                  - text: (
                                  - generic [ref=e749]:
                                    - generic [ref=e750]: var
                                    - text: (
                                    - link "--ctp-success" [ref=e752] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-number : CSS property value: #fab387;" [ref=e753]':
                              - text: "--hljs-number"
                              - generic [ref=e754]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e755]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e757]:
                                  - generic [ref=e758] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-comment : CSS property value: rgb(var(--ctp-overlay0));" [ref=e759]':
                              - text: "--hljs-comment"
                              - generic [ref=e760]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-overlay0))" [ref=e761]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e763]:
                                  - generic [ref=e764] [cursor=pointer]
                                - generic [ref=e765]:
                                  - generic [ref=e766]: rgb
                                  - text: (
                                  - generic [ref=e768]:
                                    - generic [ref=e769]: var
                                    - text: (
                                    - link "--ctp-overlay0" [ref=e771] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-function : CSS property value: rgb(var(--ctp-accent));" [ref=e772]':
                              - text: "--hljs-function"
                              - generic [ref=e773]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent))" [ref=e774]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e776]:
                                  - generic [ref=e777] [cursor=pointer]
                                - generic [ref=e778]:
                                  - generic [ref=e779]: rgb
                                  - text: (
                                  - generic [ref=e781]:
                                    - generic [ref=e782]: var
                                    - text: (
                                    - link "--ctp-accent" [ref=e784] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-type : CSS property value: rgb(var(--ctp-warning));" [ref=e785]':
                              - text: "--hljs-type"
                              - generic [ref=e786]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-warning))" [ref=e787]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e789]:
                                  - generic [ref=e790] [cursor=pointer]
                                - generic [ref=e791]:
                                  - generic [ref=e792]: rgb
                                  - text: (
                                  - generic [ref=e794]:
                                    - generic [ref=e795]: var
                                    - text: (
                                    - link "--ctp-warning" [ref=e797] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-variable : CSS property value: rgb(var(--ctp-error));" [ref=e798]':
                              - text: "--hljs-variable"
                              - generic [ref=e799]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e800]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e802]:
                                  - generic [ref=e803] [cursor=pointer]
                                - generic [ref=e804]:
                                  - generic [ref=e805]: rgb
                                  - text: (
                                  - generic [ref=e807]:
                                    - generic [ref=e808]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e810] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-regexp : CSS property value: #f5c2e7;" [ref=e811]':
                              - text: "--hljs-regexp"
                              - generic [ref=e812]: ":"
                              - 'generic "CSS property value: #f5c2e7" [ref=e813]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e815]:
                                  - generic [ref=e816] [cursor=pointer]
                                - text: "#f5c2e7"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-tag : CSS property value: rgb(var(--ctp-accent));" [ref=e817]':
                              - text: "--hljs-tag"
                              - generic [ref=e818]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-accent))" [ref=e819]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e821]:
                                  - generic [ref=e822] [cursor=pointer]
                                - generic [ref=e823]:
                                  - generic [ref=e824]: rgb
                                  - text: (
                                  - generic [ref=e826]:
                                    - generic [ref=e827]: var
                                    - text: (
                                    - link "--ctp-accent" [ref=e829] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-attribute : CSS property value: rgb(var(--ctp-warning));" [ref=e830]':
                              - text: "--hljs-attribute"
                              - generic [ref=e831]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-warning))" [ref=e832]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e834]:
                                  - generic [ref=e835] [cursor=pointer]
                                - generic [ref=e836]:
                                  - generic [ref=e837]: rgb
                                  - text: (
                                  - generic [ref=e839]:
                                    - generic [ref=e840]: var
                                    - text: (
                                    - link "--ctp-warning" [ref=e842] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-symbol : CSS property value: rgb(var(--ctp-error));" [ref=e843]':
                              - text: "--hljs-symbol"
                              - generic [ref=e844]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e845]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e847]:
                                  - generic [ref=e848] [cursor=pointer]
                                - generic [ref=e849]:
                                  - generic [ref=e850]: rgb
                                  - text: (
                                  - generic [ref=e852]:
                                    - generic [ref=e853]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e855] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-meta : CSS property value: #fab387;" [ref=e856]':
                              - text: "--hljs-meta"
                              - generic [ref=e857]: ":"
                              - 'generic "CSS property value: #fab387" [ref=e858]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e860]:
                                  - generic [ref=e861] [cursor=pointer]
                                - text: "#fab387"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-addition : CSS property value: rgb(var(--ctp-success));" [ref=e862]':
                              - text: "--hljs-addition"
                              - generic [ref=e863]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-success))" [ref=e864]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e866]:
                                  - generic [ref=e867] [cursor=pointer]
                                - generic [ref=e868]:
                                  - generic [ref=e869]: rgb
                                  - text: (
                                  - generic [ref=e871]:
                                    - generic [ref=e872]: var
                                    - text: (
                                    - link "--ctp-success" [ref=e874] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-deletion : CSS property value: rgb(var(--ctp-error));" [ref=e875]':
                              - text: "--hljs-deletion"
                              - generic [ref=e876]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-error))" [ref=e877]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e879]:
                                  - generic [ref=e880] [cursor=pointer]
                                - generic [ref=e881]:
                                  - generic [ref=e882]: rgb
                                  - text: (
                                  - generic [ref=e884]:
                                    - generic [ref=e885]: var
                                    - text: (
                                    - link "--ctp-error" [ref=e887] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-property : CSS property value: #94e2d5;" [ref=e888]':
                              - text: "--hljs-property"
                              - generic [ref=e889]: ":"
                              - 'generic "CSS property value: #94e2d5" [ref=e890]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e892]:
                                  - generic [ref=e893] [cursor=pointer]
                                - text: "#94e2d5"
                              - text: ;
                            - 'treeitem "CSS property name: --hljs-punctuation : CSS property value: rgb(var(--ctp-overlay1));" [ref=e894]':
                              - text: "--hljs-punctuation"
                              - generic [ref=e895]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-overlay1))" [ref=e896]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e898]:
                                  - generic [ref=e899] [cursor=pointer]
                                - generic [ref=e900]:
                                  - generic [ref=e901]: rgb
                                  - text: (
                                  - generic [ref=e903]:
                                    - generic [ref=e904]: var
                                    - text: (
                                    - link "--ctp-overlay1" [ref=e906] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e907]: "}"
                      - generic [ref=e908]:
                        - generic [ref=e909]: Layer
                        - button "base" [ref=e910] [cursor=pointer]
                      - listitem "html, :host, css selector" [ref=e911]:
                        - link "index.css:563" [ref=e913] [cursor=pointer]
                        - generic [ref=e914]:
                          - generic [ref=e916]:
                            - generic "CSS selector" [ref=e917]: html, :host
                            - text: "{"
                          - tree [ref=e920]:
                            - 'treeitem "CSS property name: line-height : CSS property value: 1.5;" [ref=e921]':
                              - text: line-height
                              - generic [ref=e922]: ":"
                              - 'generic "CSS property value: 1.5" [ref=e923]': "1.5"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-text-size-adjust : CSS property value: 100%;" [ref=e924]':
                              - text: "-webkit-text-size-adjust"
                              - generic [ref=e925]: ":"
                              - 'generic "CSS property value: 100%" [ref=e926]': 100%
                              - text: ;
                            - 'treeitem "CSS property name: tab-size : CSS property value: 4;" [ref=e927]':
                              - text: tab-size
                              - generic [ref=e928]: ":"
                              - 'generic "CSS property value: 4" [ref=e929]': "4"
                              - text: ;
                            - 'treeitem "CSS property name: font-family : CSS property value: var(--default-font-family, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\");" [ref=e930]':
                              - text: font-family
                              - generic [ref=e931]: ":"
                              - 'generic "CSS property value: var(--default-font-family, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\")" [ref=e932]':
                                - generic [ref=e934]:
                                  - generic [ref=e935]: var
                                  - text: (
                                  - link "--default-font-family" [ref=e937] [cursor=pointer]
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: font-feature-settings : CSS property value: var(--default-font-feature-settings, normal);" [ref=e938]':
                              - text: font-feature-settings
                              - generic [ref=e939]: ":"
                              - 'generic "CSS property value: var(--default-font-feature-settings, normal)" [ref=e940]':
                                - generic [ref=e942]:
                                  - generic [ref=e943]: var
                                  - text: (
                                  - link "--default-font-feature-settings" [disabled] [ref=e945] [cursor=pointer]
                                  - text: ", normal)"
                              - text: ;
                            - 'treeitem "CSS property name: font-variation-settings : CSS property value: var(--default-font-variation-settings, normal);" [ref=e946]':
                              - text: font-variation-settings
                              - generic [ref=e947]: ":"
                              - 'generic "CSS property value: var(--default-font-variation-settings, normal)" [ref=e948]':
                                - generic [ref=e950]:
                                  - generic [ref=e951]: var
                                  - text: (
                                  - link "--default-font-variation-settings" [disabled] [ref=e953] [cursor=pointer]
                                  - text: ", normal)"
                              - text: ;
                            - 'treeitem "CSS property name: -webkit-tap-highlight-color : CSS property value: transparent;" [ref=e954]':
                              - text: "-webkit-tap-highlight-color"
                              - generic [ref=e955]: ":"
                              - 'generic "CSS property value: transparent" [ref=e956]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e958]:
                                  - generic [ref=e959] [cursor=pointer]
                                - text: transparent
                              - text: ;
                          - generic [ref=e960]: "}"
                      - generic [ref=e961]:
                        - generic [ref=e962]: Layer
                        - button "theme" [ref=e963] [cursor=pointer]
                      - listitem ":root, :host, css selector" [ref=e964]:
                        - link "index.css:4" [ref=e966] [cursor=pointer]
                        - generic [ref=e967]:
                          - generic [ref=e969]:
                            - generic "CSS selector" [ref=e970]: :root, :host
                            - text: "{"
                          - tree [ref=e973]:
                            - 'treeitem "CSS property name: --font-sans : CSS property value: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";" [ref=e974]':
                              - text: "--font-sans"
                              - generic [ref=e975]: ":"
                              - 'generic "CSS property value: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"" [ref=e976]': "-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\""
                              - text: ;
                            - 'treeitem "CSS property name: --font-mono : CSS property value: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;" [ref=e977]':
                              - text: "--font-mono"
                              - generic [ref=e978]: ":"
                              - 'generic "CSS property value: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace" [ref=e979]': ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace
                              - text: ;
                            - 'treeitem "CSS property name: --color-orange-500 : CSS property value: oklch(70.5% 0.213 47.604);" [ref=e980]':
                              - text: "--color-orange-500"
                              - generic [ref=e981]: ":"
                              - 'generic "CSS property value: oklch(70.5% 0.213 47.604)" [ref=e982]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e984]:
                                  - generic [ref=e985] [cursor=pointer]
                                - generic [ref=e986]:
                                  - generic [ref=e987]: oklch
                                  - text: (70.5% 0.213 47.604)
                              - text: ;
                            - 'treeitem "CSS property name: --color-amber-500 : CSS property value: oklch(76.9% 0.188 70.08);" [ref=e988]':
                              - text: "--color-amber-500"
                              - generic [ref=e989]: ":"
                              - 'generic "CSS property value: oklch(76.9% 0.188 70.08)" [ref=e990]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e992]:
                                  - generic [ref=e993] [cursor=pointer]
                                - generic [ref=e994]:
                                  - generic [ref=e995]: oklch
                                  - text: (76.9% 0.188 70.08)
                              - text: ;
                            - 'treeitem "CSS property name: --color-green-500 : CSS property value: oklch(72.3% 0.219 149.579);" [ref=e996]':
                              - text: "--color-green-500"
                              - generic [ref=e997]: ":"
                              - 'generic "CSS property value: oklch(72.3% 0.219 149.579)" [ref=e998]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1000]:
                                  - generic [ref=e1001] [cursor=pointer]
                                - generic [ref=e1002]:
                                  - generic [ref=e1003]: oklch
                                  - text: (72.3% 0.219 149.579)
                              - text: ;
                            - 'treeitem "CSS property name: --color-emerald-500 : CSS property value: oklch(69.6% 0.17 162.48);" [ref=e1004]':
                              - text: "--color-emerald-500"
                              - generic [ref=e1005]: ":"
                              - 'generic "CSS property value: oklch(69.6% 0.17 162.48)" [ref=e1006]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1008]:
                                  - generic [ref=e1009] [cursor=pointer]
                                - generic [ref=e1010]:
                                  - generic [ref=e1011]: oklch
                                  - text: (69.6% 0.17 162.48)
                              - text: ;
                            - 'treeitem "CSS property name: --color-teal-500 : CSS property value: oklch(70.4% 0.14 182.503);" [ref=e1012]':
                              - text: "--color-teal-500"
                              - generic [ref=e1013]: ":"
                              - 'generic "CSS property value: oklch(70.4% 0.14 182.503)" [ref=e1014]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1016]:
                                  - generic [ref=e1017] [cursor=pointer]
                                - generic [ref=e1018]:
                                  - generic [ref=e1019]: oklch
                                  - text: (70.4% 0.14 182.503)
                              - text: ;
                            - 'treeitem "CSS property name: --color-cyan-500 : CSS property value: oklch(71.5% 0.143 215.221);" [ref=e1020]':
                              - text: "--color-cyan-500"
                              - generic [ref=e1021]: ":"
                              - 'generic "CSS property value: oklch(71.5% 0.143 215.221)" [ref=e1022]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1024]:
                                  - generic [ref=e1025] [cursor=pointer]
                                - generic [ref=e1026]:
                                  - generic [ref=e1027]: oklch
                                  - text: (71.5% 0.143 215.221)
                              - text: ;
                            - 'treeitem "CSS property name: --color-indigo-500 : CSS property value: oklch(58.5% 0.233 277.117);" [ref=e1028]':
                              - text: "--color-indigo-500"
                              - generic [ref=e1029]: ":"
                              - 'generic "CSS property value: oklch(58.5% 0.233 277.117)" [ref=e1030]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1032]:
                                  - generic [ref=e1033] [cursor=pointer]
                                - generic [ref=e1034]:
                                  - generic [ref=e1035]: oklch
                                  - text: (58.5% 0.233 277.117)
                              - text: ;
                            - 'treeitem "CSS property name: --color-violet-500 : CSS property value: oklch(60.6% 0.25 292.717);" [ref=e1036]':
                              - text: "--color-violet-500"
                              - generic [ref=e1037]: ":"
                              - 'generic "CSS property value: oklch(60.6% 0.25 292.717)" [ref=e1038]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1040]:
                                  - generic [ref=e1041] [cursor=pointer]
                                - generic [ref=e1042]:
                                  - generic [ref=e1043]: oklch
                                  - text: (60.6% 0.25 292.717)
                              - text: ;
                            - 'treeitem "CSS property name: --color-purple-400 : CSS property value: oklch(71.4% 0.203 305.504);" [ref=e1044]':
                              - text: "--color-purple-400"
                              - generic [ref=e1045]: ":"
                              - 'generic "CSS property value: oklch(71.4% 0.203 305.504)" [ref=e1046]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1048]:
                                  - generic [ref=e1049] [cursor=pointer]
                                - generic [ref=e1050]:
                                  - generic [ref=e1051]: oklch
                                  - text: (71.4% 0.203 305.504)
                              - text: ;
                            - 'treeitem "CSS property name: --color-purple-500 : CSS property value: oklch(62.7% 0.265 303.9);" [ref=e1052]':
                              - text: "--color-purple-500"
                              - generic [ref=e1053]: ":"
                              - 'generic "CSS property value: oklch(62.7% 0.265 303.9)" [ref=e1054]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1056]:
                                  - generic [ref=e1057] [cursor=pointer]
                                - generic [ref=e1058]:
                                  - generic [ref=e1059]: oklch
                                  - text: (62.7% 0.265 303.9)
                              - text: ;
                            - 'treeitem "CSS property name: --color-rose-500 : CSS property value: oklch(64.5% 0.246 16.439);" [ref=e1060]':
                              - text: "--color-rose-500"
                              - generic [ref=e1061]: ":"
                              - 'generic "CSS property value: oklch(64.5% 0.246 16.439)" [ref=e1062]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1064]:
                                  - generic [ref=e1065] [cursor=pointer]
                                - generic [ref=e1066]:
                                  - generic [ref=e1067]: oklch
                                  - text: (64.5% 0.246 16.439)
                              - text: ;
                            - 'treeitem "CSS property name: --color-gray-300 : CSS property value: oklch(87.2% 0.01 258.338);" [ref=e1068]':
                              - text: "--color-gray-300"
                              - generic [ref=e1069]: ":"
                              - 'generic "CSS property value: oklch(87.2% 0.01 258.338)" [ref=e1070]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1072]:
                                  - generic [ref=e1073] [cursor=pointer]
                                - generic [ref=e1074]:
                                  - generic [ref=e1075]: oklch
                                  - text: (87.2% 0.01 258.338)
                              - text: ;
                            - 'treeitem "CSS property name: --color-gray-500 : CSS property value: oklch(55.1% 0.027 264.364);" [ref=e1076]':
                              - text: "--color-gray-500"
                              - generic [ref=e1077]: ":"
                              - 'generic "CSS property value: oklch(55.1% 0.027 264.364)" [ref=e1078]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1080]:
                                  - generic [ref=e1081] [cursor=pointer]
                                - generic [ref=e1082]:
                                  - generic [ref=e1083]: oklch
                                  - text: (55.1% 0.027 264.364)
                              - text: ;
                            - 'treeitem "CSS property name: --color-black : CSS property value: #000;" [ref=e1084]':
                              - text: "--color-black"
                              - generic [ref=e1085]: ":"
                              - 'generic "CSS property value: #000" [ref=e1086]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1088]:
                                  - generic [ref=e1089] [cursor=pointer]
                                - text: "#000"
                              - text: ;
                            - 'treeitem "CSS property name: --color-white : CSS property value: #fff;" [ref=e1090]':
                              - text: "--color-white"
                              - generic [ref=e1091]: ":"
                              - 'generic "CSS property value: #fff" [ref=e1092]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1094]:
                                  - generic [ref=e1095] [cursor=pointer]
                                - text: "#fff"
                              - text: ;
                            - 'treeitem "CSS property name: --spacing : CSS property value: 0.25rem;" [ref=e1096]':
                              - text: "--spacing"
                              - generic [ref=e1097]: ":"
                              - 'generic "CSS property value: 0.25rem" [ref=e1098]': 0.25rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-xs : CSS property value: 20rem;" [ref=e1099]':
                              - text: "--container-xs"
                              - generic [ref=e1100]: ":"
                              - 'generic "CSS property value: 20rem" [ref=e1101]': 20rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-sm : CSS property value: 24rem;" [ref=e1102]':
                              - text: "--container-sm"
                              - generic [ref=e1103]: ":"
                              - 'generic "CSS property value: 24rem" [ref=e1104]': 24rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-md : CSS property value: 28rem;" [ref=e1105]':
                              - text: "--container-md"
                              - generic [ref=e1106]: ":"
                              - 'generic "CSS property value: 28rem" [ref=e1107]': 28rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-lg : CSS property value: 32rem;" [ref=e1108]':
                              - text: "--container-lg"
                              - generic [ref=e1109]: ":"
                              - 'generic "CSS property value: 32rem" [ref=e1110]': 32rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-2xl : CSS property value: 42rem;" [ref=e1111]':
                              - text: "--container-2xl"
                              - generic [ref=e1112]: ":"
                              - 'generic "CSS property value: 42rem" [ref=e1113]': 42rem
                              - text: ;
                            - 'treeitem "CSS property name: --container-3xl : CSS property value: 48rem;" [ref=e1114]':
                              - text: "--container-3xl"
                              - generic [ref=e1115]: ":"
                              - 'generic "CSS property value: 48rem" [ref=e1116]': 48rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xs : CSS property value: 0.75rem;" [ref=e1117]':
                              - text: "--text-xs"
                              - generic [ref=e1118]: ":"
                              - 'generic "CSS property value: 0.75rem" [ref=e1119]': 0.75rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xs--line-height : CSS property value: calc(1 / 0.75);" [ref=e1120]':
                              - text: "--text-xs--line-height"
                              - generic [ref=e1121]: ":"
                              - 'generic "CSS property value: calc(1 / 0.75)" [ref=e1122]':
                                - generic [ref=e1123]:
                                  - generic [ref=e1124]: calc
                                  - text: (
                                  - generic [ref=e1125]:
                                    - generic [ref=e1126]: "1"
                                    - generic [ref=e1127]: /
                                    - generic [ref=e1128]: "0.75"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-sm : CSS property value: 0.875rem;" [ref=e1129]':
                              - text: "--text-sm"
                              - generic [ref=e1130]: ":"
                              - 'generic "CSS property value: 0.875rem" [ref=e1131]': 0.875rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-sm--line-height : CSS property value: calc(1.25 / 0.875);" [ref=e1132]':
                              - text: "--text-sm--line-height"
                              - generic [ref=e1133]: ":"
                              - 'generic "CSS property value: calc(1.25 / 0.875)" [ref=e1134]':
                                - generic [ref=e1135]:
                                  - generic [ref=e1136]: calc
                                  - text: (
                                  - generic [ref=e1137]:
                                    - generic [ref=e1138]: "1.25"
                                    - generic [ref=e1139]: /
                                    - generic [ref=e1140]: "0.875"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-base : CSS property value: 1rem;" [ref=e1141]':
                              - text: "--text-base"
                              - generic [ref=e1142]: ":"
                              - 'generic "CSS property value: 1rem" [ref=e1143]': 1rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-base--line-height : CSS property value: calc(1.5 / 1);" [ref=e1144]':
                              - text: "--text-base--line-height"
                              - generic [ref=e1145]: ":"
                              - 'generic "CSS property value: calc(1.5 / 1)" [ref=e1146]':
                                - generic [ref=e1147]:
                                  - generic [ref=e1148]: calc
                                  - text: (
                                  - generic [ref=e1149]:
                                    - generic [ref=e1150]: "1.5"
                                    - generic [ref=e1151]: /
                                    - generic [ref=e1152]: "1"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-lg : CSS property value: 1.125rem;" [ref=e1153]':
                              - text: "--text-lg"
                              - generic [ref=e1154]: ":"
                              - 'generic "CSS property value: 1.125rem" [ref=e1155]': 1.125rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-lg--line-height : CSS property value: calc(1.75 / 1.125);" [ref=e1156]':
                              - text: "--text-lg--line-height"
                              - generic [ref=e1157]: ":"
                              - 'generic "CSS property value: calc(1.75 / 1.125)" [ref=e1158]':
                                - generic [ref=e1159]:
                                  - generic [ref=e1160]: calc
                                  - text: (
                                  - generic [ref=e1161]:
                                    - generic [ref=e1162]: "1.75"
                                    - generic [ref=e1163]: /
                                    - generic [ref=e1164]: "1.125"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-xl : CSS property value: 1.25rem;" [ref=e1165]':
                              - text: "--text-xl"
                              - generic [ref=e1166]: ":"
                              - 'generic "CSS property value: 1.25rem" [ref=e1167]': 1.25rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-xl--line-height : CSS property value: calc(1.75 / 1.25);" [ref=e1168]':
                              - text: "--text-xl--line-height"
                              - generic [ref=e1169]: ":"
                              - 'generic "CSS property value: calc(1.75 / 1.25)" [ref=e1170]':
                                - generic [ref=e1171]:
                                  - generic [ref=e1172]: calc
                                  - text: (
                                  - generic [ref=e1173]:
                                    - generic [ref=e1174]: "1.75"
                                    - generic [ref=e1175]: /
                                    - generic [ref=e1176]: "1.25"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-2xl : CSS property value: 1.5rem;" [ref=e1177]':
                              - text: "--text-2xl"
                              - generic [ref=e1178]: ":"
                              - 'generic "CSS property value: 1.5rem" [ref=e1179]': 1.5rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-2xl--line-height : CSS property value: calc(2 / 1.5);" [ref=e1180]':
                              - text: "--text-2xl--line-height"
                              - generic [ref=e1181]: ":"
                              - 'generic "CSS property value: calc(2 / 1.5)" [ref=e1182]':
                                - generic [ref=e1183]:
                                  - generic [ref=e1184]: calc
                                  - text: (
                                  - generic [ref=e1185]:
                                    - generic [ref=e1186]: "2"
                                    - generic [ref=e1187]: /
                                    - generic [ref=e1188]: "1.5"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --text-3xl : CSS property value: 1.875rem;" [ref=e1189]':
                              - text: "--text-3xl"
                              - generic [ref=e1190]: ":"
                              - 'generic "CSS property value: 1.875rem" [ref=e1191]': 1.875rem
                              - text: ;
                            - 'treeitem "CSS property name: --text-3xl--line-height : CSS property value: calc(2.25 / 1.875);" [ref=e1192]':
                              - text: "--text-3xl--line-height"
                              - generic [ref=e1193]: ":"
                              - 'generic "CSS property value: calc(2.25 / 1.875)" [ref=e1194]':
                                - generic [ref=e1195]:
                                  - generic [ref=e1196]: calc
                                  - text: (
                                  - generic [ref=e1197]:
                                    - generic [ref=e1198]: "2.25"
                                    - generic [ref=e1199]: /
                                    - generic [ref=e1200]: "1.875"
                                  - text: )
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-normal : CSS property value: 400;" [ref=e1201]':
                              - text: "--font-weight-normal"
                              - generic [ref=e1202]: ":"
                              - 'generic "CSS property value: 400" [ref=e1203]': "400"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-medium : CSS property value: 500;" [ref=e1204]':
                              - text: "--font-weight-medium"
                              - generic [ref=e1205]: ":"
                              - 'generic "CSS property value: 500" [ref=e1206]': "500"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-semibold : CSS property value: 600;" [ref=e1207]':
                              - text: "--font-weight-semibold"
                              - generic [ref=e1208]: ":"
                              - 'generic "CSS property value: 600" [ref=e1209]': "600"
                              - text: ;
                            - 'treeitem "CSS property name: --font-weight-bold : CSS property value: 700;" [ref=e1210]':
                              - text: "--font-weight-bold"
                              - generic [ref=e1211]: ":"
                              - 'generic "CSS property value: 700" [ref=e1212]': "700"
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-normal : CSS property value: 0em;" [ref=e1213]':
                              - text: "--tracking-normal"
                              - generic [ref=e1214]: ":"
                              - 'generic "CSS property value: 0em" [ref=e1215]': 0em
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-wider : CSS property value: 0.05em;" [ref=e1216]':
                              - text: "--tracking-wider"
                              - generic [ref=e1217]: ":"
                              - 'generic "CSS property value: 0.05em" [ref=e1218]': 0.05em
                              - text: ;
                            - 'treeitem "CSS property name: --tracking-widest : CSS property value: 0.1em;" [ref=e1219]':
                              - text: "--tracking-widest"
                              - generic [ref=e1220]: ":"
                              - 'generic "CSS property value: 0.1em" [ref=e1221]': 0.1em
                              - text: ;
                            - 'treeitem "CSS property name: --leading-tight : CSS property value: 1.25;" [ref=e1222]':
                              - text: "--leading-tight"
                              - generic [ref=e1223]: ":"
                              - 'generic "CSS property value: 1.25" [ref=e1224]': "1.25"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-snug : CSS property value: 1.375;" [ref=e1225]':
                              - text: "--leading-snug"
                              - generic [ref=e1226]: ":"
                              - 'generic "CSS property value: 1.375" [ref=e1227]': "1.375"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-normal : CSS property value: 1.5;" [ref=e1228]':
                              - text: "--leading-normal"
                              - generic [ref=e1229]: ":"
                              - 'generic "CSS property value: 1.5" [ref=e1230]': "1.5"
                              - text: ;
                            - 'treeitem "CSS property name: --leading-relaxed : CSS property value: 1.625;" [ref=e1231]':
                              - text: "--leading-relaxed"
                              - generic [ref=e1232]: ":"
                              - 'generic "CSS property value: 1.625" [ref=e1233]': "1.625"
                              - text: ;
                            - 'treeitem "CSS property name: --radius-sm : CSS property value: 0.25rem;" [ref=e1234]':
                              - text: "--radius-sm"
                              - generic [ref=e1235]: ":"
                              - 'generic "CSS property value: 0.25rem" [ref=e1236]': 0.25rem
                              - text: ;
                          - button "Show all properties (15 more)" [ref=e1237]
                          - generic [ref=e1238]: "}"
                      - generic [ref=e1239]: Pseudo ::before element
                      - generic [ref=e1240]:
                        - generic [ref=e1241]: Layer
                        - button "base" [ref=e1242] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e1243]:
                        - link "index.css:144" [ref=e1245] [cursor=pointer]
                        - generic [ref=e1246]:
                          - generic [ref=e1248]:
                            - generic "CSS selector" [ref=e1249]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e1252]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1253]':
                              - text: box-sizing
                              - generic [ref=e1254]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1255]': border-box
                              - text: ;
                          - generic [ref=e1256]: "}"
                      - generic [ref=e1257]:
                        - generic [ref=e1258]: Layer
                        - button "base" [ref=e1259] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1260]:
                        - link "index.css:542" [ref=e1262] [cursor=pointer]
                        - generic [ref=e1263]:
                          - generic [ref=e1265]:
                            - generic "CSS selector" [ref=e1266]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1269]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1270]':
                              - text: box-sizing
                              - generic [ref=e1271]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1272]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1273]':
                              - text: margin
                              - generic [ref=e1274]: ":"
                              - 'generic "CSS property value: 0" [ref=e1276]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1277]':
                              - text: padding
                              - generic [ref=e1278]: ":"
                              - 'generic "CSS property value: 0" [ref=e1280]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1281]':
                              - text: border
                              - generic [ref=e1282]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1284]': 0 solid
                              - text: ;
                          - generic [ref=e1285]: "}"
                      - generic [ref=e1286]: Pseudo ::after element
                      - generic [ref=e1287]:
                        - generic [ref=e1288]: Layer
                        - button "base" [ref=e1289] [cursor=pointer]
                      - listitem "*, *::before, *::after, css selector" [ref=e1290]:
                        - link "index.css:144" [ref=e1292] [cursor=pointer]
                        - generic [ref=e1293]:
                          - generic [ref=e1295]:
                            - generic "CSS selector" [ref=e1296]: "*, *::before, *::after"
                            - text: "{"
                          - tree [ref=e1299]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1300]':
                              - text: box-sizing
                              - generic [ref=e1301]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1302]': border-box
                              - text: ;
                          - generic [ref=e1303]: "}"
                      - generic [ref=e1304]:
                        - generic [ref=e1305]: Layer
                        - button "base" [ref=e1306] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1307]:
                        - link "index.css:542" [ref=e1309] [cursor=pointer]
                        - generic [ref=e1310]:
                          - generic [ref=e1312]:
                            - generic "CSS selector" [ref=e1313]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1316]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1317]':
                              - text: box-sizing
                              - generic [ref=e1318]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1319]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1320]':
                              - text: margin
                              - generic [ref=e1321]: ":"
                              - 'generic "CSS property value: 0" [ref=e1323]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1324]':
                              - text: padding
                              - generic [ref=e1325]: ":"
                              - 'generic "CSS property value: 0" [ref=e1327]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1328]':
                              - text: border
                              - generic [ref=e1329]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1331]': 0 solid
                              - text: ;
                          - generic [ref=e1332]: "}"
                      - generic [ref=e1333]: Pseudo ::backdrop element
                      - generic [ref=e1334]:
                        - generic [ref=e1335]: Layer
                        - button "base" [ref=e1336] [cursor=pointer]
                      - listitem "*, ::after, ::before, ::backdrop, ::file-selector-button, css selector" [ref=e1337]:
                        - link "index.css:542" [ref=e1339] [cursor=pointer]
                        - generic [ref=e1340]:
                          - generic [ref=e1342]:
                            - generic "CSS selector" [ref=e1343]: "*, ::after, ::before, ::backdrop, ::file-selector-button"
                            - text: "{"
                          - tree [ref=e1346]:
                            - 'treeitem "CSS property name: box-sizing : CSS property value: border-box;" [ref=e1347]':
                              - text: box-sizing
                              - generic [ref=e1348]: ":"
                              - 'generic "CSS property value: border-box" [ref=e1349]': border-box
                              - text: ;
                            - 'treeitem "CSS property name: margin : CSS property value: 0;" [ref=e1350]':
                              - text: margin
                              - generic [ref=e1351]: ":"
                              - 'generic "CSS property value: 0" [ref=e1353]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: padding : CSS property value: 0;" [ref=e1354]':
                              - text: padding
                              - generic [ref=e1355]: ":"
                              - 'generic "CSS property value: 0" [ref=e1357]': "0"
                              - text: ;
                            - 'treeitem "CSS property name: border : CSS property value: 0 solid;" [ref=e1358]':
                              - text: border
                              - generic [ref=e1359]: ":"
                              - 'generic "CSS property value: 0 solid" [ref=e1361]': 0 solid
                              - text: ;
                          - generic [ref=e1362]: "}"
                      - generic [ref=e1363]: Pseudo ::scrollbar element
                      - generic [ref=e1364]:
                        - generic [ref=e1365]: Layer
                        - button "base" [ref=e1366] [cursor=pointer]
                      - listitem "::-webkit-scrollbar, css selector" [ref=e1367]:
                        - link "index.css:231" [ref=e1369] [cursor=pointer]
                        - generic [ref=e1370]:
                          - generic [ref=e1372]:
                            - generic "CSS selector" [ref=e1373]: ::-webkit-scrollbar
                            - text: "{"
                          - tree [ref=e1376]:
                            - 'treeitem "CSS property name: width : CSS property value: 6px;" [ref=e1377]':
                              - text: width
                              - generic [ref=e1378]: ":"
                              - 'generic "CSS property value: 6px" [ref=e1379]': 6px
                              - text: ;
                            - 'treeitem "CSS property name: height : CSS property value: 6px;" [ref=e1380]':
                              - text: height
                              - generic [ref=e1381]: ":"
                              - 'generic "CSS property value: 6px" [ref=e1382]': 6px
                              - text: ;
                          - generic [ref=e1383]: "}"
                      - generic [ref=e1384]: Pseudo ::scrollbar-thumb element
                      - generic [ref=e1385]:
                        - generic [ref=e1386]: Layer
                        - button "base" [ref=e1387] [cursor=pointer]
                      - listitem ":hover::-webkit-scrollbar-thumb:hover, css selector" [ref=e1388]:
                        - link "index.css:250" [ref=e1390] [cursor=pointer]
                        - generic [ref=e1391]:
                          - generic [ref=e1393]:
                            - generic "CSS selector" [ref=e1394]: :hover::-webkit-scrollbar-thumb:hover
                            - text: "{"
                          - tree [ref=e1397]:
                            - 'treeitem "CSS property name: background : CSS property value: rgb(var(--ctp-surface2));" [ref=e1398]':
                              - text: background
                              - generic [ref=e1399]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-surface2))" [ref=e1401]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1403]:
                                  - generic [ref=e1404] [cursor=pointer]
                                - generic [ref=e1405]:
                                  - generic [ref=e1406]: rgb
                                  - text: (
                                  - generic [ref=e1408]:
                                    - generic [ref=e1409]: var
                                    - text: (
                                    - link "--ctp-surface2" [ref=e1411] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e1412]: "}"
                      - generic [ref=e1413]:
                        - generic [ref=e1414]: Layer
                        - button "base" [ref=e1415] [cursor=pointer]
                      - listitem ":hover::-webkit-scrollbar-thumb, css selector" [ref=e1416]:
                        - link "index.css:246" [ref=e1418] [cursor=pointer]
                        - generic [ref=e1419]:
                          - generic [ref=e1421]:
                            - generic "CSS selector" [ref=e1422]: :hover::-webkit-scrollbar-thumb
                            - text: "{"
                          - tree [ref=e1425]:
                            - 'treeitem "CSS property name: background : CSS property value: rgb(var(--ctp-surface1));" [ref=e1426]':
                              - text: background
                              - generic [ref=e1427]: ":"
                              - 'generic "CSS property value: rgb(var(--ctp-surface1))" [ref=e1429]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1431]:
                                  - generic [ref=e1432] [cursor=pointer]
                                - generic [ref=e1433]:
                                  - generic [ref=e1434]: rgb
                                  - text: (
                                  - generic [ref=e1436]:
                                    - generic [ref=e1437]: var
                                    - text: (
                                    - link "--ctp-surface1" [ref=e1439] [cursor=pointer]
                                    - text: )
                                  - text: )
                              - text: ;
                          - generic [ref=e1440]: "}"
                      - generic [ref=e1441]:
                        - generic [ref=e1442]: Layer
                        - button "base" [ref=e1443] [cursor=pointer]
                      - listitem "::-webkit-scrollbar-thumb, css selector" [ref=e1444]:
                        - link "index.css:240" [ref=e1446] [cursor=pointer]
                        - generic [ref=e1447]:
                          - generic [ref=e1449]:
                            - generic "CSS selector" [ref=e1450]: ::-webkit-scrollbar-thumb
                            - text: "{"
                          - tree [ref=e1453]:
                            - 'treeitem "CSS property name: background : CSS property value: transparent;" [ref=e1454]':
                              - text: background
                              - generic [ref=e1455]: ":"
                              - 'generic "CSS property value: transparent" [ref=e1457]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1459]:
                                  - generic [ref=e1460] [cursor=pointer]
                                - text: transparent
                              - text: ;
                            - 'treeitem "CSS property name: border-radius : CSS property value: 3px;" [ref=e1461]':
                              - text: border-radius
                              - generic [ref=e1462]: ":"
                              - 'generic "CSS property value: 3px" [ref=e1464]': 3px
                              - text: ;
                            - 'treeitem "CSS property name: transition : CSS property value: background 0.2s ease;" [ref=e1465]':
                              - text: transition
                              - generic [ref=e1466]: ":"
                              - 'generic "CSS property value: background 0.2s ease" [ref=e1468]':
                                - text: background 0.2s
                                - generic [ref=e1469]:
                                  - generic "Open cubic bezier editor" [ref=e1470]
                                  - text: ease
                              - text: ;
                          - generic [ref=e1472]: "}"
                      - generic [ref=e1473]: Pseudo ::scrollbar-track element
                      - generic [ref=e1474]:
                        - generic [ref=e1475]: Layer
                        - button "base" [ref=e1476] [cursor=pointer]
                      - listitem "::-webkit-scrollbar-track, css selector" [ref=e1477]:
                        - link "index.css:236" [ref=e1479] [cursor=pointer]
                        - generic [ref=e1480]:
                          - generic [ref=e1482]:
                            - generic "CSS selector" [ref=e1483]: ::-webkit-scrollbar-track
                            - text: "{"
                          - tree [ref=e1486]:
                            - 'treeitem "CSS property name: background : CSS property value: transparent;" [ref=e1487]':
                              - text: background
                              - generic [ref=e1488]: ":"
                              - 'generic "CSS property value: transparent" [ref=e1490]':
                                - generic "Open color picker. Shift + Click to change color format" [ref=e1492]:
                                  - generic [ref=e1493] [cursor=pointer]
                                - text: transparent
                              - text: ;
                          - generic [ref=e1494]: "}"
                      - generic [ref=e1495]: "@property"
                  - generic [ref=e1499]:
                    - generic [ref=e1500]: margin
                    - generic [ref=e1501]: "0"
                    - generic [ref=e1502]: "0"
                    - generic [ref=e1503]:
                      - generic [ref=e1504]: border
                      - generic [ref=e1505]: "0"
                      - generic [ref=e1506]: "0"
                      - generic [ref=e1507]:
                        - generic [ref=e1508]: padding
                        - generic [ref=e1509]: "0"
                        - generic [ref=e1510]: "0"
                        - generic [ref=e1511]:
                          - generic [ref=e1512]: "1280"
                          - generic [ref=e1513]: ×
                          - generic [ref=e1514]: "900"
                        - generic [ref=e1515]: "0"
                        - generic [ref=e1516]: "0"
                      - generic [ref=e1517]: "0"
                      - generic [ref=e1518]: "0"
                    - generic [ref=e1519]: "0"
                    - generic [ref=e1520]: "0"
  - alert [ref=e1522]: DevTools is undocked
  - status
```

# Test source

```ts
  308 |   const connect = w.locator('[data-testid="dispatcher-card-switch"]');
  309 |   await expect(connect).toBeVisible();
  310 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  311 |   await connect.click();
  312 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(false);
  313 |   await connect.click();
  314 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  315 | 
  316 |   // The wire comes back after a restart.
  317 |   await app!.electronApp.close();
  318 |   w = (await launch()).window;
  319 |   await expect(row(w)).toBeVisible({ timeout: 15_000 });
  320 |   await expect.poll(() => hasWire(w, dispatcherId), { timeout: 15_000 }).toBe(true);
  321 | 
  322 |   // Turning the setting off drops the row and wires and keeps the folder and its memory.
  323 |   fs.writeFileSync(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'kept\n');
  324 |   // An old notes/ folder, as the agent kept before memory (#3038).
  325 |   fs.mkdirSync(path.join(dispatcherDir(), 'notes'), { recursive: true });
  326 |   fs.writeFileSync(path.join(dispatcherDir(), 'notes', 'release.md'), 'old note\n');
  327 |   await openSettingsPage(w, 'Dispatcher');
  328 |   await w.locator('[data-testid="dispatcher-enabled"]').click();
  329 |   await expect(row(w)).toHaveCount(0);
  330 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(false);
  331 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'utf8')).toBe('kept\n');
  332 |   await w.locator('[data-testid="dispatcher-enabled"]').click();
  333 |   await expect(row(w)).toBeVisible();
  334 |   // Turning it on sorts the old notes into memory once and keeps the folder, renamed.
  335 |   await expect.poll(() => fs.existsSync(path.join(dispatcherDir(), 'notes'))).toBe(false);
  336 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'notes-archive', 'release.md'), 'utf8')).toBe('old note\n');
  337 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'release.md'), 'utf8')).toMatch(/old note\n$/);
  338 |   expect(await fs.promises.readFile(path.join(dispatcherDir(), 'memory', 'topics', 'plan.md'), 'utf8')).toBe('kept\n');
  339 |   expect(await dispatcherIds()).toEqual([dispatcherId]);
  340 |   await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  341 | 
  342 |   // Start it from its view.
  343 |   await closeSettings(w);
  344 |   await rowItem(w).click();
  345 |   await w.locator('[data-testid="dispatcher-view"] [data-testid="wake-button"]').click();
  346 |   await expect.poll(startedAs, { timeout: 20_000 }).toBe((await chatConfigs())[0].id);
  347 |   // Waking it from its view keeps the view, with its chat, and no project in the title (#2563).
  348 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible({ timeout: 15_000 });
  349 |   await expect(w.locator('[data-testid="title-bar"]')).toContainText('Dispatcher');
  350 |   await expect(w.locator('[data-testid="title-bar"]')).not.toContainText('dispatcher-e2e-');
  351 | 
  352 |   // Its composer has one Behavior chip in place of the model and permission pickers (#3045).
  353 |   const view = w.locator('[data-testid="dispatcher-view"]');
  354 |   const chip = view.locator('[data-testid="dispatcher-behavior-chip"]');
  355 |   await expect(chip).toHaveAttribute('data-level', 'standard', { timeout: 15_000 });
  356 |   await expect(view.locator('[data-testid="chat-model-pill"]')).toHaveCount(0);
  357 |   await expect(view.locator('[data-testid="chat-level-pill"]')).toHaveCount(0);
  358 |   // Thorough keeps the chat on the same tier as Standard, so the running chat
  359 |   // isn't switched: this fixture replays a strict script with no model change here.
  360 |   await chip.click();
  361 |   await view.locator('[data-testid="dispatcher-behavior-thorough"]').click();
  362 |   await expect(chip).toHaveAttribute('data-level', 'thorough');
  363 |   await expect(view.locator('[data-testid="dispatcher-behavior-menu"]')).toHaveCount(0);
  364 |   // Settings shows the same choice.
  365 |   await openSettingsPage(w, 'Dispatcher');
  366 |   await expect(w.locator('[data-testid="dispatcher-behavior"]')).toHaveValue('thorough');
  367 | 
  368 |   // Clear chat (#3043) from its menu asks first, starts the conversation over and leaves memory alone.
  369 |   await closeSettings(w);
  370 |   await rowItem(w).click();
  371 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible({ timeout: 15_000 });
  372 |   const memoryFiles = ['index.md', 'topics/plan.md', 'topics/release.md'].map((f) => path.join(dispatcherDir(), 'memory', f));
  373 |   const memoryBefore = await Promise.all(memoryFiles.map((f) => fs.promises.readFile(f, 'utf8')));
  374 |   await rowItem(w).click({ button: 'right' });
  375 |   await w.locator('[data-testid="agent-context-menu"] [data-testid="ctx-clear-chat"]').click();
  376 |   await expect(w.locator('[data-testid="dispatcher-clear-chat-confirm"]')).toBeVisible();
  377 |   await w.locator('[data-testid="dispatcher-clear-chat-confirm-button"]').click();
  378 |   await expect(w.locator('[data-testid="dispatcher-clear-chat-confirm"]')).toHaveCount(0, { timeout: 15_000 });
  379 |   await expect(w.locator('[data-testid="dispatcher-view"] [data-testid="chat-view"]')).toBeVisible();
  380 |   expect(await Promise.all(memoryFiles.map((f) => fs.promises.readFile(f, 'utf8')))).toEqual(memoryBefore);
  381 | });
  382 | 
  383 | test('the Dispatcher wakes a connected agent with a message and sleeps it again', async () => {
  384 |   projectDir = makeProject();
  385 |   const fixtureDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dispatcher-e2e-fixture-'));
  386 |   try {
  387 |     fakes = await installFakeClis({ claude: await writeQuietFixture(fixtureDir) });
  388 |     profile = createDisposableProfile({ label: 'dispatcher-wake' });
  389 |     const w = (await launch()).window;
  390 | 
  391 |     await expect(row(w)).toBeVisible({ timeout: 15_000 });
  392 |     await expect.poll(async () => (await dispatcherConfigs()).length).toBe(1);
  393 |     const dispatcherId = (await dispatcherConfigs())[0].id;
  394 | 
  395 |     await addProject(app!.electronApp, w, projectDir);
  396 |     // An orchestrator is connected by default (#2578).
  397 |     await openDispatcherCard(w);
  398 |     await expect(w.locator('[data-testid="dispatcher-card-switch"]')).toHaveAttribute('aria-checked', 'true');
  399 |     await expect.poll(() => hasWire(w, dispatcherId)).toBe(true);
  400 | 
  401 |     // Start the Dispatcher. The fake reports the bridge credentials it was given.
  402 |     const { mcp } = await startDispatcher(w, dispatcherId);
  403 | 
  404 |     const toolFor = (names: string[], suffix: string) => names.find((n) => n.endsWith(`__${suffix}`) && n.includes('conductor'));
  405 | 
  406 |     // #3656 item 4: a sleeping LOCAL wire lists send_message, but sending never auto-wakes it.
  407 |     const asleep = await mcp.toolNames();
> 408 |     expect(toolFor(asleep, 'get_status')).toBeTruthy();
      |                                           ^ Error: expect(received).toBeTruthy()
  409 |     expect(toolFor(asleep, 'send_message')).toBeTruthy();
  410 |     expect(toolFor(asleep, 'sleep_agent')).toBeUndefined();
  411 |     const sleepingSend = await mcp.callText(toolFor(asleep, 'send_message')!, { message: 'stay asleep until explicitly woken' });
  412 |     expect(sleepingSend.isError).toBe(true);
  413 |     expect(sleepingSend.text).toContain(`Agent ${ORCHESTRATOR_ID} is sleeping.`);
  414 |     expect((await mcp.call(toolFor(asleep, 'get_status')!)).body).toMatchObject({ status: 'sleeping', running: false });
  415 |     expect(await startedAs()).toBe(dispatcherId); // No target CLI was started by send_message.
  416 | 
  417 |     // Wake with a message, which reaches the CLI as the first prompt.
  418 |     const woken = await mcp.call(toolFor(asleep, 'wake_agent')!, { message: 'first prompt from dispatcher' });
  419 |     expect(woken.isError).toBe(false);
  420 |     expect(woken.body).toMatchObject({ status: 'running', messageDelivered: true });
  421 |     await expect.poll(async () => {
  422 |       const report = await fakes!.report('claude').catch((): undefined => undefined);
  423 |       return report?.env.CLUBHOUSE_AGENT_ID === ORCHESTRATOR_ID && JSON.stringify(report.unexpected).includes('first prompt from dispatcher');
  424 |     }, { timeout: 20_000 }).toBe(true);
  425 | 
  426 |     // Awake: sleep_agent instead of wake_agent.
  427 |     const awake = await mcp.toolNames();
  428 |     expect(toolFor(awake, 'wake_agent')).toBeUndefined();
  429 |     const sleepTool = toolFor(awake, 'sleep_agent')!;
  430 |     expect(sleepTool).toBeTruthy();
  431 | 
  432 |     // The fake never answers, so it is mid-turn: refused without force.
  433 |     const refused = await mcp.call(sleepTool);
  434 |     expect(refused.isError).toBe(true);
  435 |     expect(refused.body).toMatchObject({ status: 'refused', reason: 'mid_turn' });
  436 |     expect(((await mcp.call(toolFor(awake, 'get_status')!)).body as { running: boolean }).running).toBe(true);
  437 | 
  438 |     const slept = await mcp.call(sleepTool, { force: true });
  439 |     expect((slept.body as { status: string }).status).toBe('sleeping');
  440 |     expect(((await mcp.call(toolFor(awake, 'get_status')!)).body as { running: boolean }).running).toBe(false);
  441 |     expect(toolFor(await mcp.toolNames(), 'wake_agent')).toBeTruthy();
  442 |   } finally {
  443 |     await fs.promises.rm(fixtureDir, { recursive: true, force: true, maxRetries: 20, retryDelay: 100 });
  444 |   }
  445 | });
  446 | 
  447 | test('an Ask-first call waits in Needs you, and goes through once the user allows it (#2970)', async () => {
  448 |   const fixtureDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dispatcher-e2e-fixture-'));
  449 |   try {
  450 |     fakes = await installFakeClis({ claude: await writeQuietFixture(fixtureDir) });
  451 |     profile = createDisposableProfile({ label: 'dispatcher-ask-first' });
  452 |     const w = (await launch()).window;
  453 | 
  454 |     await expect(row(w)).toBeVisible({ timeout: 15_000 });
  455 |     await expect.poll(async () => (await dispatcherConfigs()).length).toBe(1);
  456 |     const dispatcherId = (await dispatcherConfigs())[0].id;
  457 | 
  458 |     const { chatId, mcp } = await startDispatcher(w, dispatcherId);
  459 | 
  460 |     // Changing app settings is Ask first for the Dispatcher: the tool is offered, and the call asks.
  461 |     expect(await mcp.toolNames()).toContain('set_helper_presets');
  462 |     const { revision } = (await mcp.call('read_helper_presets')).body as { revision: number };
  463 |     const args = { revision, reset: {} };
  464 |     const asked = await mcp.callText('set_helper_presets', args);
  465 |     expect(asked.isError).toBe(true);
  466 |     expect(asked.text).toContain('needs the user\'s approval');
  467 | 
  468 |     // It waits in Needs you, on the Dispatcher's own row; selecting it opens the request, and the user allows it.
  469 |     await expect(w.locator(`[data-testid="needs-you-row-${dispatcherId}"]`)).toHaveCount(0);
  470 |     const needsRow = w.locator(`[data-testid="needs-you-row-${chatId}"]`);
  471 |     await expect(needsRow).toBeVisible({ timeout: 10_000 });
  472 |     await expect(needsRow).toContainText('Change app settings');
  473 |     await needsRow.click();
  474 |     const dialog = w.locator('[data-testid="grant-request-dialog"]');
  475 |     await expect(dialog).toContainText('set_helper_presets');
  476 |     await dialog.locator('[data-testid="grant-request-allow"]').click();
  477 |     await expect(dialog).toBeHidden();
  478 |     await expect(needsRow).toBeHidden();
  479 | 
  480 |     // The same call now goes through, once.
  481 |     const done = await mcp.call('set_helper_presets', args);
  482 |     expect(done.isError).toBe(false);
  483 |     expect(done.body).toMatchObject({ ok: true });
  484 |     expect((await mcp.callText('set_helper_presets', { revision: (done.body as { revision: number }).revision, reset: {} })).text).toContain('needs the user\'s approval');
  485 |   } finally {
  486 |     await fs.promises.rm(fixtureDir, { recursive: true, force: true, maxRetries: 20, retryDelay: 100 });
  487 |   }
  488 | });
  489 | 
  490 | /**
  491 |  * The popout window the next createPopout opens. Unpackaged builds may open
  492 |  * DevTools first, so a window without the popout's root is skipped.
  493 |  */
  494 | async function nextPopout(electronApp: ElectronApp, open: () => Promise<void>): Promise<Page> {
  495 |   const seen = new Set(electronApp.windows());
  496 |   const first = electronApp.waitForEvent('window', { predicate: (p) => !seen.has(p), timeout: 15_000 });
  497 |   await open();
  498 |   let page = await first;
  499 |   await page.waitForLoadState('load');
  500 |   if (!(await page.locator('[data-testid="popout-window"]').isVisible({ timeout: 5_000 }).catch(() => false))) {
  501 |     seen.add(page);
  502 |     page = await electronApp.waitForEvent('window', { predicate: (p) => !seen.has(p), timeout: 10_000 });
  503 |     await page.waitForLoadState('load');
  504 |   }
  505 |   return page;
  506 | }
  507 | 
  508 | test('Pop Out shows its chat in its own window, where the user keeps talking to it (#3235)', async () => {
```