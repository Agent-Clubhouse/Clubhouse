# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: annex-v2/agents-across-machines.spec.ts >> a sender crash after a durable200 replays the same identity once, then preserves FIFO and file bytes
- Location: e2e/annex-v2/agents-across-machines.spec.ts:304:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - button "Hide sidebar" [pressed] [ref=e5] [cursor=pointer]
    - tablist "Project tabs" [ref=e9]:
      - tab "Agents" [selected] [ref=e10] [cursor=pointer]
      - tab "Terminal" [ref=e17] [cursor=pointer]
      - tab "Files" [ref=e22] [cursor=pointer]
      - tab "Browser" [ref=e27] [cursor=pointer]
      - tab "Canvas" [ref=e33] [cursor=pointer]
      - tab "Review" [ref=e41] [cursor=pointer]
    - generic [ref=e49]:
      - generic [ref=e50]: sender-project
      - generic [aria-hidden] [ref=e51]: /
      - generic [ref=e52]: Agents
  - generic [ref=e54]:
    - generic [ref=e57]: No git repository detected. Some features may not be available.
    - button "git init" [ref=e58] [cursor=pointer]
    - button "x" [ref=e59] [cursor=pointer]
  - generic [ref=e60]:
    - complementary "Sidebar" [ref=e62]:
      - button "Show All computers" [ref=e65] [cursor=pointer]:
        - generic [ref=e66]: All computers
      - generic [ref=e70]:
        - textbox "Filter projects and agents" [ref=e72]:
          - /placeholder: Filter
        - button "Command palette" [ref=e73] [cursor=pointer]: Ctrl K
        - button "New agent" [ref=e75] [cursor=pointer]: New
      - navigation "App views" [ref=e78]:
        - button "Canvas" [ref=e79] [cursor=pointer]
        - button "Review" [ref=e86] [cursor=pointer]
        - button "Group Projects" [ref=e92] [cursor=pointer]
      - generic [ref=e98]:
        - tree "Dispatcher" [ref=e99]:
          - treeitem "Dispatcher" [level=1] [ref=e101] [cursor=pointer]:
            - img "Sleeping" [ref=e102]
            - generic [ref=e103]: D
            - img "Claude Code" [ref=e107]: C
        - tree "Dispatcher on Studio" [ref=e108]:
          - treeitem "Dispatcher on Studio" [level=1] [ref=e110] [cursor=pointer]:
            - img "Done" [ref=e111]
            - generic [ref=e112]: D
          - treeitem "Dispatcher controller (online)" [level=2] [ref=e117] [cursor=pointer]:
            - img "Done" [ref=e118]
            - generic [aria-hidden] [ref=e119]: D
            - generic [ref=e120]: Dispatcher controller
            - generic [ref=e121]: online
      - region "Projects" [ref=e123]:
        - generic [ref=e124]:
          - generic [ref=e125]: Projects
          - generic [ref=e126]: "1"
          - button "Projects order" [ref=e127] [cursor=pointer]
          - button "Collapse all projects" [ref=e130] [cursor=pointer]
        - tree "Projects and agents" [ref=e133]:
          - generic [ref=e134]:
            - treeitem "sender-project" [expanded] [level=1] [ref=e135]:
              - button "Collapse sender-project" [ref=e136] [cursor=pointer]
              - button "sender-project" [ref=e139] [cursor=pointer]:
                - generic [aria-hidden] [ref=e140]: S
            - treeitem "durable-sender" [level=2] [ref=e144] [cursor=pointer]:
              - img "Done" [ref=e145]
              - generic [ref=e146]: DS
              - img "Claude Code" [ref=e150]: C
      - generic [ref=e151]:
        - button "Add project" [ref=e152] [cursor=pointer]
        - button "Help" [ref=e155] [cursor=pointer]
        - button "Settings" [ref=e159] [cursor=pointer]
    - generic [ref=e166]:
      - generic [ref=e167]:
        - generic [ref=e168]: sender-project
        - generic [ref=e169]: project root
        - radiogroup "Project view" [ref=e170]:
          - radio "Overview" [checked] [ref=e171]
          - radio "Changes" [ref=e172]
      - generic [ref=e176]:
        - generic [ref=e177]:
          - heading "sender-project" [level=1] [ref=e178]
          - generic [ref=e179]: /tmp/clubhouse-e2e-delivery-crash-LshlTl/sender-project
        - generic [ref=e180]:
          - textbox "What should an agent do in sender-project?" [ref=e181]
          - generic [ref=e182]:
            - combobox "Run as" [ref=e183] [cursor=pointer]:
              - option "New quick agent" [selected]
            - combobox "Model" [ref=e184] [cursor=pointer]:
              - option "Default" [selected]
              - option "Opus"
              - option "Sonnet"
              - option "Haiku"
            - generic [ref=e185]: Ctrl+Enter
            - button "Start" [disabled] [ref=e186]
        - generic [ref=e187]:
          - button "New durable agent…" [ref=e188] [cursor=pointer]
          - button "Project settings" [ref=e189] [cursor=pointer]
          - button "Group projects" [ref=e190] [cursor=pointer]
```

# Test source

```ts
  300 |     return prompts.includes('hello from the other desk') && prompts.includes('on Desk') && prompts.includes('[TASK:across1]');
  301 |   }, { timeout: 30_000 }).toBe(true);
  302 | });
  303 | 
  304 | test('a sender crash after a durable200 replays the same identity once, then preserves FIFO and file bytes', async () => {
  305 |   const info = test.info();
  306 |   scratch = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'clubhouse-e2e-delivery-crash-'));
  307 |   const quiet = await quietFixture(scratch);
  308 |   const receiverFixture = await writeChatScript(scratch, 'receiver', buildChatScript('claude', {
  309 |     description: 'Three actual Annex inputs, with completed token-free turns so later FIFO work can run.',
  310 |     turns: Array.from({ length: 3 }, (_, i) => ({ steps: [{ type: 'text' as const, text: `Fixture accepted input ${i + 1}.` }] })),
  311 |   }));
  312 |   fakesHere = await installFakeClis({ claude: quiet });
  313 |   fakesThere = await installFakeClis({ claude: receiverFixture.fixture });
  314 |   const senderProject = path.join(scratch, 'sender-project');
  315 |   const receiverProject = path.join(scratch, 'receiver-project');
  316 |   await fs.promises.mkdir(senderProject);
  317 |   await fs.promises.mkdir(receiverProject);
  318 |   here = await launchDesktop('crash-sender', fakesHere, 'Desk');
  319 |   there = await launchDesktop('crash-receiver', fakesThere, 'Studio');
  320 |   const senderId = await startAgent(here, senderProject, 'durable-sender');
  321 |   const receiverId = await startAgent(there, receiverProject, 'durable-receiver');
  322 |   const senderReport = await waitForFakeCliRegistration(here, fakesHere, senderId);
  323 |   const oldCliPid = senderReport.pid;
  324 |   const { senderFingerprint, receiverFingerprint } = await pairDesktops(here, there, senderId, receiverId);
  325 |   // Both stores and the authenticated network path must be ready before going offline.
  326 |   await waitForDurableDeliveryPath(here, there, receiverFingerprint);
  327 |   await waitForDurableDeliveryPath(there, here, senderFingerprint);
  328 |   let mcp = await connectMcp(senderReport.env);
  329 |   const send = (await mcp.toolNames()).find((name) => name.endsWith('__send_message'));
  330 |   expect(send).toBeTruthy();
  331 |   // A one-shot disconnect can be undone by discovery or membership reconciliation.
  332 |   // Keep the client off until both durable admissions are persisted and the barrier is armed.
  333 |   await here.window.evaluate(async () => {
  334 |     const settings = await window.clubhouse.annex.getSettings();
  335 |     await window.clubhouse.annex.saveSettings({ ...settings, enableClient: false });
  336 |   });
  337 |   await expect.poll(async () => {
  338 |     return here!.window.evaluate(async () => ({
  339 |       enabled: (await window.clubhouse.annex.getSettings()).enableClient,
  340 |       satellites: (await window.clubhouse.annexClient.getSatellites()).length,
  341 |     }));
  342 |   }, { timeout: 30_000, message: 'Sender client must be stopped before queuing the two offline deliveries' }).toEqual({ enabled: false, satellites: 0 });
  343 |   const firstArgs = { message: 'durable first input', task_id: 'durable-first', idempotency_key: 'durable-first' };
  344 |   const secondArgs = { message: 'durable second input', task_id: 'durable-second', idempotency_key: 'durable-second' };
  345 |   expect((await mcp.call(send!, firstArgs)).text).toContain('delivery_id=');
  346 |   expect((await mcp.call(send!, secondArgs)).text).toContain('delivery_id=');
  347 |   const senderStore = path.join(here.userDataDir, 'annex-agent-outbox.json');
  348 |   const readSender = async (): Promise<DeliveryFile> => JSON.parse(await fs.promises.readFile(senderStore, 'utf8'));
  349 |   const before = await readSender();
  350 |   expect(before.outbox).toHaveLength(2);
  351 |   expect(before.outbox.map((item) => item.body.args.task_id)).toEqual(['durable-first', 'durable-second']);
  352 |   const [firstId, secondId] = before.outbox.map((item) => item.id);
  353 |   const boundaryPath = path.join(scratch, 'delivery-boundary.json');
  354 |   const requestsPath = path.join(scratch, 'received-call-ids.jsonl');
  355 |   await observeDeliveryRequests(there, requestsPath);
  356 |   const senderIdentity = await armDeliveryCommitBarrier(here, firstId, boundaryPath);
  357 |   await here.window.evaluate(async () => {
  358 |     const settings = await window.clubhouse.annex.getSettings();
  359 |     await window.clubhouse.annex.saveSettings({ ...settings, enableClient: true });
  360 |   });
  361 |   await expect.poll(() => fs.existsSync(boundaryPath), { timeout: 30_000 }).toBe(true);
  362 |   const boundary: DeliveryBoundary = JSON.parse(await fs.promises.readFile(boundaryPath, 'utf8'));
  363 |   expect(boundary).toMatchObject({ callId: firstId, status: 200, outboxIds: [firstId, secondId] });
  364 |   expect((await readSender()).deliveries.find((row) => row.callId === firstId)).toMatchObject({ state: 'sending', attempts: 1 });
  365 |   const receiverStore = path.join(there.userDataDir, 'annex-agent-outbox.json');
  366 |   const received: DeliveryFile = JSON.parse(await fs.promises.readFile(receiverStore, 'utf8'));
  367 |   const receipt = received.inbox.find((row) => row.key.endsWith(`/${firstId}`));
  368 |   expect(receipt).toMatchObject({ state: 'delivered', updatedAt: boundary.receiptAt });
  369 |   expect(createHash('sha256').update(JSON.stringify(receipt!.result)).digest('hex')).toBe(boundary.resultHash);
  370 |   const profile = here.profile;
  371 |   const pid = here.electronApp.process().pid;
  372 |   expect(pid).toBe(senderIdentity.launcherPid);
  373 |   expect(boundary.launcherPid).toBe(pid);
  374 |   expect(boundary.pid).toBe(senderIdentity.pid);
  375 |   if (!pid) throw new Error('Owned sender PID is unavailable');
  376 |   const closed = here.electronApp.waitForEvent('close');
  377 |   const child = here.electronApp.process();
  378 |   await Promise.all([closed, killOwnedDesktop(here, child, pid, profile, boundary.pid)]);
  379 |   expect(exited(child)).toBe(true);
  380 |   untrackOpenApp(here.electronApp);
  381 |   here = undefined;
  382 |   const receiverChat = there.window.locator(`[data-testid="chat-view"][data-agent-pane="${receiverId}"][data-view-context="main"]`);
  383 |   await expect(receiverChat).toHaveAttribute('data-state', 'idle');
  384 |   here = await launchApp({ profile, label: 'same-sender-profile', args: ['--disable-gpu'], env: fakesHere.env });
  385 |   expect(here.userDataDir).toBe(profile.userDataDir);
  386 |   expect(profile.disposed).toBe(false);
  387 |   expect(await fingerprintOf(here.window)).toBe(senderFingerprint);
  388 |   await waitForDurableDeliveryPath(here, there, receiverFingerprint);
  389 |   await expect.poll(async () => (await readSender()).outbox.length, { timeout: 30_000 }).toBe(0);
  390 |   const after = await readSender();
  391 |   expect(after.deliveries.find((row) => row.callId === firstId)).toMatchObject({ state: 'delivered', attempts: 2 });
  392 |   expect(after.deliveries.find((row) => row.callId === secondId)).toMatchObject({ state: 'delivered', attempts: 1 });
  393 |   await here.window.evaluate(async ({ id, project }) => {
  394 |     const running = await window.clubhouse.agent.getRunningStatuses([id]);
  395 |     if (!running.includes(id)) await window.clubhouse.agent.spawnAgent({ agentId: id, projectPath: project, cwd: project, kind: 'durable', orchestrator: 'claude-code' });
  396 |   }, { id: senderId, project: senderProject });
  397 |   const restartedReport = await waitForFakeCliRegistration(here, fakesHere, senderId, oldCliPid);
  398 |   mcp = await connectMcp(restartedReport.env);
  399 |   const duplicate = await mcp.call(send!, firstArgs);
> 400 |   expect(duplicate.isError).toBe(false);
      |                             ^ Error: expect(received).toBe(expected) // Object.is equality
  401 |   expect(createHash('sha256').update(JSON.stringify(duplicate.result)).digest('hex')).toBe(boundary.resultHash);
  402 |   const statusTool = (await mcp.toolNames()).find((name) => name.endsWith('get_delivery'));
  403 |   expect(statusTool).toBeTruthy();
  404 |   expect(JSON.parse((await mcp.call(statusTool!, { delivery_id: firstId })).text)).toMatchObject({ callId: firstId, state: 'delivered', attempts: 2 });
  405 |   await expect(receiverChat).toHaveAttribute('data-state', 'idle');
  406 |   const fileTool = (await mcp.toolNames()).find((name) => name.endsWith('__send_file'));
  407 |   expect(fileTool).toBeTruthy();
  408 |   const content = 'Exact file bytes.\r\nSecond line.\n';
  409 |   const fileArgs = { content, filename: 'durable.txt', task_id: 'durable-file', idempotency_key: 'durable-file' };
  410 |   const fileResult = await mcp.call(fileTool!, fileArgs);
  411 |   expect(fileResult.isError).toBe(false);
  412 |   const filePath = /path=(.+)$/.exec(fileResult.text)?.[1];
  413 |   if (!filePath) throw new Error('File receipt did not name the fixture file');
  414 |   const temp = await there.electronApp.evaluate(({ app }) => app.getPath('temp'));
  415 |   expect(path.dirname(path.dirname(filePath))).toBe(temp);
  416 |   expect(path.basename(path.dirname(filePath))).toMatch(/^clubhouse-a2a-/);
  417 |   expect(path.basename(filePath)).toMatch(/^[0-9a-f-]{36}\.md$/);
  418 |   expect(await fs.promises.readFile(filePath)).toEqual(Buffer.from(content));
  419 |   expect(await mcp.call(fileTool!, fileArgs)).toEqual(fileResult);
  420 |   await expect.poll(async () => {
  421 |     const events = await there!.window.evaluate((id) => window.clubhouse.chat.readTranscript(id), receiverId);
  422 |     return events.filter((event) => event.type === 'user_message' && event.data.source === 'mcp')
  423 |       .map((event) => event.type === 'user_message' ? event.data.content.filter((block) => block.type === 'text').map((block) => block.type === 'text' ? block.text : '').join('') : '');
  424 |   }).toEqual([expect.stringContaining('[TASK:durable-first]'), expect.stringContaining('[TASK:durable-second]'), expect.stringContaining('[TASK:durable-file]')]);
  425 |   await expect.poll(async () => (await fakesThere!.report('claude')).complete).toBe(true);
  426 |   expect((await fakesThere.report('claude')).unexpected).toEqual([]);
  427 |   expect((await fakesThere.report('claude')).mismatch).toBeNull();
  428 |   const ids = (await fs.promises.readFile(requestsPath, 'utf8')).trim().split('\n').map((line) => (JSON.parse(line) as { callId: string }).callId);
  429 |   expect(ids.slice(0, 3)).toEqual([firstId, firstId, secondId]);
  430 |   expect(ids.filter((id) => id === firstId)).toHaveLength(2);
  431 |   const persistedReceipt: DeliveryFile = JSON.parse(await fs.promises.readFile(receiverStore, 'utf8'));
  432 |   expect(persistedReceipt.inbox.find((row) => row.key === receipt!.key)).toEqual(receipt);
  433 |   const otherId = await createDurableAgent(here.window, { projectName: path.basename(senderProject), name: 'other-delivery-caller', orchestrator: 'claude-code' });
  434 |   const otherReport = await waitForFakeCliRegistration(here, fakesHere, otherId);
  435 |   const otherMcp = await connectMcp(otherReport.env);
  436 |   expect(await otherMcp.call(statusTool!, { delivery_id: firstId })).toMatchObject({ isError: true, text: 'No retained delivery with that id belongs to you.' });
  437 |   await info.attach('durable-replay-witness', { body: JSON.stringify({ firstId, secondId, attempts: [2, 1], actualRequestIds: ids, runtimeInputs: 3, fileBytes: Buffer.byteLength(content), fileHash: createHash('sha256').update(content).digest('hex') }), contentType: 'application/json' });
  438 | });
  439 | 
  440 | test('default native Copilot SDK fixtures accept one remote input and replay a stable delivery without a second input', async () => {
  441 |   const info = test.info();
  442 |   scratch = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'clubhouse-e2e-delivery-sdk-'));
  443 |   const senderFixture = await writeChatScript(scratch, 'sdk-sender', buildChatScript('copilot', { description: 'Native SDK sender with no model turns.', turns: [] }));
  444 |   const receiverFixture = await writeChatScript(scratch, 'sdk-receiver', buildChatScript('copilot', {
  445 |     description: 'One token-free native SDK Annex input.',
  446 |     turns: [{ steps: [{ type: 'text', text: 'Synthetic fixture response, not model execution.' }] }],
  447 |   }));
  448 |   fakesHere = await installFakeClis({ copilot: await writeAuthenticatedSdkFixture(scratch, senderFixture.fixture) });
  449 |   fakesThere = await installFakeClis({ copilot: await writeAuthenticatedSdkFixture(scratch, receiverFixture.fixture) });
  450 |   const senderHome = path.join(scratch, 'sender-sdk-home');
  451 |   const receiverHome = path.join(scratch, 'receiver-sdk-home');
  452 |   for (const [fakes, home] of [[fakesHere, senderHome], [fakesThere, receiverHome]] as const) {
  453 |     await fs.promises.mkdir(path.join(home, 'session-state'), { recursive: true });
  454 |     fakes.env = { ...fakes.env, ...SDK_FIXTURE_ENV, COPILOT_HOME: home, HOME: home, USERPROFILE: home, XDG_CONFIG_HOME: home, XDG_STATE_HOME: home };
  455 |   }
  456 |   const senderProject = path.join(scratch, 'sdk-sender-project');
  457 |   const receiverProject = path.join(scratch, 'sdk-receiver-project');
  458 |   await fs.promises.mkdir(senderProject);
  459 |   await fs.promises.mkdir(receiverProject);
  460 |   here = await launchDesktop('native-sdk-sender', fakesHere, 'Desk', 'copilot-cli');
  461 |   there = await launchDesktop('native-sdk-receiver', fakesThere, 'Studio', 'copilot-cli');
  462 |   const senderId = await startAgent(here, senderProject, 'sdk-sender', 'copilot-cli');
  463 |   const receiverId = await startAgent(there, receiverProject, 'sdk-receiver', 'copilot-cli');
  464 |   for (const [app, fakes, id, home] of [[here, fakesHere, senderId, senderHome], [there, fakesThere, receiverId, receiverHome]] as const) {
  465 |     const report = await fakes.report('copilot', id);
  466 |     expect(report.protocol).toBe('copilot-sdk');
  467 |     expect(report.argv).toEqual(expect.arrayContaining(['--headless', '--port', '0']));
  468 |     expect(report.env.COPILOT_HOME).toBe(home);
  469 |     expect(report.env.CLUBHOUSE_AGENT_ID).toBe(id);
  470 |     await expect.poll(async () => {
  471 |       const events = await app.window.evaluate((agentId) => window.clubhouse.chat.readTranscript(agentId), id);
  472 |       return events.filter((event) => event.type === 'session_started').pop()?.data.driver;
  473 |     }).toBe('copilot_sdk');
  474 |   }
  475 |   await pairDesktops(here, there, senderId, receiverId);
  476 |   const requestsPath = path.join(scratch, 'received-call-ids.jsonl');
  477 |   await observeDeliveryRequests(there, requestsPath);
  478 |   const mcp = await connectMcp((await fakesHere.report('copilot', senderId)).env);
  479 |   const send = (await mcp.toolNames()).find((name) => name.endsWith('__send_message'));
  480 |   expect(send).toBeTruthy();
  481 |   const args = { message: 'one native SDK fixture input', task_id: 'native-sdk-delivery', idempotency_key: 'native-sdk-delivery' };
  482 |   const first = await mcp.call(send!, args);
  483 |   expect(first.isError).toBe(false);
  484 |   expect(await mcp.call(send!, args)).toEqual(first);
  485 |   await expect.poll(async () => (await fakesThere!.report('copilot', receiverId)).complete).toBe(true);
  486 |   const report = await fakesThere.report('copilot', receiverId);
  487 |   expect(report.mismatch).toBeNull();
  488 |   expect(report.unexpected).toEqual([]);
  489 |   const input = await there.window.evaluate(async (id) => (await window.clubhouse.chat.readTranscript(id))
  490 |     .filter((event) => event.type === 'user_message' && event.data.source === 'mcp'), receiverId);
  491 |   expect(input).toHaveLength(1);
  492 |   const calls = (await fs.promises.readFile(requestsPath, 'utf8')).trim().split('\n');
  493 |   expect(calls).toHaveLength(1);
  494 |   await info.attach('native-sdk-replay-witness', { body: JSON.stringify({ driver: 'copilot_sdk', runtimeInputs: input.length, actualRequests: calls.length, realLogin: false, modelExecution: false }), contentType: 'application/json' });
  495 | });
  496 | 
  497 | test('capacity probes require device.read and return coarse results for both desktops', async () => {
  498 |   scratch = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'handoff-capacity-'));
  499 |   const fixture = await quietFixture(scratch);
  500 |   fakesHere = await installFakeClis({ claude: fixture });
```