import gzip
import hashlib
import json
import pathlib
import subprocess

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/fixture-overlap-baseline")
raw_manifest = (out / "manifest.json").read_bytes()
manifest = json.loads(raw_manifest)
assert len(manifest["archives"]) == 36
assert subprocess.check_output(["git", "rev-parse", "HEAD"]).decode().strip() == manifest["source"]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def archive(name, raw):
    encoded = gzip.compress(raw, mtime=0)
    target = out / (name + ".gz")
    assert not target.exists()
    target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == raw
    manifest["archives"].append({
        "file": target.name, "bytes": len(raw), "sha256": sha(raw),
        "gzipBytes": len(encoded), "gzipSha256": sha(encoded),
    })


archive("166-original-proposal-manifest.json", raw_manifest)
archive("166-original-proposal-readme.md", (out / "README.md").read_bytes())
for name in [
    "166-freeze-overlap-original.log", "166-freeze-overlap-exit.txt",
    "167-overlap-contract-refinement.txt", "167-freeze-overlap-contract-refinement.py",
]:
    archive(name, (cache / name).read_bytes())
manifest["pendingContract"] = {
    "initial": "165-overlap-minimal-hunk-contract.txt.gz",
    "latestAdditiveRequirement": "167-overlap-contract-refinement.txt.gz",
    "status": "Not implemented/approved; full independent design pending",
    "originalProposalManifestSha256": sha(raw_manifest),
    "requirements": [
        "Immutable coalesced original owner and later-directory protection",
        "Separate actual raw-body completion; no manual cleanup self-await",
        "Completion record retains exact actual errors AND mandatory teardown outcomes",
        "Explicit registered/asserted synthetic references, not body resolution or blanket hook swallow",
        "Unexpected caller/teardown errors remain surfaced",
    ],
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
assert len(manifest["archives"]) == 42
assert {path.name for path in out.iterdir()} == {row["file"] for row in manifest["archives"]} | {"manifest.json", "README.md"}
print(json.dumps({"archives": 42, "baseline": manifest["source"],
                  "counts": manifest["run"]["counts"], "failureNodes": manifest["run"]["failureNodes"],
                  "contractStatus": manifest["pendingContract"]["status"]}))
