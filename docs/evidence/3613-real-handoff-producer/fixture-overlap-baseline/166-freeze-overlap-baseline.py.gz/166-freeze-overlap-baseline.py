import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/fixture-overlap-baseline")
base = "76656abec9b5f9a0fb6f6cd12b74178efcbf7ae2"
source = "c535d031ef94617c2364e745a9765c91c2a31726"
custody = "16991dca76a7a6117a3c7e26232ecae5b86d89d0"
fixture = "test/annex-v2/handoff-producer-admission.test.ts"
prefix = "164-overlap-original-red"


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert text("rev-parse", "HEAD") == source
assert not text("status", "--porcelain")
assert text("diff", "--name-only", base, source) == fixture
assert text("rev-parse", base + ":src") == text("rev-parse", source + ":src")
before = json.loads((cache / (prefix + "-before.json")).read_text())
after = json.loads((cache / (prefix + "-after.json")).read_text())
assert before["head"] == after["head"] == source
assert before["clean"] and after["clean"] and after["matchesBefore"]
assert before["files"] == after["files"] and len(before["files"]) == 16
assert before["command"] == after["command"]
assert before["tree"] == text("rev-parse", source + "^{tree}")
assert before["srcTree"] == text("rev-parse", source + ":src")
assert int((cache / (prefix + "-exit.txt")).read_text()) == 1
log = (cache / (prefix + "-original.log")).read_text()
assert "START lane-p2" in log and "END lane-p2 rc=1" in log

old = git("show", base + ":" + fixture)
current = git("show", source + ":" + fixture)
start = current.index(b"  it('keeps overlapping cleanup behind the original actual preparation drain'")
end = current.index(b"  it.each([1, 9])('drains a real held preparation", start)
control = current[start:end]
assert current[:start] + current[end:] == old
owned_start, owned_end = b"beforeEach(async () => {", b"afterEach(cleanupFixture);"
old_owned = old[old.index(owned_start):old.index(owned_end) + len(owned_end)]
current_owned = current[current.index(owned_start):current.index(owned_end) + len(owned_end)]
assert old_owned == current_owned
cases = list(ET.fromstring((cache / (prefix + "-original.xml")).read_bytes()).iter("testcase"))
rows = [{
    "attributes": case.attrib,
    "result": "fail" if case.findall("failure") or case.findall("error")
    else "skip" if case.find("skipped") is not None else "pass",
    "failureNodes": [ET.tostring(node, encoding="unicode")
                     for node in list(case) if node.tag in ("failure", "error")],
} for case in cases]
counts = dict(collections.Counter(row["result"] for row in rows))
assert len(rows) == 59 and counts == {"fail": 1, "skip": 58}
assert sum(len(row["failureNodes"]) for row in rows) == 4
assert all(node.attrib.get("type") == "AssertionError"
           for case in cases for node in case.findall("failure"))
pr = json.loads((cache / "166-overlap-pr-original.json").read_text())
assert pr["state"] == "OPEN" and pr["headRefOid"] == base
refs = dict(line.split("\t", 1)[::-1] for line in
            (cache / "166-overlap-refs-original.txt").read_text().splitlines())
assert refs["refs/heads/lane-3613-p2-routes/handoff-producer-ci-failure-45075711451"] == custody
assert refs["refs/heads/lane-3613-p2-routes/handoff-recipient-continuity"] == base
assert refs["refs/heads/lane-3613-p2-routes/handoff-producer-teardown-correction"] == base
assert refs["refs/heads/lane-3613-p2-routes/handoff-producer-ci-failure"] == "ab853c28ab03472425279bf159c370e16c27cc57"
assert pr["baseRefOid"] == refs["refs/heads/main"] == "50c474b48f57e0256661244bd29b9343ec112bc4"
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, raw):
    encoded = gzip.compress(raw, mtime=0)
    target = out / (name + ".gz")
    assert not target.exists() or target.read_bytes() == encoded
    target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == raw
    archives.append({
        "file": target.name, "bytes": len(raw), "sha256": sha(raw),
        "gzipBytes": len(encoded), "gzipSha256": sha(encoded),
    })


for path in sorted(cache.glob(prefix + "-*")):
    archive(path.name, path.read_bytes())
for name in [
    "165-overlap-minimal-hunk-contract.txt", "166-overlap-pr-original.json",
    "166-overlap-refs-original.txt", "131-hosted-correction-command-receipt.cjs",
    "133-producer-hosted-correction-tsconfig.json", "166-freeze-overlap-baseline.py",
]:
    archive(name, (cache / name).read_bytes())
for name, row in before["files"].items():
    raw = pathlib.Path(name).read_bytes()
    assert sha(raw) == row["sha256"] and len(raw) == row["bytes"]
    if not name.startswith("node_modules/"):
        assert raw == git("show", source + ":" + name)
    archive("bound-input-" + name.replace("/", "__"), raw)
for head in [base, source]:
    archive("source-" + head + "-fixture.test.ts", git("show", head + ":" + fixture))
    archive("source-" + head + "-commit.txt", git("show", "--no-patch", "--format=raw", head))
archive("source-" + custody + "-commit.txt", git("show", "--no-patch", "--format=raw", custody))
archive("baseline-added-control.txt", control)
archive("original-owned-wrapper-and-cleanup.txt", old_owned)
archive("baseline-76656-to-c535.patch", git("diff", base, source, "--", fixture))
archive("164-overlap-original-red-testcase-rows.json", (json.dumps(rows, indent=2) + "\n").encode())
manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "base": base, "source": source, "sourceTree": before["tree"],
    "srcTree": before["srcTree"], "selectedFile": fixture,
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-overlap-baseline",
    "originalHostedCustody": custody, "prBeforeFreeze": pr,
    "diffStat": text("diff", "--stat", base, source),
    "bridges": {
        "completeOriginalFixture": {"bytes": len(old), "sha256": sha(old),
                                   "gitBlob": text("rev-parse", base + ":" + fixture),
                                   "identicalAfterRemovingOneControl": True},
        "originalOwnedWrapperAndCleanup": {"bytes": len(old_owned), "sha256": sha(old_owned),
                                          "identical": True},
        "addedControl": {"bytes": len(control), "sha256": sha(control), "lines": 47},
    },
    "run": {
        "prefix": prefix, "command": before["command"], "node": before["node"],
        "sourceHead": source, "sourceTree": before["tree"], "srcTree": before["srcTree"],
        "cleanPrePost": True, "matchingRelevantInputs": 16,
        "exit": 1, "declarations": 59, "counts": counts, "failureNodes": 4,
        "failedCaseAttributes": next(row["attributes"] for row in rows if row["result"] == "fail"),
    },
    "limits": [
        "ONE original76656 negative-control execution;58 declarations skipped",
        "No correction, new framework, phase instrumentation or hosted execution",
        "No new type/lint execution or transfer of earlier proof to the added runtime hunk",
        "No preparation-success claim; actual preparation settlement awaited after hold release",
        "Shared cleanup settlement is not actual raw-body completion",
        "First Windows body delay/all57 closure and underlying Chat PDF cause remain unknown",
        "Proposed minimal hunk contract awaits existing independent reviewer/full design",
    ],
    "archives": archives,
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
assert {path.name for path in out.iterdir()} == {row["file"] for row in archives} | {"manifest.json"}
assert not text("status", "--porcelain", "--untracked-files=no")
print(json.dumps({"archives": len(archives), "counts": counts, "failureNodes": 4,
                  "source": source, "srcTree": before["srcTree"]}))
