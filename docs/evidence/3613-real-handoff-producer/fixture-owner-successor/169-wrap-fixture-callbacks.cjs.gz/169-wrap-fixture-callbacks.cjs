const fs = require('node:fs');
const ts = require('typescript');
const file = 'test/annex-v2/handoff-producer-admission.test.ts';
const source = fs.readFileSync(file, 'utf8');
const tree = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
const edits = [];
const tail = source.indexOf('async function prepare(');
let callbacks = 0;
function visit(node) {
  if (ts.isCallExpression(node)) {
    const call = node.expression;
    const fixtureTest = ts.isIdentifier(call) && call.text === 'it'
      || ts.isCallExpression(call) && ts.isPropertyAccessExpression(call.expression)
      && ts.isIdentifier(call.expression.expression) && call.expression.expression.text === 'it'
      && call.expression.name.text === 'each';
    const callback = node.arguments[node.arguments.length - 1];
    if (fixtureTest && callback && ts.isArrowFunction(callback) && ts.isBlock(callback.body)) {
      edits.push({ start: callback.body.getStart(tree), end: callback.body.getStart(tree), text: 'runFixtureBody(async () => ' });
      edits.push({ start: callback.body.end, end: callback.body.end, text: ')' });
      callbacks++;
    }
  }
  if (node.getStart(tree) >= tail && ts.isIdentifier(node)) {
    const replacements = { operations: 'fixtureOwner().operations', releases: 'fixtureOwner().releases', dir: 'fixtureDirectory()' };
    if (Object.hasOwn(replacements, node.text)) edits.push({ start: node.getStart(tree), end: node.end, text: replacements[node.text] });
  }
  ts.forEachChild(node, visit);
}
visit(tree);
let output = source;
for (const edit of edits.sort((a, b) => b.start - a.start)) output = output.slice(0, edit.start) + edit.text + output.slice(edit.end);
fs.writeFileSync(file, output);
console.log(JSON.stringify({ callbacks, edits: edits.length, file }));
