import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/fixture-owner-successor")
source = "219fca7759963de4c68a4ddf0159c6c7b1a97645"
candidate = "79e562d6bbd45a4e14c8293227cf59f2dd92e1d0"
base = "e2da738ce3db11a21c250333e7a80a1ffb8347c2"
baseline = "c535d031ef94617c2364e745a9765c91c2a31726"
fixture = "test/annex-v2/handoff-producer-admission.test.ts"
prefixes = [
    "170-owner-finite-candidate", "171-owner-fixture-types", "172-owner-fixture-lint",
    "173-owner-final-finite", "174-owner-final-types", "175-owner-final-lint",
]


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert text("rev-parse", "HEAD") == source and not text("status", "--porcelain")
assert text("diff", "--name-only", base, source) == fixture
assert text("rev-parse", base + ":src") == text("rev-parse", source + ":src")
report = (cache / "168-full-design-report-original.md").read_bytes()
assert len(report) == 21408
assert hashlib.sha1(f"blob {len(report)}\0".encode() + report).hexdigest() == "610ced89454c17139479813b6e2262bea5fd48f8"
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, raw):
    encoded = gzip.compress(raw, mtime=0)
    path = out / (name + ".gz")
    assert not path.exists() or path.read_bytes() == encoded
    path.write_bytes(encoded)
    assert gzip.decompress(path.read_bytes()) == raw
    archives.append({
        "file": path.name, "bytes": len(raw), "sha256": sha(raw),
        "gzipBytes": len(encoded), "gzipSha256": sha(encoded),
    })


runs = []
for prefix in prefixes:
    before = json.loads((cache / (prefix + "-before.json")).read_text())
    after = json.loads((cache / (prefix + "-after.json")).read_text())
    assert before["clean"] and after["clean"] and after["matchesBefore"]
    assert before["files"] == after["files"] and len(before["files"]) == 16
    assert before["head"] == after["head"] == (candidate if prefix.startswith(("170", "171", "172")) else source)
    assert before["tree"] == text("rev-parse", before["head"] + "^{tree}")
    assert before["srcTree"] == text("rev-parse", source + ":src")
    assert int((cache / (prefix + "-exit.txt")).read_text()) == 0
    for name, row in before["files"].items():
        if not name.startswith("node_modules/"):
            assert sha(git("show", before["head"] + ":" + name)) == row["sha256"]
    run = {"prefix": prefix, "head": before["head"], "tree": before["tree"],
           "srcTree": before["srcTree"], "command": before["command"], "node": before["node"],
           "exit": 0, "matchingRelevantInputs": 16, "cleanPrePost": True}
    xml = cache / (prefix + "-original.xml")
    if xml.exists():
        cases = list(ET.fromstring(xml.read_bytes()).iter("testcase"))
        rows = [{
            "attributes": case.attrib,
            "result": "fail" if case.findall("failure") or case.findall("error")
            else "skip" if case.find("skipped") is not None else "pass",
            "failureNodes": [ET.tostring(node, encoding="unicode")
                             for node in list(case) if node.tag in ("failure", "error")],
        } for case in cases]
        counts = dict(collections.Counter(row["result"] for row in rows))
        assert counts == {"pass": 18 if prefix.startswith("170") else 19, "skip": 50}
        run.update({"declarations": len(rows), "counts": counts,
                    "failureNodes": sum(len(row["failureNodes"]) for row in rows)})
        archive(prefix + "-testcase-rows.json", (json.dumps(rows, indent=2) + "\n").encode())
    if "types" in prefix:
        lines = (cache / (prefix + "-original.log")).read_text().splitlines()
        assert not any("error TS" in line for line in lines)
        assert sum(line.startswith("/") for line in lines) == 3959
        run.update({"diagnostics": 0, "orderedListFilesRows": 3959})
    if "lint" in prefix:
        rows = json.loads((cache / (prefix + "-original.json")).read_text())
        assert len(rows) == 1 and not any(row["errorCount"] or row["warningCount"] for row in rows)
        run.update({"completeFixtureFiles": 1, "errors": 0, "warnings": 0})
    runs.append(run)
    for path in sorted(cache.glob(prefix + "-*")):
        archive(path.name, path.read_bytes())

for path in sorted(cache.glob("164-overlap-original-red-*")):
    archive(path.name, path.read_bytes())
for head in [base, baseline, candidate, source]:
    archive("source-" + head + "-fixture.test.ts", git("show", head + ":" + fixture))
    archive("source-" + head + "-commit.txt", git("show", "--no-patch", "--format=raw", head))
for previous in [base, baseline, candidate]:
    archive("delta-" + previous + "-" + source + ".patch", git("diff", previous, source, "--", fixture))
for name in [
    "168-full-design-report-original.md", "168-full-design-blob-original.json",
    "168-full-design-path-original.json", "169-wrap-fixture-callbacks.cjs",
    "173-run-owner-proof.sh", "176-owner-source-bridges.cjs", "176-owner-source-bridges-original.json",
    "176-owner-pr-original.json", "176-owner-refs-original.txt", "176-freeze-owner-successor.py",
]:
    archive(name, (cache / name).read_bytes())

last = json.loads((cache / "175-owner-final-lint-after.json").read_text())
for name, row in last["files"].items():
    raw = pathlib.Path(name).read_bytes()
    assert sha(raw) == row["sha256"] and len(raw) == row["bytes"]
    archive("bound-input-" + name.replace("/", "__"), raw)

index = {}
for entry in git("ls-files", "-s", "-z").decode().split("\0"):
    if entry:
        header, name = entry.split("\t", 1)
        _, blob, stage = header.split()
        assert stage == "0"
        index[name] = blob
root = str(pathlib.Path.cwd()) + "/"
inventory = []
inputs = [line for line in (cache / "174-owner-final-types-original.log").read_text().splitlines() if line.startswith("/")]
for ordinal, name in enumerate(inputs):
    raw = pathlib.Path(name).read_bytes()
    relative = name[len(root):] if name.startswith(root) else None
    tracked = relative in index
    blob = hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()
    if tracked:
        assert blob == index[relative]
    inventory.append({"ordinal": ordinal, "path": name, "relative": relative, "tracked": tracked,
                      "bytes": len(raw), "sha256": sha(raw), "gitBlob": blob if tracked else None})
assert len(inputs) == len(set(inputs)) == 3959
archive("174-input-inventory-observed-after-execution.json", (json.dumps(inventory, indent=2) + "\n").encode())
bridge = json.loads((cache / "176-owner-source-bridges-original.json").read_text())
assert bridge["source"] == source and bridge["originalCallbacks"] == 33 and bridge["currentCallbacks"] == 40
assert sum(row["normalizedAssertions"] for row in bridge["preserved"]) == 448
pr = json.loads((cache / "176-owner-pr-original.json").read_text())
assert pr["state"] == "OPEN" and pr["headRefOid"] == "76656abec9b5f9a0fb6f6cd12b74178efcbf7ae2"
manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": source, "sourceTree": text("rev-parse", source + "^{tree}"),
    "srcTree": text("rev-parse", source + ":src"), "base": base, "selectedFile": fixture,
    "diffStat": text("diff", "--stat", base, source),
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-owner-successor",
    "design": {"ref": "d642886848992bea1a8a7ac845f96578d88ebd1d",
               "path": json.loads((cache / "168-full-design-path-original.json").read_text())["path"],
               "blob": "610ced89454c17139479813b6e2262bea5fd48f8",
               "bytes": len(report), "sha256": sha(report)},
    "runs": runs, "sourceBridges": bridge,
    "compilerInventory": {"observedAfterExecution": True, "rows": len(inventory),
                          "trackedVerifiedToSourceGit": sum(row["tracked"] for row in inventory),
                          "dependencyObservations": sum(not row["tracked"] for row in inventory),
                          "atomicOrPreExecutionSeal": False},
    "reusedBaseline": {"source": baseline, "custody": base, "prefix": "164-overlap-original-red",
                       "counts": {"fail": 1, "skip": 58}, "declarations": 59, "failureNodes": 4},
    "prBeforeFreeze": pr,
    "limits": ["Exact final17319PASS/50SKIP/69 declarations, not aggregate69 execution",
               "Candidate17018PASS stays bound to79e; no source transfer",
               "50 skipped producer cases are not newly runtime-accepted",
               "Sentinel body/expired-waiter/admission proof is not native Vitest/Windows timeout acceptance",
               "Original first Windows delay/all57 failures and separate Chat loader/open cause remain unknown",
               "No production/deadline/permission/framework/Chat edit or new hosted observation",
               "Existing independent exact source/proof review required before PR update"],
    "archives": archives,
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
assert {path.name for path in out.iterdir()} == {row["file"] for row in archives} | {"manifest.json"}
assert not text("status", "--porcelain", "--untracked-files=no")
print(json.dumps({"archives": len(archives), "source": source,
                  "inventory": manifest["compilerInventory"], "finalRuntime": runs[3]["counts"]}))
