const fs = require('node:fs');
const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const file = 'test/annex-v2/handoff-producer-admission.test.ts';
const base = execFileSync('git', ['show', `e2da738ce3db11a21c250333e7a80a1ffb8347c2:${file}`], { encoding: 'utf8' });
const current = fs.readFileSync(file, 'utf8');
const normalize = text => text.replaceAll('fixtureOwner().operations', 'operations')
  .replaceAll('fixtureOwner().releases', 'releases').replaceAll('fixtureDirectory()', 'dir').replace(/\s+/g, ' ');
function tests(source) {
  const tree = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true);
  if (tree.parseDiagnostics.length) throw new Error('Source bridge parse failed.');
  const rows = new Map();
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const call = node.expression;
      const test = ts.isIdentifier(call) && call.text === 'it'
        || ts.isCallExpression(call) && ts.isPropertyAccessExpression(call.expression)
        && ts.isIdentifier(call.expression.expression) && call.expression.expression.text === 'it';
      const callback = node.arguments[node.arguments.length - 1];
      if (test && ts.isArrowFunction(callback)) {
        const wrapped = ts.isCallExpression(callback.body) && ts.isIdentifier(callback.body.expression)
          && callback.body.expression.text === 'runFixtureBody';
        const body = wrapped ? callback.body.arguments[0].body : callback.body;
        const assertions = [];
        function collect(child) {
          if (ts.isCallExpression(child) && /^expect(?:\.soft)?\(/.test(child.getText(tree))) {
            assertions.push(normalize(child.getText(tree)));
          }
          ts.forEachChild(child, collect);
        }
        collect(body);
        const name = node.arguments[0].getText(tree);
        if (rows.has(name)) throw new Error('Duplicate physical callback name.');
        rows.set(name, { name, wrapped, assertions, argumentCount: node.arguments.length });
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(tree);
  return rows;
}
const oldTests = tests(base), newTests = tests(current);
const preserved = [];
for (const [name, row] of oldTests) {
  const now = newTests.get(name);
  if (!now || now.argumentCount !== row.argumentCount || !now.wrapped) throw new Error('Original callback/deadline registration changed.');
  let position = 0;
  for (const assertion of row.assertions) {
    while (position < now.assertions.length && now.assertions[position] !== assertion) position++;
    if (position === now.assertions.length) throw new Error(`Original assertion not retained: ${name}: ${assertion}`);
    position++;
  }
  preserved.push({ name, normalizedAssertions: row.assertions.length, originalArgumentsPreserved: true });
}
if ([...newTests.values()].some(row => !row.wrapped)) throw new Error('Unowned actual callback.');
console.log(JSON.stringify({
  schema: 1, base: 'e2da738ce3db11a21c250333e7a80a1ffb8347c2',
  source: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  originalCallbacks: oldTests.size, currentCallbacks: newTests.size,
  allCurrentCallbacksRegistered: true, preserved,
  limits: 'Static normalized assertion/registration comparison, not unchanged whole-fixture bytes or runtime acceptance of skipped cases.',
}, null, 2));
