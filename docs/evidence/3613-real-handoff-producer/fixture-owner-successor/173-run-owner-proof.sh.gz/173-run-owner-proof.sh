#!/usr/bin/env bash
set -u
prefix="$1"
minimum="$2"
shift 2
cache=node_modules/.cache/native-handoff-ingress
log="$cache/$prefix-original.log"
test ! -e "$log" || exit 99
printf -v command '%q ' "$HOME/.clubhouse/orch/desktop-test-gate.sh" lane-p2 "$minimum" -- "$@"
node "$cache/131-hosted-correction-command-receipt.cjs" "$cache/$prefix-before.json" "$command" || exit $?
"$HOME/.clubhouse/orch/desktop-test-gate.sh" lane-p2 "$minimum" -- "$@" > "$log" 2>&1
result=$?
printf '%s\n' "$result" > "$cache/$prefix-exit.txt"
node "$cache/131-hosted-correction-command-receipt.cjs" "$cache/$prefix-after.json" "$command" "$cache/$prefix-before.json"
receipt=$?
grep -E 'START lane|END lane|error TS|Test Files|Tests  |Duration ' "$log" || true
test "$receipt" -eq 0 || exit "$receipt"
exit "$result"
