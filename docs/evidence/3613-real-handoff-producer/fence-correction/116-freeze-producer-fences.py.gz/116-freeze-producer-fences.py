import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/fence-correction")
source = "275df2b3c8e5fa81cc066d0b308edb6c59d9df61"
original = "ef99265da9faddddf522c2c294745d86d593d78d"
red_source = "c2a6d24fa1b381ac23e825dc31ccd06bd061af9e"
benign_source = "970e22dd4b99a2a3ce8654505675366067ce2d38"
selected = [
    "src/main/services/clubhouse-mcp/handoff-permissions.ts",
    "src/main/services/handoff-host.ts",
    "test/annex-v2/handoff-producer-admission.test.ts",
    "docs/annex-reverse-routes.md",
]


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


assert text("rev-parse", "HEAD") == source
assert not text("status", "--porcelain", "--untracked-files=no")
assert set(text("diff", "--name-only", original, source).splitlines()) == set(selected)
for unchanged in [red_source, benign_source]:
    assert text("rev-parse", f"{unchanged}:src") == text("rev-parse", f"{original}:src")
assert text("rev-parse", f"{source}:docs/evidence/3613-real-handoff-producer/candidate/manifest.json") == "0f1fc23ef0286c168ab1fdd4ac7a7124969da5e9"
assert blob((cache / "109-producer-full-review-b6-original.md").read_bytes()) == "1c2b871739e5eaec9f41fce72495a02d6d5b016a"
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, data, provenance):
    target = out / (name + ".gz")
    encoded = gzip.compress(data, mtime=0)
    if target.exists():
        assert target.read_bytes() == encoded, f"Existing archive differs: {target}"
    else:
        target.write_bytes(encoded)
    stored = target.read_bytes()
    assert gzip.decompress(stored) == data
    record = {
        "file": target.name, "rawBytes": len(data), "rawSha256": sha(data),
        "gzipBytes": len(stored), "gzipSha256": sha(stored), "provenance": provenance,
    }
    archives.append(record)
    return record


checks = [
    (111, "producer-fences-red", red_source, 1),
    (112, "producer-benign", benign_source, 0),
    (113, "producer-fences-green", source, 0),
    (114, "producer-fences-types", source, 0),
    (115, "producer-fences-eslint", source, 0),
]
receipts = []
for number, name, head, exit_code in checks:
    stem = f"{number}-{name}"
    before = json.loads((cache / f"{stem}-before.json").read_text())
    after = json.loads((cache / f"{stem}-after.json").read_text())
    assert before["head"] == after["head"] == head
    assert before["clean"] and after["clean"] and after["matchesBefore"]
    assert before["files"] == after["files"] and before["tree"] == after["tree"]
    assert before["tree"] == text("rev-parse", f"{head}^{{tree}}")
    for file, recorded in before["files"].items():
        if not file.startswith("node_modules/"):
            assert recorded["gitBlob"] == text("rev-parse", f"{head}:{file}")
    log = (cache / f"{stem}-original.log").read_text()
    assert re.search(rf" END lane-p2 rc={exit_code}\s*$", log)
    assert int((cache / f"{stem}-exit.txt").read_text()) == exit_code
    for suffix in ["before.json", "after.json", "original.log", "exit.txt"]:
        path = cache / f"{stem}-{suffix}"
        archive(path.name, path.read_bytes(), {"source": head, "path": str(path)})
    receipts.append({"run": number, "source": head, "exit": exit_code, "command": before["command"],
                     "tree": before["tree"], "cleanBeforeAfter": True, "matchingRelevantHashes": True})

xml_runs = []
for number, name, head, expected in [
    (111, "producer-fences-red", red_source, {"pass": 4, "fail": 4, "skip": 29}),
    (112, "producer-benign", benign_source, {"pass": 1, "fail": 0, "skip": 36}),
    (113, "producer-fences-green", source, {"pass": 8, "fail": 0, "skip": 29}),
]:
    path = cache / f"{number}-{name}-original.xml"
    rows = []
    for case in ET.parse(path).getroot().iter("testcase"):
        failures = [
            {"tag": item.tag, "attributes": item.attrib, "text": item.text or ""}
            for item in list(case) if item.tag in ["failure", "error"]
        ]
        skipped = [item.attrib for item in list(case) if item.tag == "skipped"]
        status = "fail" if failures else "skip" if skipped else "pass"
        rows.append({"name": case.attrib["name"], "classname": case.attrib["classname"],
                     "attributes": case.attrib, "status": status, "failures": failures, "skipped": skipped})
    counts = dict(collections.Counter(row["status"] for row in rows))
    assert {key: counts.get(key, 0) for key in expected} == expected
    assert len(rows) == 37
    if number == 111:
        assert sum(len(row["failures"]) for row in rows) == 22
        assert all(item["attributes"].get("type") == "AssertionError" for row in rows for item in row["failures"])
    archive(path.name, path.read_bytes(), {"source": head, "path": str(path)})
    xml_runs.append({"run": number, "source": head, "counts": expected, "rows": rows})

type_log = (cache / "114-producer-fences-types-original.log").read_text()
assert not re.search(r"error TS\d+:", type_log)
inputs = []
for line in type_log.splitlines():
    if not line.startswith("/"):
        continue
    file = pathlib.Path(line)
    assert file.is_file(), f"Emitted compiler input missing: {line}"
    data = file.read_bytes()
    inputs.append({"path": line, "bytes": len(data), "sha256": sha(data)})
assert len(inputs) == 3958
for fixture in [
    "test/annex-v2/handoff-producer-admission.test.ts",
    "src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts",
]:
    assert str(pathlib.Path(fixture).resolve()) in [entry["path"] for entry in inputs]
inventory = {
    "capturePhase": "after executed compiler114, not a pre-execution or atomic full-input seal",
    "orderedListFiles": True, "source": source, "inputs": inputs,
}
inventory_path = cache / "114-producer-fences-types-input-inventory-after.json"
inventory_path.write_text(json.dumps(inventory, indent=2) + "\n")
archive(inventory_path.name, inventory_path.read_bytes(), {"source": source, "path": str(inventory_path)})

lint_path = cache / "115-producer-fences-eslint-original.json"
lint = json.loads(lint_path.read_text())
assert len(lint) == 3
assert sum(row["errorCount"] for row in lint) == 0
assert sum(row["warningCount"] for row in lint) == 0
archive(lint_path.name, lint_path.read_bytes(), {"source": source, "path": str(lint_path)})
for name in [
    "79-producer-candidate-tsconfig.json", "109-producer-full-review-b6-original.md",
    "110-producer-command-receipt.cjs", "116-freeze-producer-fences.py",
]:
    path = cache / name
    archive(path.name, path.read_bytes(), {"path": str(path)})

source_rows = []
for index, file in enumerate(selected, 1):
    row = {"path": file}
    for label, commit in [("original", original), ("successor", source)]:
        data = git("show", f"{commit}:{file}")
        identity = text("rev-parse", f"{commit}:{file}")
        assert blob(data) == identity
        row[label] = {"source": commit, "blob": identity, "bytes": len(data), "sha256": sha(data)}
        archive(f"source-{index}-{label}.txt", data, {"source": commit, "path": file})
    source_rows.append(row)
for label, parent, child in [
    ("selected-delta", original, source), ("genuine-baseline-fixture", original, red_source),
    ("benign-fixture-refinement", red_source, benign_source), ("combined-private-fences", benign_source, source),
]:
    archive(label + ".patch", git("diff", "--binary", parent, child, "--", *selected),
            {"parent": parent, "source": child, "paths": selected})
for label, commit in [("genuine-baseline", red_source), ("benign-refinement", benign_source)]:
    file = selected[2]
    archive(label + "-complete-fixture.txt", git("show", f"{commit}:{file}"), {"source": commit, "path": file})

manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": source, "sourceTree": text("rev-parse", f"{source}^{{tree}}"),
    "srcTree": text("rev-parse", f"{source}:src"), "originalCandidate": original,
    "originalImplementation": "ad104a538772156af463f3750783fbf4cd99c39c",
    "base": "50c474b48f57e0256661244bd29b9343ec112bc4",
    "review": {"commit": "b6aa456b1f3ea7b90d6ebfe74d36ca475fb682e3",
               "blob": "1c2b871739e5eaec9f41fce72495a02d6d5b016a", "findings": ["CP1", "CP2"]},
    "publishedRef": "refs/heads/lane-3613-p2-routes/handoff-producer-fences",
    "preservedCandidateRef": "refs/heads/lane-3613-p2-routes/handoff-usable-path",
    "preservedBoundaryRef": "refs/heads/lane-3613-p2-routes/handoff-producer-boundary",
    "sourceRows": source_rows, "checks": receipts, "xmlRuns": xml_runs,
    "actualXmlRows": sum(len(run["rows"]) for run in xml_runs),
    "compiler": {"run": 114, "diagnostics": 0, "actualOrderedInputs": len(inputs),
                 "bothCompleteFixturesPresent": True, "inputHashesCapturedAfterExecution": True},
    "lint": {"run": 115, "files": 3, "errors": 0, "warnings": 0},
    "archives": archives, "archiveCount": len(archives),
    "receiptLimits": "Observed clean head/tree and relevant hashes before/after each admitted command; no exclusive filesystem or atomic full-input seal. Historical101 has no listFiles/input inventory and is not retrosealed.",
    "sourceObservationFixture": "Notification input is dispatched to the real registered onAgentConfigChanged callback; actual peekDurableConfigs lookup is held. Producer.check spy forwards the real check and counts visits only; no private counters or authorization values are rewritten.",
    "acceptance": "Unreviewed combined CP1/CP2 successor; source-specific selected controls only. No PR/CI, whole-handoff, native TLS/bridge/provider/live-human, apply/wake/two-host or duplex acceptance.",
}
assert text("rev-parse", "HEAD") == source
assert not text("status", "--porcelain", "--untracked-files=no")
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"source": source, "archives": len(archives), "rawXmlRuns": len(xml_runs),
                  "actualXmlRows": manifest["actualXmlRows"], "compilerInputs": len(inputs),
                  "manifestSha256": sha((out / "manifest.json").read_bytes())}, indent=2))
