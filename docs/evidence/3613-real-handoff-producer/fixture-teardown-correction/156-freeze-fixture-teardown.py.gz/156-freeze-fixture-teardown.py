import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/fixture-teardown-correction")
source = "6eaa947d4195510a39a4f8331aa904c7e86b6bfb"
base = "6fa27a5a7f7b497a779df831b008489741390658"
fixture = "test/annex-v2/handoff-producer-admission.test.ts"
prefixes = [
    "146-fixture-teardown-faults-red", "147-fixture-teardown-faults-green",
    "148-fixture-teardown-types", "151-pre-forward-diagnostic-red",
    "153-fixture-teardown-final-green", "154-fixture-teardown-types", "155-fixture-teardown-lint",
]


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert text("rev-parse", "HEAD") == source and not text("status", "--porcelain")
assert text("diff", "--name-only", base, source) == fixture
assert text("rev-parse", source + ":src") == text("rev-parse", base + ":src")
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, raw):
    encoded = gzip.compress(raw, mtime=0)
    target = out / (name + ".gz")
    assert not target.exists() or target.read_bytes() == encoded
    target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == raw
    archives.append({"file": target.name, "bytes": len(raw), "sha256": sha(raw),
                     "gzipBytes": len(encoded), "gzipSha256": sha(encoded)})


runs = []
heads = {base, source}
for prefix in prefixes:
    before = json.loads((cache / (prefix + "-before.json")).read_text())
    after = json.loads((cache / (prefix + "-after.json")).read_text())
    assert before["clean"] and after["clean"] and after["matchesBefore"]
    assert before["head"] == after["head"] and before["files"] == after["files"]
    assert len(before["files"]) == 16
    head = before["head"]
    heads.add(head)
    assert before["tree"] == text("rev-parse", head + "^{tree}")
    assert before["srcTree"] == text("rev-parse", head + ":src")
    for name, row in before["files"].items():
        if not name.startswith("node_modules/"):
            assert sha(git("show", head + ":" + name)) == row["sha256"]
    run = {"prefix": prefix, "head": head, "tree": before["tree"], "srcTree": before["srcTree"],
           "command": before["command"], "exit": int((cache / (prefix + "-exit.txt")).read_text()),
           "relevantHashes": 16}
    xml = cache / (prefix + "-original.xml")
    if xml.exists():
        cases = list(ET.fromstring(xml.read_bytes()).iter("testcase"))
        rows = [{"name": case.attrib["name"], "classname": case.attrib.get("classname"),
                 "result": "fail" if case.findall("failure") or case.findall("error")
                 else "skip" if case.find("skipped") is not None else "pass",
                 "failures": [ET.tostring(node, encoding="unicode")
                              for node in list(case) if node.tag in ("failure", "error")]}
                for case in cases]
        run.update({"declarations": len(rows),
                    "counts": dict(collections.Counter(row["result"] for row in rows)),
                    "failureNodes": sum(len(row["failures"]) for row in rows)})
        archive(prefix + "-testcase-rows.json", (json.dumps(rows, indent=2) + "\n").encode())
    if "-types" in prefix:
        log = (cache / (prefix + "-original.log")).read_text()
        run["diagnostics"] = re.findall(r"^.*error TS\d+:.*$", log, re.M)
        run["orderedListFilesRows"] = sum(line.startswith("/") for line in log.splitlines())
    if "-lint" in prefix:
        rows = json.loads((cache / (prefix + "-original.json")).read_text())
        run.update({"lintFiles": len(rows), "errors": sum(row["errorCount"] for row in rows),
                    "warnings": sum(row["warningCount"] for row in rows)})
    runs.append(run)
    for path in sorted(cache.glob(prefix + "-*")):
        archive(path.name, path.read_bytes())

inputs = [line for line in (cache / "154-fixture-teardown-types-original.log").read_text().splitlines()
          if line.startswith("/")]
index = {}
for entry in git("ls-files", "-s", "-z").decode().split("\0"):
    if entry:
        header, name = entry.split("\t", 1)
        _, blob, stage = header.split()
        assert stage == "0"
        index[name] = blob
root = str(pathlib.Path.cwd()) + "/"
inventory = []
for ordinal, name in enumerate(inputs):
    raw = pathlib.Path(name).read_bytes()
    relative = name[len(root):] if name.startswith(root) else None
    tracked = relative in index
    blob = hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()
    if tracked:
        assert blob == index[relative]
    inventory.append({"ordinal": ordinal, "path": name, "relative": relative,
                      "tracked": tracked, "bytes": len(raw), "sha256": sha(raw),
                      "gitBlob": blob if tracked else None})
assert len(inputs) == 3959 and len(inputs) == len(set(inputs))
for name in [fixture, "src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts",
             "src/main/services/prepare-handoff-skill.test.ts"]:
    assert str(pathlib.Path(name).resolve()) in inputs
archive("154-owner-observed-after-execution-input-inventory.json",
        (json.dumps(inventory, indent=2) + "\n").encode())

old = git("show", base + ":" + fixture)
current = git("show", source + ":" + fixture)
red = git("show", "81c40696132e2b32382121fcaee107f86b4c8af7:" + fixture)
forward_red = git("show", "0007940501bba9b9fd341e6e1e8f5b16388bbb8d:" + fixture)
suffix = b"  it('keeps actual fixture preparation alive until teardown settles it'"
old_suffix, current_suffix = old[old.index(suffix):], current[current.index(suffix):]
assert old_suffix == current_suffix
start, end = b"beforeEach(async () => {", b"afterEach(cleanupFixture);"
old_owned = old[old.index(start):old.index(end) + len(end)]
red_owned = red[red.index(start):red.index(end) + len(end)]
assert old_owned == red_owned
end_forward = b"async function cleanupFixture():"
old_forward = old[old.index(start):old.index(end_forward)]
baseline_forward = forward_red[forward_red.index(start):forward_red.index(end_forward)]
assert old_forward == baseline_forward
bridges = {
    "old52TestBodies": {"bytes": len(old_suffix), "sha256": sha(old_suffix), "identical": True},
    "146OriginalOwnedWrapperAndCleanup": {"bytes": len(old_owned), "sha256": sha(old_owned), "identical": True},
    "151OriginalBeforeForwardMetadata": {"bytes": len(old_forward), "sha256": sha(old_forward), "identical": True},
    "unchangedFullSrcTree": text("rev-parse", source + ":src"),
}
archive("unchanged-source-bridges.json", (json.dumps(bridges, indent=2) + "\n").encode())
archive("unchanged-old52-test-bodies.txt", old_suffix)
archive("146-original-owned-wrapper-and-cleanup.txt", old_owned)
archive("151-original-before-forward-metadata.txt", old_forward)
for head in sorted(heads):
    archive("source-" + head + "-handoff-producer-admission.test.ts", git("show", head + ":" + fixture))
for prior in [base, "81c40696132e2b32382121fcaee107f86b4c8af7",
              "0007940501bba9b9fd341e6e1e8f5b16388bbb8d"]:
    archive("delta-" + prior + "-" + source + ".patch", git("diff", prior, source, "--", fixture))
report = (cache / "150-full-e08-review-original.md").read_bytes()
assert hashlib.sha1(f"blob {len(report)}\0".encode() + report).hexdigest() == "74ed6185885aacde7dc24c7dcf7b58f3bd9708f6"
for name in [
    "150-full-e08-review-original.md", "150-full-e08-review-original.stderr",
    "131-hosted-correction-command-receipt.cjs", "133-producer-hosted-correction-tsconfig.json",
    "156-teardown-pr-original.json", "156-teardown-refs-original.txt", "156-freeze-fixture-teardown.py",
]:
    archive(name, (cache / name).read_bytes())
pr = json.loads((cache / "156-teardown-pr-original.json").read_text())
assert pr["state"] == "OPEN" and pr["headRefOid"] == "7d244fcd153df00668ecac3d0709cece054801e3"
assert text("rev-parse", "HEAD") == source and not text("status", "--porcelain", "--untracked-files=no")
manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": source, "sourceTree": text("rev-parse", source + "^{tree}"),
    "srcTree": text("rev-parse", source + ":src"), "base": base,
    "selectedFile": fixture, "diffStat": text("diff", "--stat", base, source),
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-teardown-correction",
    "review": {"ref": "e08fa4e8c7753d9467db4829f723cd74eb5e9002",
               "path": "docs/qa-transfer/2026-11-22/reports/producer-hosted-c165-independent-review.md",
               "blob": "74ed6185885aacde7dc24c7dcf7b58f3bd9708f6", "bytes": len(report), "sha256": sha(report)},
    "pr": pr, "runs": runs, "archives": archives, "archiveCount": len(archives),
    "junitRows": sum(run.get("declarations", 0) for run in runs),
    "bridges": bridges,
    "compilerInputs": {"rows": len(inputs), "trackedVerified": sum(row["tracked"] for row in inventory),
                       "dependencyObserved": sum(not row["tracked"] for row in inventory),
                       "timing": "AFTER execution; not a pre/atomic/full dynamic runtime seal"},
    "limits": {"traceRows": 8, "outputRows": 8, "outputFields": 3, "toolNameCharacters": 80},
    "preserved": ["c165/6fa", "ab853 original45068217103 failure", "454/90fa/b6/2d363", "all prior originals"],
    "sourceAttribution": "153 exact6eaa8PASS/50SKIP/58 declarations;154 compiler/155 lint exactsamehead. 146/147/148/151 belong only to their own archived source. No aggregate58/full-handoff/hosted/landing acceptance.",
    "unresolved": "Windows first5000ms body timeout phase and all36 failure closure remain UNKNOWN. Forced synchronous diagnostic branch is simulation, not native Windows acceptance. Existing exactdelta review required before PR update.",
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"archives": len(archives), "junitRows": manifest["junitRows"], "source": source,
                  "bridges": bridges, "compilerInputs": manifest["compilerInputs"]}))
