import gzip
import hashlib
import json
import subprocess
from pathlib import Path
from xml.etree import ElementTree as ET

cache = Path("node_modules/.cache/native-handoff-ingress")
target = Path("docs/evidence/3613-real-handoff-producer/baseline")
target.mkdir(parents=True, exist_ok=True)


def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()


source = git("rev-parse", "HEAD")
assert source == "25317bb72a41d8b04f9bda104cc32b5908bed3b1"
assert not git("status", "--porcelain")
assert git("rev-parse", "HEAD:src") == git("rev-parse", "50c474b:src")
archives = []
names = [
    "67-producer-boundary-packet.json",
    "68-producer-boundary-readback.json",
    "69-producer-baseline-original.log",
    "69-producer-baseline-original.xml",
    "70-producer-ask-metadata-original.log",
    "70-producer-ask-metadata-original.xml",
    "70-producer-fixture-tsconfig.json",
    "71-producer-fixture-types-original.log",
    "73-producer-fixture-types-original.log",
    "74-producer-fixture-eslint-original.json",
    "74-producer-fixture-eslint-original.log",
    "75-producer-checks-readback.json",
    "76-review-download-enobufs-original.txt",
    "2d363-producer-design-review.md",
    "77-freeze-producer-baseline.py",
]
for name in names:
    raw = (cache / name).read_bytes()
    archived = target / (name + ".gz")
    archived.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(archived.read_bytes()) == raw
    archives.append({"original": name, "bytes": len(raw),
                     "sha256": hashlib.sha256(raw).hexdigest(),
                     "archive": archived.name,
                     "archiveSha256": hashlib.sha256(archived.read_bytes()).hexdigest()})

cases = []
for number, execution in [(69, "baseline-original"), (70, "ask-metadata-correction")]:
    xml = cache / ("69-producer-baseline-original.xml" if number == 69 else "70-producer-ask-metadata-original.xml")
    for case in ET.parse(xml).iter("testcase"):
        cases.append({"execution": execution, "name": case.get("name"), "classname": case.get("classname"),
                      "status": "fail" if case.find("failure") is not None or case.find("error") is not None
                      else "skip" if case.find("skipped") is not None else "pass",
                      "failureNodes": len(case.findall("failure"))})

log = (cache / "69-producer-baseline-original.log").read_text()
witness = json.loads(next(line.split("Original sender admission witness ", 1)[1]
                         for line in log.splitlines() if line.startswith("Original sender admission witness ")))
assert witness["generalGate"] == "open" and witness["sourceUnchanged"]
assert witness["handoffOfferGrant"] == "no_grant" and not witness["resultIsError"]
assert len(witness["beforeHistory"]) == 1 and len(witness["afterHistory"]) == 2
assert len(witness["beforeCatalog"]["entries"][0]["boundTo"]) == 1
assert len(witness["afterCatalog"]["entries"][0]["boundTo"]) == 2
manifest = {
    "source": source,
    "sourceTree": git("rev-parse", "HEAD^{tree}"),
    "baselineProduction": "50c474b48f57e0256661244bd29b9343ec112bc4",
    "productionTreeUnchanged": git("rev-parse", "HEAD:src"),
    "publishedSourceRef": "refs/heads/lane-3613-p2-routes/handoff-usable-path",
    "originalBoundary": {
        "commit": "664effcd1d6d10858c0c7904983628a0393a0780",
        "publishedRef": "refs/heads/lane-3613-p2-routes/handoff-producer-boundary",
        "branchFieldMeaning": "Original664 branch field names an unpublished local work branch at that time, not the published boundary review ref",
    },
    "design": {"commit": "2d363a2c592133155979ddd599d17453aa578404",
               "blob": "9e9c5ffbbea2934b3178fb8016b7ee2309bf2c05",
               "mcpGateBlob": "1e9c4e99e2700082b5946a88d6b4adf18cb60f37",
               "disposition": "DESIGN READY with refinements; production candidate not yet implemented or reviewed"},
    "executions": [
        {"number": 69, "source": "07a65c84c2a2ca90dac41cd4d0f8429f1bc512d0", "exit": 1,
         "pass": 2, "fail": 2, "cases": 4,
         "attribution": "Genuine stale-offer/catalog mutation case has three soft assertion failures; separate Ask fixture metadata incorrectly expected .args instead of actual .argumentsText after actual refusal/history/catalog assertions had passed"},
        {"number": 70, "source": "2ce67b22a5f81e34b57369fcd142ee7e3f7481e1", "exit": 0,
         "pass": 1, "skip": 3, "cases": 4,
         "attribution": "Only corrected Ask-first argumentsText case executed; no stale/current/Off rerun"},
        {"number": 71, "source": "2ce67b22a5f81e34b57369fcd142ee7e3f7481e1", "exit": 2,
         "diagnostics": 1, "attribution": "Own fixture implicit-any callback from untyped Function.bind; preserved original FAIL"},
        {"number": 73, "source": source, "exit": 0, "diagnostics": 0,
         "attribution": "Only two erased method type annotations added; same complete fixture plus ordinary production graph"},
        {"number": 74, "source": source, "exit": 0, "errors": 0, "warnings": 0},
    ],
    "typeGraph": json.loads((cache / "75-producer-checks-readback.json").read_text()),
    "cases": cases,
    "actualWitness": witness,
    "archives": archives,
    "limits": [
        "No final253 aggregate four-case execution or aggregate PASS claim",
        "No production edits, local E2E, live grants, human approval, bridge nonce, provider or agent process",
        "Actual real callTool/current evaluator/grantstore/exact call context, registered project and source, Git preparation/catalog and actual coordinator/history stores",
        "Only test queue scheduling is instrumented; every actual updater, authorizer, bind and save runs production code",
        "Explicit prepare happened before grant retirement; failed offer is not a global zero-local-IO assertion",
        "No native grant/preparation/content transport/application/wake/two-host/full-handoff/full-duplex acceptance transfer",
        "Original earlier166FAIL scoped nonregression and71/247 warnings remain separately attributed unchanged",
        "No global MCP-gate/forget cancellation change",
    ],
}
(target / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"source": source, "archives": len(archives), "caseRows": len(cases),
                  "typeGraph": manifest["typeGraph"]}))
