import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/hosted-failure-45068217103")
source = "7d244fcd153df00668ecac3d0709cece054801e3"
packet_path = cache / "129-ci-terminal-packet.json"
packet = json.loads(packet_path.read_text())


def git(*args):
    return subprocess.check_output(["git", *args]).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert git("rev-parse", "HEAD") == source
assert not git("status", "--porcelain", "--untracked-files=no")
assert packet["head"] == source and packet["run"] == 45068217103 and packet["attempt"] == 1
assert packet["conclusion"] == "failure" and packet["watcherExit"] == 1
assert packet["jobCounts"] == {"success": 31, "skipped": 4, "failure": 2}
assert len(packet["checkout"]) == 11 and len(packet["junit"]) == 4
assert all(row["srcTree"] == git("rev-parse", "HEAD:src") for row in packet["checkoutSources"])
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(path):
    data = path.read_bytes()
    relative = path.relative_to(cache)
    filename = str(relative).replace("/", "__") + ".gz"
    encoded = gzip.compress(data, mtime=0)
    target = out / filename
    if target.exists():
        assert target.read_bytes() == encoded
    else:
        target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == data
    archives.append({
        "file": filename, "originalPath": str(path), "bytes": len(data), "sha256": sha(data),
        "gzipBytes": len(encoded), "gzipSha256": sha(encoded),
    })


files = {
    cache / name for name in [
        "128-ci-owner-original.txt", "128-ci-supervisor-original.log", "128-ci-watch-original.log",
        "128-ci-watch-exit-original.txt", "128-ci-capture-exits-original.tsv",
        "128-watch-producer-admission.sh", "129-ci-terminal-packet.json",
        "126-producer-recipient-final-review-454-original.md", "127-pr-guards-before-original.json",
        "127-pr-readback-original.json", "130-freeze-producer-hosted-failure.py",
    ]
}
captures = []
for line in (cache / "128-ci-capture-exits-original.tsv").read_text().splitlines():
    name, result = line.split("\t")
    assert int(result) == 0, f"Original capture failed: {name}/{result}"
    captures.append({"file": name, "exit": int(result)})
    files.update([cache / name, cache / (name + ".stderr")])
files.update((cache / "129-ci-junit-original").rglob("*.xml"))
files.update(cache.glob("129-ci-checkout-*-original.json"))
for path in sorted(files):
    archive(path)
original_log = (cache / "129-ci-logs-original.log").read_bytes()
assert sha(original_log) == packet["originalLog"]["sha256"]

junit_rows = []
for entry in packet["junit"]:
    path = pathlib.Path(entry["file"])
    raw = path.read_bytes()
    assert sha(raw) == entry["sha256"]
    cases = list(ET.fromstring(raw).iter("testcase"))
    counts = collections.Counter(
        "fail" if case.find("failure") is not None or case.find("error") is not None
        else "skip" if case.find("skipped") is not None else "pass" for case in cases
    )
    assert dict(counts) == entry["allCounts"]
    junit_rows.append({"file": str(path), "rows": len(cases), "counts": dict(counts),
                       "selectedCounts": entry["selectedCounts"], "sha256": sha(raw)})

manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "pr": 3779, "source": source, "sourceTree": git("rev-parse", "HEAD^{tree}"),
    "srcTree": git("rev-parse", "HEAD:src"),
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-ci-failure",
    "run": packet["run"], "attempt": 1, "event": "pull_request", "conclusion": "failure",
    "jobCounts": packet["jobCounts"], "failedJobs": [
        row for row in packet["jobs"] if row["conclusion"] == "failure"
    ],
    "checkout": packet["checkout"], "checkoutSources": packet["checkoutSources"],
    "junit": junit_rows, "captures": captures, "archives": archives, "archiveCount": len(archives),
    "terminalPacketSha256": sha(packet_path.read_bytes()),
    "originalLogSha256": sha(original_log), "originalLogBytes": len(original_log),
    "review": "45495858a176a5971494cef2cfc5ae67ffbf9b18",
    "preservedOriginalFailure": {"run": 45046385831, "proofPrefix": "13703", "cause": "unknown"},
    "acceptance": "FAILURE, not a waiver/rerun or transferred local51-case/fullhandoff acceptance. Separate evidence ref; PR head/source unchanged.",
    "unresolved": [
        "Prepare-handoff skill valid-offer assertion fails both platforms; fixture/real agreement-scope root cause not yet executed.",
        "Windows36 producer testcases time out5000ms with cleanupEBUSY nodes; first-failure/held-work/cleanup cause remains unproven.",
    ],
}
assert git("rev-parse", "HEAD") == source and not git("status", "--porcelain", "--untracked-files=no")
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"archives": len(archives), "source": source, "run": packet["run"],
                  "conclusion": "failure", "junitRows": sum(row["rows"] for row in junit_rows)}))
