#!/usr/bin/env bash
set -u
set -o pipefail

root=node_modules/.cache/native-handoff-ingress
repo=Agent-Clubhouse/Clubhouse
head=7d244fcd153df00668ecac3d0709cece054801e3
branch=lane-3613-p2-routes/handoff-recipient-continuity
pr="$1"
capture() {
  local name="$1"
  shift
  "$@" > "$root/$name" 2> "$root/$name.stderr"
  local result=$?
  printf '%s\t%s\n' "$name" "$result" >> "$root/128-ci-capture-exits-original.tsv"
  return "$result"
}

printf 'Owner PID: %s; PR: %s; exact head: %s\n' "$$" "$pr" "$head" | tee "$root/128-ci-owner-original.txt"
run=""
for attempt in $(seq 1 20); do
  capture "128-ci-discovery-$attempt-original.json" gh run list --repo "$repo" --branch "$branch" --event pull_request --workflow validate.yml --limit 10 --json databaseId,event,headSha,status,conclusion,url || exit 91
  run=$(node - "$root/128-ci-discovery-$attempt-original.json" "$head" <<'NODE'
const fs = require('node:fs');
const assert = require('node:assert/strict');
const matches = JSON.parse(fs.readFileSync(process.argv[2])).filter(run => run.headSha === process.argv[3]);
assert(matches.length <= 1, 'Multiple automatic runs at this head require disposition');
if (matches.length === 1) console.log(matches[0].databaseId);
NODE
  ) || exit 92
  if [ -n "$run" ]; then break; fi
  printf 'Waiting for ordinary automatic trigger: %s/20\n' "$attempt"
  if [ "$attempt" -lt 20 ]; then sleep 30; fi
done
if [ -z "$run" ]; then
  printf 'No automatic exact-head Validate run in bounded discovery; no dispatch attempted\n'
  exit 93
fi

capture 128-ci-run-initial-original.json gh api "repos/$repo/actions/runs/$run" || exit 94
capture 128-ci-merge-ref-initial-original.json gh api "repos/$repo/git/ref/pull/$pr/merge" || exit 95
node - "$root/128-ci-run-initial-original.json" "$head" "$pr" <<'NODE' || exit 96
const fs = require('node:fs');
const assert = require('node:assert/strict');
const run = JSON.parse(fs.readFileSync(process.argv[2]));
assert.equal(run.head_sha, process.argv[3]);
assert.equal(run.event, 'pull_request');
assert.equal(run.run_attempt, 1);
assert(run.pull_requests.some(pr => pr.number === Number(process.argv[4])));
console.log(JSON.stringify({watching:run.id, head:run.head_sha, attempt:run.run_attempt, status:run.status, url:run.html_url}));
NODE

gh run watch "$run" --repo "$repo" --interval 60 --exit-status > "$root/128-ci-watch-original.log" 2>&1
watch_result=$?
printf '%s\n' "$watch_result" > "$root/128-ci-watch-exit-original.txt"
printf 'Automatic exact-head watcher terminal exit: %s\n' "$watch_result"

capture 129-ci-run-final-original.json gh api "repos/$repo/actions/runs/$run"
run_capture=$?
capture 129-ci-jobs-final-original.json gh api --paginate --slurp "repos/$repo/actions/runs/$run/jobs?filter=latest&per_page=100"
jobs_capture=$?
capture 129-ci-pr-final-original.json gh pr view "$pr" --repo "$repo" --json number,url,state,headRefOid,baseRefOid,mergeable,mergeStateStatus,statusCheckRollup,reviewDecision
pr_capture=$?
capture 129-ci-logs-original.log gh run view "$run" --repo "$repo" --log
logs_capture=$?
capture 129-ci-artifacts-original.json gh api --paginate --slurp "repos/$repo/actions/runs/$run/artifacts?per_page=100"
artifacts_capture=$?
capture 129-ci-refs-final-original.txt git ls-remote origin refs/heads/main "refs/heads/$branch"
refs_capture=$?
if [ "$run_capture" -ne 0 ] || [ "$jobs_capture" -ne 0 ] || [ "$pr_capture" -ne 0 ] || [ "$logs_capture" -ne 0 ] || [ "$artifacts_capture" -ne 0 ] || [ "$refs_capture" -ne 0 ]; then
  printf 'Terminal capture failure: run=%s jobs=%s pr=%s logs=%s artifacts=%s refs=%s; originals retained\n' "$run_capture" "$jobs_capture" "$pr_capture" "$logs_capture" "$artifacts_capture" "$refs_capture"
  exit 97
fi

test_artifacts=$(node - "$root/129-ci-artifacts-original.json" <<'NODE'
const fs = require('node:fs');
const pages = JSON.parse(fs.readFileSync(process.argv[2]));
console.log(pages.flatMap(page => page.artifacts).filter(artifact => artifact.name.startsWith('test-results-') && !artifact.expired).length);
NODE
) || exit 98
if [ "$test_artifacts" -gt 0 ]; then
  capture 129-ci-junit-download-original.txt gh run download "$run" --repo "$repo" --pattern 'test-results-*' --dir "$root/129-ci-junit-original" || exit 99
else
  printf 'No unexpired unit JUnit artifact published; this absence is NOT passing coverage\n' | tee "$root/129-ci-junit-absent-original.txt"
fi

python - "$pr" <<'PY'
import collections
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

root = pathlib.Path("node_modules/.cache/native-handoff-ingress")
head = "7d244fcd153df00668ecac3d0709cece054801e3"
source_tree = "2327da993691b55ac2d8fab1e33d6bc6b49f41ab"


def read(name):
    return json.loads((root / name).read_text())


run = read("129-ci-run-final-original.json")
pr = read("129-ci-pr-final-original.json")
jobs = [job for page in read("129-ci-jobs-final-original.json") for job in page["jobs"]]
assert run["head_sha"] == head and run["event"] == "pull_request" and run["run_attempt"] == 1
assert run["status"] == "completed"
assert pr["headRefOid"] == head and pr["number"] == int(sys.argv[1])
assert all(job["status"] == "completed" for job in jobs)
log_path = root / "129-ci-logs-original.log"
log = log_path.read_text()
lines = log.splitlines()
checkout = []
for index, line in enumerate(lines[:-1]):
    fields = line.split("\t", 2)
    if len(fields) != 3 or "checkout" not in fields[1].lower():
        continue
    if re.search(r'git(?:\.exe)?"? log -1 --format=%H', line):
        result = re.search(r"\b[0-9a-f]{40}\b", lines[index + 1])
        assert result, "No actual checkout result after checkout command"
        checkout.append({"job": fields[0], "step": fields[1], "sha": result[0],
                         "commandLine": index + 1, "resultLine": index + 2})
assert checkout, "No actual checkout witnesses in original logs"
checkout_sources = []
for sha in sorted({entry["sha"] for entry in checkout}):
    commit_path = root / f"129-ci-checkout-{sha}-commit-original.json"
    data = subprocess.check_output(["gh", "api", f"repos/Agent-Clubhouse/Clubhouse/git/commits/{sha}"])
    commit_path.write_bytes(data)
    commit = json.loads(data)
    assert commit["sha"] == sha
    tree_path = root / f"129-ci-checkout-{sha}-tree-original.json"
    data = subprocess.check_output(["gh", "api", f"repos/Agent-Clubhouse/Clubhouse/git/trees/{commit['tree']['sha']}"])
    tree_path.write_bytes(data)
    tree = json.loads(data)
    src = [entry for entry in tree["tree"] if entry["path"] == "src" and entry["type"] == "tree"]
    assert len(src) == 1 and src[0]["sha"] == source_tree, "Actual checkout src differs from approved source"
    checkout_sources.append({"checkout": sha, "tree": commit["tree"]["sha"], "srcTree": src[0]["sha"]})

junit = []
for path in sorted((root / "129-ci-junit-original").rglob("*.xml")):
    raw = path.read_bytes()
    document = ET.fromstring(raw)
    rows = []
    selected = []
    failed = []
    for case in document.iter("testcase"):
        failures = [{"tag": child.tag, "attributes": child.attrib, "text": child.text or ""}
                    for child in case if child.tag in ["failure", "error"]]
        status = "fail" if failures else "skip" if case.find("skipped") is not None else "pass"
        row = {"attributes": case.attrib, "status": status, "failures": failures}
        rows.append(row)
        identity = case.attrib.get("classname", "") + " " + case.attrib.get("name", "")
        if "handoff-producer-admission" in identity or "isolated real MCP producer domain admission" in identity or "handoff-tools" in identity:
            selected.append(row)
        if failures:
            failed.append(row)
    junit.append({
        "file": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "allCounts": dict(collections.Counter(row["status"] for row in rows)),
        "selectedCounts": dict(collections.Counter(row["status"] for row in selected)),
        "selectedRows": selected, "failedRows": failed,
    })
packet = {
    "run": run["id"], "url": run["html_url"], "head": head, "attempt": run["run_attempt"],
    "status": run["status"], "conclusion": run["conclusion"],
    "watcherExit": int((root / "128-ci-watch-exit-original.txt").read_text()),
    "pr": pr, "jobCounts": dict(collections.Counter(job["conclusion"] for job in jobs)),
    "jobs": [{"id": job["id"], "name": job["name"], "conclusion": job["conclusion"],
              "url": job["html_url"]} for job in jobs],
    "checkout": checkout, "checkoutSources": checkout_sources,
    "originalLog": {"file": str(log_path), "bytes": log_path.stat().st_size,
                    "sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()},
    "junit": junit, "junitPresent": bool(junit),
    "limits": "Actual automatic run and per-artifact rows only; not transferred local51-case or wholehandoff acceptance. Absent JUnit is explicit missing evidence, not passing coverage.",
    "preservedHistoricalFailure": {"run": 45046385831, "proofPrefix": "13703", "cause": "unknown"},
}
(root / "129-ci-terminal-packet.json").write_text(json.dumps(packet, indent=2) + "\n")
print(json.dumps({"run": packet["run"], "head": head, "conclusion": packet["conclusion"],
                  "jobCounts": packet["jobCounts"], "actualCheckouts": len(checkout),
                  "junitArtifacts": len(junit), "selectedPerArtifact": [
                      {"file": entry["file"], "counts": entry["selectedCounts"]} for entry in junit]}))
PY
packet_result=$?
gzip -c "$root/129-ci-logs-original.log" > "$root/129-ci-logs-original.log.gz"
gzip_result=$?
if [ "$packet_result" -ne 0 ] || [ "$gzip_result" -ne 0 ]; then
  printf 'Terminal packet/gzip failure: %s/%s; originals retained\n' "$packet_result" "$gzip_result"
  exit 100
fi
exit "$watch_result"
