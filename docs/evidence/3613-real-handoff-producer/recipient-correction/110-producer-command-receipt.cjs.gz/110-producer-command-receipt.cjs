const fs = require('node:fs');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const files = [
  'src/main/services/handoff-service.ts',
  'src/main/services/handoff-coordinator.ts',
  'src/main/services/handoff-preparations.ts',
  'src/main/services/handoff-host.ts',
  'src/main/services/clubhouse-mcp/handoff-permissions.ts',
  'src/main/services/clubhouse-mcp/tools/handoff-tools.ts',
  'src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts',
  'test/annex-v2/handoff-producer-admission.test.ts',
  'docs/annex-reverse-routes.md',
  'package.json', 'package-lock.json', 'tsconfig.json', 'vitest.config.ts',
  'node_modules/.cache/native-handoff-ingress/79-producer-candidate-tsconfig.json',
  'node_modules/.cache/native-handoff-ingress/110-producer-command-receipt.cjs',
];
const [output, command, beforeFile] = process.argv.slice(2);
if (!output || !command) throw new Error('Receipt requires an output path and full command.');
const status = git('status', '--porcelain');
const receipt = {
  capturedAt: new Date().toISOString(),
  command,
  node: process.version,
  branch: git('branch', '--show-current'),
  head: git('rev-parse', 'HEAD'),
  tree: git('rev-parse', 'HEAD^{tree}'),
  srcTree: git('rev-parse', 'HEAD:src'),
  clean: status === '',
  status,
  files: Object.fromEntries(files.map((file) => {
    const bytes = fs.readFileSync(file);
    return [file, {
      bytes: bytes.length,
      sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
      gitBlob: crypto.createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'),
    }];
  })),
};
if (beforeFile) {
  const before = JSON.parse(fs.readFileSync(beforeFile, 'utf8'));
  receipt.beforeFile = beforeFile;
  receipt.matchesBefore = before.clean && receipt.clean && before.head === receipt.head
    && before.tree === receipt.tree && before.srcTree === receipt.srcTree
    && before.command === receipt.command && JSON.stringify(before.files) === JSON.stringify(receipt.files);
}
fs.writeFileSync(output, JSON.stringify(receipt, null, 2) + '\n');
console.log(`${output}: ${receipt.head} clean=${receipt.clean} matchesBefore=${receipt.matchesBefore ?? 'n/a'}`);
if (!receipt.clean || receipt.matchesBefore === false) {
  console.error('Source/command receipt guard failed; original metadata was retained.');
  process.exitCode = 1;
}
