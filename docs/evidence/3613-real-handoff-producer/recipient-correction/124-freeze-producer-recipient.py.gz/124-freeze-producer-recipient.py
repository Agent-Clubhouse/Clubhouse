import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/recipient-correction")
source = "e90eab8bbf53c3592ffdf7ae76cd758311831848"
original = "f1c128853165a088698a06b875cd294ebac12472"
red_source = "1ae15bc6ef5cf346d15b9c0ac6adf3816374e117"
selected = [
    "src/main/services/clubhouse-mcp/handoff-permissions.ts",
    "src/main/services/handoff-host.ts",
    "test/annex-v2/handoff-producer-admission.test.ts",
    "docs/annex-reverse-routes.md",
]


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


assert text("rev-parse", "HEAD") == source
assert not text("status", "--porcelain", "--untracked-files=no")
assert set(text("diff", "--name-only", original, source).splitlines()) == set(selected)
assert text("rev-parse", f"{red_source}:src") == text("rev-parse", f"{original}:src")
assert text("rev-parse", f"{source}:{selected[2]}") == text("rev-parse", f"{red_source}:{selected[2]}")
for directory in ["candidate", "fence-correction"]:
    entry = f"docs/evidence/3613-real-handoff-producer/{directory}"
    assert text("rev-parse", f"{original}:{entry}") == text("rev-parse", f"{source}:{entry}")
review_path = cache / "119-producer-recipient-review-90-original.md"
assert blob(review_path.read_bytes()) == "92cb3a0b5922a38a9075a52030a25019d6d5ba56"
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, data, provenance):
    target = out / (name + ".gz")
    encoded = gzip.compress(data, mtime=0)
    if target.exists():
        assert target.read_bytes() == encoded, f"Existing archive differs: {target}"
    else:
        target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == data
    archives.append({
        "file": target.name, "rawBytes": len(data), "rawSha256": sha(data),
        "gzipBytes": len(encoded), "gzipSha256": sha(encoded), "provenance": provenance,
    })


checks = []
for number, name, head, exit_code in [
    (120, "producer-recipient-red", red_source, 1),
    (121, "producer-recipient-green", source, 0),
    (122, "producer-recipient-types", source, 0),
    (123, "producer-recipient-eslint", source, 0),
]:
    stem = f"{number}-{name}"
    before = json.loads((cache / f"{stem}-before.json").read_text())
    after = json.loads((cache / f"{stem}-after.json").read_text())
    assert before["head"] == after["head"] == head
    assert before["clean"] and after["clean"] and after["matchesBefore"]
    assert before["files"] == after["files"] and before["tree"] == after["tree"]
    assert before["tree"] == text("rev-parse", f"{head}^{{tree}}")
    assert before["srcTree"] == after["srcTree"] == text("rev-parse", f"{head}:src")
    assert len(before["files"]) == 15
    for file, recorded in before["files"].items():
        if not file.startswith("node_modules/"):
            assert recorded["gitBlob"] == text("rev-parse", f"{head}:{file}")
    log = (cache / f"{stem}-original.log").read_text()
    assert re.search(rf" END lane-p2 rc={exit_code}\s*$", log)
    assert int((cache / f"{stem}-exit.txt").read_text()) == exit_code
    for suffix in ["before.json", "after.json", "original.log", "exit.txt"]:
        path = cache / f"{stem}-{suffix}"
        archive(path.name, path.read_bytes(), {"source": head, "path": str(path)})
    checks.append({
        "run": number, "source": head, "exit": exit_code, "command": before["command"],
        "tree": before["tree"], "cleanBeforeAfter": True, "matchingRelevantHashes": True,
    })

xml_runs = []
for number, name, head, expected in [
    (120, "producer-recipient-red", red_source, {"pass": 8, "fail": 6, "skip": 37}),
    (121, "producer-recipient-green", source, {"pass": 14, "fail": 0, "skip": 37}),
]:
    path = cache / f"{number}-{name}-original.xml"
    rows = []
    for case in ET.parse(path).getroot().iter("testcase"):
        failures = [
            {"tag": item.tag, "attributes": item.attrib, "text": item.text or ""}
            for item in list(case) if item.tag in ["failure", "error"]
        ]
        skipped = [item.attrib for item in list(case) if item.tag == "skipped"]
        rows.append({
            "name": case.attrib["name"], "classname": case.attrib["classname"], "attributes": case.attrib,
            "status": "fail" if failures else "skip" if skipped else "pass",
            "failures": failures, "skipped": skipped,
        })
    counts = collections.Counter(row["status"] for row in rows)
    assert {key: counts.get(key, 0) for key in expected} == expected
    assert len(rows) == 51
    if number == 120:
        assert sum(len(row["failures"]) for row in rows) == 24
        assert all(item["attributes"].get("type") == "AssertionError" for row in rows for item in row["failures"])
    archive(path.name, path.read_bytes(), {"source": head, "path": str(path)})
    xml_runs.append({"run": number, "source": head, "counts": expected, "rows": rows})

type_log = (cache / "122-producer-recipient-types-original.log").read_text()
assert not re.search(r"error TS\d+:", type_log)
tracked = {}
for line in git("ls-tree", "-r", source).decode().splitlines():
    metadata, file = line.split("\t", 1)
    tracked[file] = metadata.split()[2]
inputs = []
for line in type_log.splitlines():
    if not line.startswith("/"):
        continue
    file = pathlib.Path(line)
    assert file.is_file(), f"Emitted compiler input missing: {line}"
    data = file.read_bytes()
    record = {"path": line, "bytes": len(data), "sha256": sha(data)}
    relative = str(file.relative_to(pathlib.Path.cwd()))
    if relative in tracked:
        assert blob(data) == tracked[relative]
        record["sourcePath"] = relative
        record["gitBlob"] = tracked[relative]
    inputs.append(record)
assert len(inputs) == 3958
for fixture in [selected[2], "src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts"]:
    assert str(pathlib.Path(fixture).resolve()) in [entry["path"] for entry in inputs]
inventory = {
    "capturePhase": "after executed compiler122, not a pre-execution or atomic full-input seal",
    "source": source, "orderedListFiles": True, "inputs": inputs,
}
inventory_path = cache / "122-producer-recipient-types-input-inventory-after.json"
encoded_inventory = (json.dumps(inventory, indent=2) + "\n").encode()
if inventory_path.exists():
    assert inventory_path.read_bytes() == encoded_inventory
else:
    inventory_path.write_bytes(encoded_inventory)
archive(inventory_path.name, encoded_inventory, {"source": source, "path": str(inventory_path)})
lint_path = cache / "123-producer-recipient-eslint-original.json"
lint = json.loads(lint_path.read_text())
assert len(lint) == 3 and sum(row["errorCount"] for row in lint) == sum(row["warningCount"] for row in lint) == 0
archive(lint_path.name, lint_path.read_bytes(), {"source": source, "path": str(lint_path)})
for name in [
    "79-producer-candidate-tsconfig.json", review_path.name,
    "110-producer-command-receipt.cjs", "124-freeze-producer-recipient.py",
]:
    path = cache / name
    archive(path.name, path.read_bytes(), {"path": str(path)})

source_rows = []
for index, file in enumerate(selected, 1):
    row = {"path": file}
    for label, commit in [("original", original), ("successor", source)]:
        data = git("show", f"{commit}:{file}")
        identity = text("rev-parse", f"{commit}:{file}")
        assert blob(data) == identity
        row[label] = {"source": commit, "blob": identity, "bytes": len(data), "sha256": sha(data)}
        archive(f"source-{index}-{label}.txt", data, {"source": commit, "path": file})
    source_rows.append(row)
for label, parent, child in [
    ("selected-delta", original, source), ("genuine-baseline-fixture", original, red_source),
    ("private-recipient-continuity", red_source, source),
]:
    archive(label + ".patch", git("diff", "--binary", parent, child, "--", *selected),
            {"parent": parent, "source": child, "paths": selected})
archive("genuine-baseline-complete-fixture.txt", git("show", f"{red_source}:{selected[2]}"),
        {"source": red_source, "path": selected[2]})

bridges = []


def bridge(file, start, end, label, scope=None):
    parts = []
    for commit in [original, source]:
        content = git("show", f"{commit}:{file}").decode()
        offset = content.index(start, content.index(scope) if scope else 0)
        parts.append(content[offset:content.index(end, offset) + len(end)])
    assert parts[0] == parts[1], label
    bridges.append({"label": label, "path": file, "sha256": sha(parts[0].encode()), "text": parts[0]})


bridge(selected[0], "export function withHandoffAgreementCall", "\n}", "original approval-version entry snapshot")
bridge(selected[0], "  const check = checkToolGrant", "\n}", "positive grant and Ask-versus-Allow final predicate")
bridge(selected[0], "export function handoffAgreementCallCurrent", "\n}", "final original-scope synchronous predicate")
bridge(selected[1], "    const observations = this.observations, revision", "    await observations;",
       "captured observation/revision pair", "class HandoffProducerOwner")
bridge(selected[1], "    this.verifiedRevision = revision;", "    this.check();",
       "only captured revision is verified", "class HandoffProducerOwner")
bridge(selected[1], "    if (this.retired || this.source && !this.sourceAgent && this.registrationLost",
       "      this.retire(); throw new HandoffAuthorizationChanged();\n    }",
       "original host/source/grant/observation continuity check", "class HandoffProducerOwner")
bridge(selected[1], "  admit(record: Handoff): void {", "\n  }",
       "synchronous actual admission before independent saves", "class HandoffProducerOwner")
helper = "src/main/services/agent-config.ts"
assert text("rev-parse", f"{original}:{helper}") == text("rev-parse", f"{source}:{helper}")
bridge_data = {
    "original": original, "source": source, "bridges": bridges,
    "unchangedRegistrationLease": {"path": helper, "blob": text("rev-parse", f"{source}:{helper}")},
    "limit": "Exact unchanged fragments, not entire unchanged verify/check methods or transferred runtime acceptance.",
}
archive("unchanged-closure-bridges.json", (json.dumps(bridge_data, indent=2) + "\n").encode(),
        {"original": original, "source": source})

manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": source, "sourceTree": text("rev-parse", f"{source}^{{tree}}"),
    "srcTree": text("rev-parse", f"{source}:src"), "originalCorrection": original,
    "originalCorrectionSource": "275df2b3c8e5fa81cc066d0b308edb6c59d9df61", "redSource": red_source,
    "review": {"commit": "90fa738c9e12d8df81953cdcaf33919f4799abdb",
               "blob": "92cb3a0b5922a38a9075a52030a25019d6d5ba56", "finding": "CP1-R1"},
    "publishedRef": "refs/heads/lane-3613-p2-routes/handoff-recipient-continuity",
    "sourceRows": source_rows, "checks": checks, "xmlRuns": xml_runs, "actualXmlRows": 102,
    "compiler": {"run": 122, "diagnostics": 0, "actualOrderedInputs": len(inputs),
                 "trackedInputsVerifiedToSourceGit": sum("gitBlob" in row for row in inputs),
                 "bothCompleteFixturesPresent": True, "inputHashesCapturedAfterExecution": True},
    "lint": {"run": 123, "files": 3, "errors": 0, "warnings": 0},
    "archives": archives, "archiveCount": len(archives),
    "receiptLimits": "Clean head/tree and15 relevant hashes observed before/after each admitted command; no exclusive filesystem or atomic full-input/executable seal. No older run is retrosealed.",
    "fixtureLimits": "Isolated real callTool/grant/Git/catalog/history assembly; delivered registry/config mutations and synthetic exact-call Ask answers. Local marker/POST absence is not itself a discriminator. No bridge/provider/native TLS/live-human acceptance.",
    "acceptance": "Unreviewed residual successor against90fa. Retained CP2/version/caller-context closures keep original source attribution.14 selected controls, not an aggregate51-case runtime pass; no PR/CI or whole-handoff/full-duplex acceptance.",
}
assert len(archives) == 37
assert text("rev-parse", "HEAD") == source and not text("status", "--porcelain", "--untracked-files=no")
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"source": source, "archives": len(archives), "xmlRuns": len(xml_runs),
                  "actualXmlRows": 102, "compiler": manifest["compiler"], "closureBridges": len(bridges)}))
