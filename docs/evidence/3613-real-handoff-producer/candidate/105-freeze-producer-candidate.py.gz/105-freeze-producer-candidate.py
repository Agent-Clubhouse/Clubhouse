import collections
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT = pathlib.Path.cwd()
CACHE = ROOT / "node_modules/.cache/native-handoff-ingress"
DEST = ROOT / "docs/evidence/3613-real-handoff-producer/candidate"
BASE = "50c474b48f57e0256661244bd29b9343ec112bc4"
SOURCE = "ad104a538772156af463f3750783fbf4cd99c39c"
PRODUCTION = "f05d72834653dbb1314c5083e3b6f82d8dd31f41"


def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd).decode().strip()


assert git("rev-parse", "HEAD") == SOURCE
assert git("rev-parse", f"{SOURCE}:src") == git("rev-parse", f"{PRODUCTION}:src")
assert git("status", "--porcelain") in ("", "?? docs/evidence/3613-real-handoff-producer/candidate/")
if DEST.exists():
    assert all(path.name.endswith(".gz") for path in DEST.iterdir())
else:
    DEST.mkdir()
archives = []


def archive(path, name=None):
    raw = path.read_bytes()
    name = name or path.name
    compressed = gzip.compress(raw, mtime=0)
    target = DEST / (name + ".gz")
    if target.exists():
        assert target.read_bytes() == compressed
    else:
        target.write_bytes(compressed)
    assert gzip.decompress((DEST / (name + ".gz")).read_bytes()) == raw
    item = {
        "original": str(path.relative_to(ROOT)),
        "archive": name + ".gz",
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "gzipSha256": hashlib.sha256(compressed).hexdigest(),
        "roundtrip": True,
    }
    archives.append(item)
    return item


runs = [
    ("84-producer-candidate", "e1f47fce8a5b6ca86b7eadcc98c0dfe1bcc3cb8e", {"PASS": 6, "SKIP": 15}, "initial candidate and coupled tool controls"),
    ("86-producer-continuity", "ff4ee53e10402e44899314af146650e78a8b01af", {"PASS": 16, "FAIL": 1, "SKIP": 4}, "genuine consumed-approval version red; other selected controls"),
    ("87-producer-ask-correction", "a20ba0cb2810061bf77ef1bcf64a5e8a83d1dc0e", {"PASS": 4, "SKIP": 19}, "matched approval correction/current/forget/wrong-context"),
    ("88-producer-durable-marker", "85b0f87b83afd0463d1e1e38504c16f185f3f9bc", {"PASS": 3, "SKIP": 22}, "durable identity and actual retained marker partial IO"),
    ("89-producer-target-window", "e3140b4af0b8d88fc05b6e1235aff454788a8a16", {"FAIL": 1, "SKIP": 25}, "genuine introduced cosmetic target-capture window red"),
    ("90-producer-target-owner-correction", PRODUCTION, {"PASS": 2, "SKIP": 24}, "matched target-window green and strengthened actual producer settlement"),
    ("93-negative-continuity", "83f91f8244e871f2bac556c8f98c165beef5f320", {"FAIL": 1, "SKIP": 25}, "semantic mutant: producer negative/final continuity omitted"),
    ("94-full-authorization", "c6184fdd501abebc4946dcea12392bfd98846848", {"FAIL": 2, "SKIP": 24}, "semantic mutant: actual queued full-positive authorization omitted"),
    ("95-recipient", "ed90b31ccbba52fd5d637301f3d574c2f3347366", {"FAIL": 1, "SKIP": 25}, "semantic mutant: exact canonical recipient correspondence omitted"),
    ("96-selection", "262b8ee284a0d0b42ba916894b1eefb6fe58eed3", {"FAIL": 1, "SKIP": 25}, "semantic mutant: exact selection admission/binding replaced by summary fallback"),
    ("97-post-owner", "19b992b72b431b62c6d6cddbce3b7b7f5491039a", {"FAIL": 1, "SKIP": 25}, "semantic mutant: original producer POST reference omitted; existing reverse POST owner retained"),
    ("98-producer-selected-dependency", "a8f0d35178aefe5b17d28590c04c690cc8cbba3b", {"FAIL": 2, "SKIP": 26}, "unsupported refusal fixture expectations, NOT an established production gap; branch preparation was not ready"),
    ("99-producer-mode-valid-baseline", "5e497b1a6324a5a155d3a2397785364f847ff737", {"FAIL": 1, "SKIP": 27}, "valid branch input but unsupported refusal expectation; source already serializes a new owned preparation"),
    ("100-producer-preparation-ownership", "20243bb2199edb83852720b6504f81d0fca7062d", {"PASS": 3, "SKIP": 26}, "correct source-bound original new source/mode and prior-read stop ownership; fixture-only correction, production unchanged"),
]
executions = []
for stem, source, expected, role in runs:
    xml = CACHE / (stem + "-original.xml")
    log = CACHE / (stem + "-original.log")
    rows = []
    for case in ET.parse(xml).iter("testcase"):
        assert case.get("name") and case.get("classname")
        failures = [node for node in case if node.tag in ("failure", "error")]
        status = "FAIL" if failures else "SKIP" if case.find("skipped") is not None else "PASS"
        rows.append({
            "name": case.get("name"), "class": case.get("classname"), "status": status,
            "failureNodes": [{"type": n.get("type"), "message": n.get("message"), "text": n.text} for n in failures],
        })
    assert dict(collections.Counter(row["status"] for row in rows)) == expected, (stem, rows)
    text = log.read_text()
    exit_code = 1 if expected.get("FAIL") else 0
    assert f"END lane-p2 rc={exit_code}" in text
    assert "START lane-p2" in text and "maxWorkers=1" in text
    mutated = stem[:2] in {"93", "94", "95", "96", "97"}
    executions.append({
        "id": stem, "source": source, "sourcePublishedViaCandidateAncestry": not mutated,
        "role": role, "exit": exit_code, "counts": expected, "cases": rows,
        "commandReceipt": archive(log), "xmlReceipt": archive(xml),
    })
    if mutated:
        assert git("rev-parse", source + "^") == PRODUCTION
        archive(CACHE / (stem + "-source.patch"))
        archive(CACHE / (stem + "-source.txt"))
        paths = git("diff", "--name-only", PRODUCTION, source).splitlines()
        assert len(paths) == 1
        archive(CACHE / stem / paths[0], stem + "-" + pathlib.Path(paths[0]).name)

checks = []
for number, source, expected in [
    ("79", "eaf75907c255dcca5217043398710f941e48af4e", 1),
    ("81", "365dea416ff7a035816f7a51307d9dd67b06f803", 1),
    ("83", "e1f47fce8a5b6ca86b7eadcc98c0dfe1bcc3cb8e", 0),
    ("85", "ff4ee53e10402e44899314af146650e78a8b01af", 0),
    ("91", PRODUCTION, 0),
    ("101", SOURCE, 0),
]:
    files = list(CACHE.glob(number + "-producer-*-types-original.log"))
    assert len(files) == 1, (number, files)
    log = files[0]
    text = log.read_text()
    ending = re.search(r"END lane-p2 rc=(\d+)", text)
    assert ending
    exit_code = int(ending.group(1))
    assert bool(exit_code) == bool(expected)
    errors = re.findall(r"error TS(\d+):", text)
    assert bool(errors) == bool(expected)
    checks.append({"kind": "types", "source": source, "exit": exit_code, "diagnostics": len(errors), "receipt": archive(log)})

for stem, source in [("92-producer-final-eslint", PRODUCTION), ("102-producer-complete-fixtures-eslint", SOURCE)]:
    data = json.loads((CACHE / (stem + "-original.json")).read_text())
    assert len(data) == 8 and not sum(item["errorCount"] + item["warningCount"] for item in data)
    checks.append({"kind": "eslint", "source": source, "exit": 0, "files": 8, "errors": 0, "warnings": 0,
                   "json": archive(CACHE / (stem + "-original.json")), "log": archive(CACHE / (stem + "-original.log"))})

for name in ["79-producer-candidate-tsconfig.json", "103-producer-final-checks-readback.json", "104-producer-publication-guards.txt"]:
    archive(CACHE / name)
archive(CACHE / "106-collector-v1-original.py")
archive(CACHE / "105-freeze-producer-candidate-original.log")
archive(pathlib.Path(__file__).resolve())
production = [
    "src/main/services/handoff-host.ts", "src/main/services/handoff-service.ts",
    "src/main/services/handoff-coordinator.ts", "src/main/services/handoff-preparations.ts",
    "src/main/services/clubhouse-mcp/handoff-permissions.ts", "src/main/services/clubhouse-mcp/tools/handoff-tools.ts",
]
fixtures = ["test/annex-v2/handoff-producer-admission.test.ts", "src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts"]
targets = production + fixtures + ["docs/annex-reverse-routes.md"]
assert set(git("diff", "--name-only", BASE, SOURCE, "--", "src").splitlines()) == set(production + [fixtures[1]])
patch = CACHE / "105-producer-selected-source.patch"
patch.write_text(subprocess.check_output(["git", "diff", "--binary", BASE, SOURCE, "--", *targets], cwd=ROOT).decode())
archive(patch)
manifest = {
    "source": SOURCE, "sourceTree": git("rev-parse", SOURCE + "^{tree}"), "base": BASE,
    "productionSource": PRODUCTION, "productionAndCoupledSrcTreeUnchangedSince": PRODUCTION,
    "srcTree": git("rev-parse", SOURCE + ":src"),
    "publishedBoundaryRef": {"ref": "refs/heads/lane-3613-p2-routes/handoff-producer-boundary", "commit": "664effcd1d6d10858c0c7904983628a0393a0780"},
    "publishedCandidateRef": "refs/heads/lane-3613-p2-routes/handoff-usable-path",
    "previousPublishedBaseline": "d09d4a835608eee388c1a014f4c08953cfbf220b",
    "designReport": {"commit": "2d363a2c592133155979ddd599d17453aa578404", "blob": "9e9c5ffbbea2934b3178fb8016b7ee2309bf2c05"},
    "files": [{"path": p, "sourceBlob": git("rev-parse", SOURCE + ":" + p),
               "baseBlob": git("rev-parse", BASE + ":" + p) if p != fixtures[0] else None} for p in targets],
    "diffStat": git("diff", "--stat", BASE, SOURCE, "--", *targets),
    "executions": executions, "checks": checks, "archives": archives,
    "completeRootCounts": json.loads((CACHE / "103-producer-final-checks-readback.json").read_text()),
    "authorityLimits": [
        "isolated real callTool/grants/registry/Git/catalog/history assembly; caller registration and approval input are synthetic fixtures",
        "remote saved member/public key and held transport adapter do not establish TLS/bridge/provider/live-human authority",
        "no native whole grant/preparation/content/apply/wake, two-host, whole-handoff or duplex acceptance",
        "case observations belong to their exact sources; no aggregate final-head runtime pass or repeated accepted lower/native proof",
        "mutant commits are local-only, full mutated source/patch/raw XML/logs are archived in the published packet",
        "98/99 failed unsupported refusal assertions are preserved, not recast as production defects",
        "101 PASS0 roots=2465 production+2 complete changed fixtures; not whole-suite execution or all fixtures typing",
        "102 PASS0 errors/0 warnings on exactly eight files; unrelated historical166 FAIL scoped nonregression and71/247 warning baselines remain separate",
    ],
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"source": SOURCE, "archives": len(archives), "xmlRuns": len(executions),
                  "actualXmlRows": sum(len(run["cases"]) for run in executions),
                  "checks": [(check["kind"], check["source"], check["exit"]) for check in checks],
                  "manifestSha256": hashlib.sha256((DEST / "manifest.json").read_bytes()).hexdigest()}, indent=2))
