import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/hosted-failure-45075711451")
head = "76656abec9b5f9a0fb6f6cd12b74178efcbf7ae2"
packet = json.loads((cache / "161-ci-terminal-packet.json").read_text())


def git(*args):
    return subprocess.check_output(["git", *args]).decode().strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git("rev-parse", "HEAD") == head and not git("status", "--porcelain")
assert packet["run"] == 45075711451 and packet["head"] == head and packet["attempt"] == 1
assert packet["conclusion"] == "failure" and packet["watcherExit"] == 1
assert packet["jobCounts"] == {"success": 31, "skipped": 4, "failure": 2}
assert len(packet["checkout"]) == 33 and packet["missingFailedJobCheckout"] == []
assert all(row["fullApprovedTreeMatch"] and row["approvedSrcMatch"] for row in packet["checkoutSources"])
assert len(packet["unitCheckoutCoverage"]) == 4 and all(row["witnesses"] for row in packet["unitCheckoutCoverage"])
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(path):
    raw = path.read_bytes()
    encoded = gzip.compress(raw, mtime=0)
    name = f"{len(archives) + 1:03d}-{path.name}.gz"
    assert len(name) < 160
    target = out / name
    assert not target.exists() or target.read_bytes() == encoded
    target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == raw
    archives.append({"file": name, "originalPath": str(path), "bytes": len(raw), "sha256": sha(raw),
                     "gzipBytes": len(encoded), "gzipSha256": sha(encoded)})


files = set()
captures = []
for line in (cache / "160-ci-capture-exits-original.tsv").read_text().splitlines():
    name, result = line.split("\t")
    assert int(result) == 0
    captures.append({"file": name, "exit": int(result)})
    files.update([cache / name, cache / (name + ".stderr")])
assert len(captures) == 10
for prefix in ["160-ci-", "161-ci-checkout-", "162-"]:
    files.update(path for path in cache.glob(prefix + "*") if path.is_file())
files.update((cache / "161-ci-junit-original").rglob("*.xml"))
files.update(path for path in (cache / "162-failed-chat-artifact-original").rglob("*") if path.is_file())
for name in [
    "161-ci-terminal-packet.json", "160-watch-approved-producer.sh", "161-capture-approved-producer.py",
    "157-full-4aa-review-original.md", "157-4aa-review-blob-original.json", "157-4aa-review-tree-original.json",
    "150-full-e08-review-original.md", "126-producer-recipient-final-review-454-original.md",
    "158-update-guards-original.json", "159-pr-updated-readback-original.json", "159-pr-updated-refs-original.txt",
    "163-freeze-approved-ci-failure.py",
]:
    files.add(cache / name)
for name in ["162-failed-chat-job-exit.txt", "162-failed-chat-artifact-download-exit.txt"]:
    assert int((cache / name).read_text()) == 0
for path in sorted(files):
    archive(path)
junit = []
xmls = sorted((cache / "161-ci-junit-original").rglob("*.xml")) + [cache / "162-failed-chat-artifact-original/junit.xml"]
for path in xmls:
    raw = path.read_bytes()
    cases = list(ET.fromstring(raw).iter("testcase"))
    counts = collections.Counter(
        "fail" if case.findall("failure") or case.findall("error")
        else "skip" if case.find("skipped") is not None else "pass" for case in cases
    )
    junit.append({"file": str(path), "bytes": len(raw), "sha256": sha(raw), "rows": len(cases),
                  "counts": dict(counts),
                  "failureNodes": sum(len(case.findall("failure")) + len(case.findall("error")) for case in cases)})
assert len(junit) == 5 and sum(row["rows"] for row in junit) == 73255
exact = json.loads((cache / "162-exact-unit-family-attribution.json").read_text())
chat = json.loads((cache / "162-failed-chat-junit-attribution.json").read_text())
assert chat["rows"] == 27 and chat["counts"] == {"pass": 20, "fail": 1, "skip": 6}
assert sha((cache / "161-ci-logs-original.log").read_bytes()) == packet["originalLog"]["sha256"]
assert git("rev-parse", "HEAD") == head and not git("status", "--porcelain", "--untracked-files=no")
manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": head, "sourceTree": git("rev-parse", "HEAD^{tree}"), "srcTree": git("rev-parse", "HEAD:src"),
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-ci-failure-45075711451",
    "run": packet["run"], "attempt": 1, "event": "pull_request", "conclusion": "failure",
    "jobCounts": packet["jobCounts"], "failedJobs": [row for row in packet["jobs"] if row["conclusion"] == "failure"],
    "checkout": packet["checkout"], "checkoutSources": packet["checkoutSources"],
    "unitCheckoutCoverage": packet["unitCheckoutCoverage"], "missingFailedJobCheckout": [],
    "junit": junit, "junitRows": sum(row["rows"] for row in junit), "exactUnitAttribution": exact,
    "chatAttribution": chat, "captures": captures, "archives": archives, "archiveCount": len(archives),
    "originalPacket": {"bytes": (cache / "161-ci-terminal-packet.json").stat().st_size,
                       "sha256": sha((cache / "161-ci-terminal-packet.json").read_bytes())},
    "originalLog": packet["originalLog"],
    "collectorPrecision": "Original161 heuristic prepare-skill contains three help/UI rows per OS. Preserved unchanged; exact162 classname ledger records six actual skill cases per OS, not nine.",
    "reviews": ["4aa19cba49b84ba28c4286e497348e1347ed7e51", "e08fa4e8c7753d9467db4829f723cd74eb5e9002",
                "45495858a176a5971494cef2cfc5ae67ffbf9b18"],
    "preservedOriginalFailure": {"run": 45068217103, "attempt": 1,
                                 "proof": "ab853c28ab03472425279bf159c370e16c27cc57"},
    "acceptance": "Actual terminal FAILURE, no rerun/waiver/PR update/landing or aggregate local58/fullhandoff acceptance.",
    "unresolved": "Windows first-delay/body-phase cause and subsequent continuation contamination require separate bounded attribution. Chat PDF-canvas failure is real and separate; no flake/preexisting/cause claim.",
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"archives": len(archives), "junitRows": manifest["junitRows"], "run": packet["run"],
                  "conclusion": packet["conclusion"], "source": head, "unitCaptures": len(captures)}))
