import collections
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

root = pathlib.Path("node_modules/.cache/native-handoff-ingress")
head = "76656abec9b5f9a0fb6f6cd12b74178efcbf7ae2"
expected_tree = "0526a2a05866a683981805b546365aaf3b98af69"
expected_src = "505ff0699b01779e52338e06a239d7cc15a6d2b1"


def read(name):
    return json.loads((root / name).read_text())


run = read("161-ci-run-final-original.json")
pr = read("161-ci-pr-final-original.json")
jobs = [job for page in read("161-ci-jobs-final-original.json") for job in page["jobs"]]
assert run["head_sha"] == head and run["event"] == "pull_request" and run["run_attempt"] == 1
assert run["status"] == "completed" and all(job["status"] == "completed" for job in jobs)
assert pr["number"] == 3779 and pr["headRefOid"] == head
log_path = root / "161-ci-logs-original.log"
raw_log = log_path.read_bytes()
lines = raw_log.decode().splitlines()
checkout = []
for index, line in enumerate(lines[:-1]):
    fields = line.split("\t", 2)
    if len(fields) != 3 or "[command]" not in fields[2]:
        continue
    if re.search(r'git(?:\.exe)?"? log -1 --format=%H', fields[2]):
        following = lines[index + 1].split("\t", 2)
        result = re.search(r"\b[0-9a-f]{40}\b", following[-1])
        assert result and following[0] == fields[0], "Missing actual same-job checkout result"
        checkout.append({"job": fields[0], "step": fields[1], "sha": result[0],
                         "commandLine": index + 1, "resultLine": index + 2})
assert checkout, "No actual checkout witnesses; all originals retained"
sources = []
for sha in sorted({entry["sha"] for entry in checkout}):
    commit_data = subprocess.check_output(["gh", "api", f"repos/Agent-Clubhouse/Clubhouse/git/commits/{sha}"])
    (root / f"161-ci-checkout-{sha}-commit-original.json").write_bytes(commit_data)
    commit = json.loads(commit_data)
    tree_data = subprocess.check_output(["gh", "api", f"repos/Agent-Clubhouse/Clubhouse/git/trees/{commit['tree']['sha']}"])
    (root / f"161-ci-checkout-{sha}-tree-original.json").write_bytes(tree_data)
    tree = json.loads(tree_data)
    src = [entry for entry in tree["tree"] if entry["path"] == "src" and entry["type"] == "tree"]
    assert len(src) == 1
    sources.append({"checkout": sha, "tree": commit["tree"]["sha"], "srcTree": src[0]["sha"],
                    "fullApprovedTreeMatch": commit["tree"]["sha"] == expected_tree,
                    "approvedSrcMatch": src[0]["sha"] == expected_src})
junit = []
for path in sorted((root / "161-ci-junit-original").rglob("*.xml")):
    raw = path.read_bytes()
    rows = []
    selected = []
    failed = []
    for case in ET.fromstring(raw).iter("testcase"):
        failures = [{"tag": child.tag, "attributes": child.attrib, "text": child.text or ""}
                    for child in case if child.tag in ("failure", "error")]
        status = "fail" if failures else "skip" if case.find("skipped") is not None else "pass"
        identity = case.attrib.get("classname", "") + " " + case.attrib.get("name", "")
        family = (
            "producer" if "handoff-producer-admission" in identity or "isolated real MCP producer domain admission" in identity
            else "coupled-tools" if "handoff-tools" in identity
            else "prepare-skill" if "prepare-handoff-skill" in identity or "the prepare-handoff skill" in identity
            else None
        )
        row = {"attributes": case.attrib, "status": status, "failures": failures, "family": family}
        rows.append(row)
        if family:
            selected.append(row)
        if failures:
            failed.append(row)
    junit.append({
        "file": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "allCounts": dict(collections.Counter(row["status"] for row in rows)),
        "selectedCounts": dict(collections.Counter(row["status"] for row in selected)),
        "families": {family: dict(collections.Counter(row["status"] for row in selected if row["family"] == family))
                     for family in ("producer", "coupled-tools", "prepare-skill")},
        "selectedRows": selected, "failedRows": failed,
    })
failed_jobs = [job for job in jobs if job["conclusion"] == "failure"]
missing_checkout_jobs = [
    {"id": job["id"], "name": job["name"]}
    for job in failed_jobs if not any(entry["job"] == job["name"] for entry in checkout)
]
unit_jobs = [job for job in jobs if job["name"].startswith("Unit + Component Tests")]
unit_coverage = [
    {"id": job["id"], "name": job["name"],
     "witnesses": [entry for entry in checkout if entry["job"] == job["name"]]}
    for job in unit_jobs
]
diagnostics = []
for index, line in enumerate(lines):
    if "Producer fixture teardown work:" in line:
        diagnostics.append({"line": index + 1,
                            "context": lines[max(0, index - 2):min(len(lines), index + 35)]})
packet = {
    "run": run["id"], "url": run["html_url"], "head": head, "attempt": run["run_attempt"],
    "status": run["status"], "conclusion": run["conclusion"],
    "watcherExit": int((root / "160-ci-watch-exit-original.txt").read_text()),
    "expectedTree": expected_tree, "expectedSrcTree": expected_src,
    "pr": pr, "jobCounts": dict(collections.Counter(job["conclusion"] for job in jobs)),
    "jobs": [{"id": job["id"], "name": job["name"], "conclusion": job["conclusion"],
              "url": job["html_url"]} for job in jobs],
    "checkout": checkout, "checkoutSources": sources, "unitCheckoutCoverage": unit_coverage,
    "missingFailedJobCheckout": missing_checkout_jobs,
    "allExtractedCheckoutsMatchApprovedFullTree": all(row["fullApprovedTreeMatch"] for row in sources),
    "originalLog": {"file": str(log_path), "bytes": len(raw_log),
                    "sha256": hashlib.sha256(raw_log).hexdigest()},
    "junit": junit, "junitPresent": bool(junit), "actualTeardownDiagnostics": diagnostics,
    "review": "4aa19cba49b84ba28c4286e497348e1347ed7e51",
    "preservedOriginalFailure": {"run": 45068217103, "attempt": 1,
                                 "proof": "ab853c28ab03472425279bf159c370e16c27cc57",
                                 "windowsFirstBodyPhase": "UNKNOWN"},
    "limits": "Actual automatic new-head run/per-artifact rows only. No transferred local58/fullhandoff or landing acceptance. Missing JUnit/checkouts and composition mismatches are explicit missing evidence.",
}
(root / "161-ci-terminal-packet.json").write_text(json.dumps(packet, indent=2) + "\n")
print(json.dumps({
    "run": packet["run"], "head": head, "conclusion": packet["conclusion"],
    "jobCounts": packet["jobCounts"], "actualCheckouts": len(checkout),
    "fullApprovedTreeMatch": packet["allExtractedCheckoutsMatchApprovedFullTree"],
    "missingFailedJobCheckout": missing_checkout_jobs, "unitCheckoutCoverage": [
        {"name": row["name"], "witnesses": len(row["witnesses"])} for row in unit_coverage],
    "junitArtifacts": len(junit), "perArtifact": [
        {"file": row["file"], "counts": row["allCounts"], "families": row["families"]}
        for row in junit],
    "teardownDiagnosticEvents": len(diagnostics),
}))
