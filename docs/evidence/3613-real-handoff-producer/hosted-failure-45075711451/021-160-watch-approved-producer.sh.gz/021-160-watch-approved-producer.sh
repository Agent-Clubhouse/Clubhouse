#!/usr/bin/env bash
set -u
set -o pipefail
root=node_modules/.cache/native-handoff-ingress
repo=Agent-Clubhouse/Clubhouse
head=76656abec9b5f9a0fb6f6cd12b74178efcbf7ae2
branch=lane-3613-p2-routes/handoff-recipient-continuity
pr=3779

capture() {
  local name="$1"
  shift
  "$@" > "$root/$name" 2> "$root/$name.stderr"
  local result=$?
  printf '%s\t%s\n' "$name" "$result" >> "$root/160-ci-capture-exits-original.tsv"
  return "$result"
}

printf 'Owner PID: %s; PR: %s; exact head: %s\n' "$$" "$pr" "$head" | tee "$root/160-ci-owner-original.txt"
run=""
for attempt in $(seq 1 20); do
  capture "160-ci-discovery-$attempt-original.json" gh run list --repo "$repo" --branch "$branch" --event pull_request --workflow validate.yml --limit 10 --json databaseId,event,headSha,status,conclusion,url || exit 91
  run=$(node - "$root/160-ci-discovery-$attempt-original.json" "$head" <<'NODE'
const fs = require('node:fs'), assert = require('node:assert/strict');
const runs = JSON.parse(fs.readFileSync(process.argv[2])).filter(run => run.headSha === process.argv[3]);
assert(runs.length <= 1, 'Multiple automatic runs at exact new head need disposition');
if (runs.length) console.log(runs[0].databaseId);
NODE
  ) || exit 92
  if [ -n "$run" ]; then break; fi
  printf 'Waiting for ordinary automatic trigger: %s/20\n' "$attempt"
  if [ "$attempt" -lt 20 ]; then sleep 30; fi
done
if [ -z "$run" ]; then
  printf 'Automatic exact-head discovery stalled; no dispatch attempted\n'
  exit 93
fi
capture 160-ci-run-initial-original.json gh api "repos/$repo/actions/runs/$run" || exit 94
capture 160-ci-merge-ref-initial-original.json gh api "repos/$repo/git/ref/pull/$pr/merge" || exit 95
node - "$root/160-ci-run-initial-original.json" "$head" "$pr" <<'NODE' || exit 96
const fs = require('node:fs'), assert = require('node:assert/strict');
const run = JSON.parse(fs.readFileSync(process.argv[2]));
assert.equal(run.head_sha, process.argv[3]);
assert.equal(run.event, 'pull_request');
assert.equal(run.run_attempt, 1);
assert(run.pull_requests.some(pr => pr.number === Number(process.argv[4])));
console.log(JSON.stringify({watching:run.id, head:run.head_sha, attempt:run.run_attempt,
 status:run.status, url:run.html_url}));
NODE
gh run watch "$run" --repo "$repo" --interval 60 --exit-status > "$root/160-ci-watch-original.log" 2>&1
watch_result=$?
printf '%s\n' "$watch_result" > "$root/160-ci-watch-exit-original.txt"
printf 'Exact new-head automatic watcher terminal exit: %s\n' "$watch_result"
capture 161-ci-run-final-original.json gh api "repos/$repo/actions/runs/$run"
run_capture=$?
capture 161-ci-jobs-final-original.json gh api --paginate --slurp "repos/$repo/actions/runs/$run/jobs?filter=latest&per_page=100"
jobs_capture=$?
capture 161-ci-pr-final-original.json gh pr view "$pr" --repo "$repo" --json number,url,state,headRefOid,baseRefOid,mergeable,mergeStateStatus,statusCheckRollup,reviewDecision
pr_capture=$?
capture 161-ci-logs-original.log gh run view "$run" --repo "$repo" --log
logs_capture=$?
capture 161-ci-artifacts-original.json gh api --paginate --slurp "repos/$repo/actions/runs/$run/artifacts?per_page=100"
artifacts_capture=$?
capture 161-ci-refs-final-original.txt git ls-remote origin refs/heads/main "refs/heads/$branch"
refs_capture=$?
if [ "$run_capture" -ne 0 ] || [ "$jobs_capture" -ne 0 ] || [ "$pr_capture" -ne 0 ] || [ "$logs_capture" -ne 0 ] || [ "$artifacts_capture" -ne 0 ] || [ "$refs_capture" -ne 0 ]; then
  printf 'Terminal capture stall run/jobs/pr/logs/artifacts/refs=%s/%s/%s/%s/%s/%s; originals retained\n' "$run_capture" "$jobs_capture" "$pr_capture" "$logs_capture" "$artifacts_capture" "$refs_capture"
  exit 97
fi
test_artifacts=$(node - "$root/161-ci-artifacts-original.json" <<'NODE'
const fs = require('node:fs');
const pages = JSON.parse(fs.readFileSync(process.argv[2]));
console.log(pages.flatMap(page => page.artifacts)
 .filter(artifact => artifact.name.startsWith('test-results-') && !artifact.expired).length);
NODE
) || exit 98
if [ "$test_artifacts" -gt 0 ]; then
  capture 161-ci-junit-download-original.txt gh run download "$run" --repo "$repo" --pattern 'test-results-*' --dir "$root/161-ci-junit-original" || exit 99
else
  printf 'No published unexpired unit JUnit; absence is not passing coverage\n' | tee "$root/161-ci-junit-absent-original.txt"
fi
python "$root/161-capture-approved-producer.py"
packet_result=$?
gzip -c "$root/161-ci-logs-original.log" > "$root/161-ci-logs-original.log.gz"
gzip_result=$?
if [ "$packet_result" -ne 0 ] || [ "$gzip_result" -ne 0 ]; then
  printf 'Terminal packet/gzip stall=%s/%s; originals retained\n' "$packet_result" "$gzip_result"
  exit 100
fi
exit "$watch_result"
