
const ts = require('typescript'), crypto = require('crypto');
const {execFileSync} = require('node:child_process');
const get = (head, file) => execFileSync('git', ['show', `${head}:${file}`], {encoding:'utf8'});
const file = 'src/main/services/prepare-handoff-skill.test.ts';
const before = get('a0b564ed499acc9dff2121c12849ee237401f20b', file);
const after = get('c1659088c68bd665fc1da0c61873729fcb9a85ee', file);
const parsed = ts.parseJsonConfigFileContent(
 ts.readConfigFile('tsconfig.json', ts.sys.readFile).config, ts.sys, process.cwd());
const emit = source => ts.transpileModule(source, {fileName:file,
 compilerOptions:{...parsed.options, noEmit:false, declaration:false, emitDeclarationOnly:false,
 sourceMap:false, inlineSourceMap:false}}).outputText;
const a=emit(before), b=emit(after);
if(!a.includes('withHandoffAgreementCall') || a!==b)
 throw new Error('Type-only fixture bridge lacks actual identical emitted JavaScript');
console.log(JSON.stringify({typescript:ts.version, fixture:file, oldHead:
 'a0b564ed499acc9dff2121c12849ee237401f20b', newHead:
 'c1659088c68bd665fc1da0c61873729fcb9a85ee', emittedBytes:Buffer.byteLength(a),
 sha256:crypto.createHash('sha256').update(a).digest('hex'), identical:true}));
