import collections
import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

cache = pathlib.Path("node_modules/.cache/native-handoff-ingress")
out = pathlib.Path("docs/evidence/3613-real-handoff-producer/hosted-fixture-correction")
source = "c1659088c68bd665fc1da0c61873729fcb9a85ee"
base = "7d244fcd153df00668ecac3d0709cece054801e3"
fixtures = ["src/main/services/prepare-handoff-skill.test.ts",
            "test/annex-v2/handoff-producer-admission.test.ts"]
prefixes = [
    "132-skill-original-refusal", "135-skill-original-scope", "136-skill-scope-green",
    "139-fixture-ownership-red", "140-fixture-ownership-green",
    "141-hosted-correction-types", "142-hosted-correction-types",
    "143-hosted-correction-types", "144-hosted-correction-lint",
]


def git(*args):
    return subprocess.check_output(["git", *args])


def text(*args):
    return git(*args).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert text("rev-parse", "HEAD") == source and not text("status", "--porcelain")
assert set(text("diff", "--name-only", base, source).splitlines()) == set(fixtures)
out.mkdir(parents=True, exist_ok=True)
archives = []


def archive(name, data):
    encoded = gzip.compress(data, mtime=0)
    target = out / (name + ".gz")
    assert not target.exists() or target.read_bytes() == encoded
    target.write_bytes(encoded)
    assert gzip.decompress(target.read_bytes()) == data
    archives.append({"file": target.name, "bytes": len(data), "sha256": sha(data),
                     "gzipBytes": len(encoded), "gzipSha256": sha(encoded)})


runs = []
heads = {base, source}
for prefix in prefixes:
    before = json.loads((cache / (prefix + "-before.json")).read_text())
    after = json.loads((cache / (prefix + "-after.json")).read_text())
    assert before["clean"] and after["clean"] and after["matchesBefore"]
    assert before["head"] == after["head"] and before["files"] == after["files"]
    assert len(before["files"]) == 16
    head = before["head"]
    heads.add(head)
    assert before["tree"] == text("rev-parse", head + "^{tree}")
    assert before["srcTree"] == text("rev-parse", head + ":src")
    for name, row in before["files"].items():
        if not name.startswith("node_modules/"):
            assert sha(git("show", head + ":" + name)) == row["sha256"]
    run = {"prefix": prefix, "head": head, "tree": before["tree"],
           "srcTree": before["srcTree"], "command": before["command"],
           "exit": int((cache / (prefix + "-exit.txt")).read_text()), "relevantHashes": 16}
    xml = cache / (prefix + "-original.xml")
    if xml.exists():
        cases = list(ET.fromstring(xml.read_bytes()).iter("testcase"))
        rows = [{"name": case.attrib["name"], "classname": case.attrib.get("classname"),
                 "result": "fail" if case.findall("failure") or case.findall("error")
                 else "skip" if case.find("skipped") is not None else "pass",
                 "failures": [ET.tostring(node, encoding="unicode")
                              for node in list(case) if node.tag in ("failure", "error")]}
                for case in cases]
        run.update({"declarations": len(rows),
                    "counts": dict(collections.Counter(row["result"] for row in rows)),
                    "failureNodes": sum(len(row["failures"]) for row in rows)})
        archive(prefix + "-testcase-rows.json", (json.dumps(rows, indent=2) + "\n").encode())
    if "-types" in prefix:
        log = (cache / (prefix + "-original.log")).read_text()
        run["diagnostics"] = re.findall(r"^.*error TS\d+:.*$", log, re.M)
        run["orderedListFilesRows"] = sum(line.startswith("/") for line in log.splitlines())
    if "-lint" in prefix:
        rows = json.loads((cache / (prefix + "-original.json")).read_text())
        run.update({"lintFiles": len(rows), "errors": sum(row["errorCount"] for row in rows),
                    "warnings": sum(row["warningCount"] for row in rows)})
    runs.append(run)
    for path in sorted(cache.glob(prefix + "-*")):
        archive(path.name, path.read_bytes())

compiler = cache / "143-hosted-correction-types-original.log"
inputs = [line for line in compiler.read_text().splitlines() if line.startswith("/")]
index = {}
for entry in git("ls-files", "-s", "-z").decode().split("\0"):
    if entry:
        header, name = entry.split("\t", 1)
        mode, blob, stage = header.split()
        assert stage == "0"
        index[name] = blob
root = str(pathlib.Path.cwd()) + "/"
inventory = []
for ordinal, name in enumerate(inputs):
    data = pathlib.Path(name).read_bytes()
    relative = name[len(root):] if name.startswith(root) else None
    tracked = relative in index
    blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
    if tracked:
        assert blob == index[relative]
    inventory.append({"ordinal": ordinal, "path": name, "relative": relative,
                      "tracked": tracked, "bytes": len(data), "sha256": sha(data),
                      "gitBlob": blob if tracked else None})
assert len(inputs) == 3959 and len(set(inputs)) == len(inputs)
for name in fixtures + ["src/main/services/clubhouse-mcp/tools/handoff-tools.test.ts"]:
    assert str(pathlib.Path(name).resolve()) in inputs
archive("143-owner-observed-after-execution-input-inventory.json",
        (json.dumps(inventory, indent=2) + "\n").encode())

bridge_script = """
const ts = require('typescript'), crypto = require('crypto');
const {execFileSync} = require('node:child_process');
const get = (head, file) => execFileSync('git', ['show', `${head}:${file}`], {encoding:'utf8'});
const file = 'src/main/services/prepare-handoff-skill.test.ts';
const before = get('a0b564ed499acc9dff2121c12849ee237401f20b', file);
const after = get('c1659088c68bd665fc1da0c61873729fcb9a85ee', file);
const parsed = ts.parseJsonConfigFileContent(
 ts.readConfigFile('tsconfig.json', ts.sys.readFile).config, ts.sys, process.cwd());
const emit = source => ts.transpileModule(source, {fileName:file,
 compilerOptions:{...parsed.options, noEmit:false, declaration:false, emitDeclarationOnly:false,
 sourceMap:false, inlineSourceMap:false}}).outputText;
const a=emit(before), b=emit(after);
if(!a.includes('withHandoffAgreementCall') || a!==b)
 throw new Error('Type-only fixture bridge lacks actual identical emitted JavaScript');
console.log(JSON.stringify({typescript:ts.version, fixture:file, oldHead:
 'a0b564ed499acc9dff2121c12849ee237401f20b', newHead:
 'c1659088c68bd665fc1da0c61873729fcb9a85ee', emittedBytes:Buffer.byteLength(a),
 sha256:crypto.createHash('sha256').update(a).digest('hex'), identical:true}));
"""
bridge = json.loads(subprocess.check_output(["node", "-e", bridge_script]))
assert git("show", "dd508e39270d6d55bfd2c62eee5d3a974d5ea220:" + fixtures[1]) == pathlib.Path(fixtures[1]).read_bytes()
archive("fixture-type-only-emission-bridge.json", (json.dumps(bridge, indent=2) + "\n").encode())
archive("fixture-type-only-emission-bridge-script.js", bridge_script.encode())
for head in sorted(heads):
    for name in fixtures:
        archive("source-" + head + "-" + pathlib.Path(name).name, git("show", head + ":" + name))
for old, new in [
    (base, source), ("71b929176e5fa67d952398d919e9f429d2ea1e0b", "a0b564ed499acc9dff2121c12849ee237401f20b"),
    ("330ff895484a86e899bfc86ae9454be77044134f", "dd508e39270d6d55bfd2c62eee5d3a974d5ea220"),
    ("dd508e39270d6d55bfd2c62eee5d3a974d5ea220", source),
]:
    archive("delta-" + old + "-" + new + ".patch", git("diff", old, new, "--", *fixtures))
original_log = (cache / "129-ci-logs-original.log").read_bytes()
assert sha(original_log) == "0e8e92dc8af0a2ea2ea2b73cacf35ca9b102e169ab16a07ec81a7563c7f54272"
lines = original_log.decode().splitlines()
excerpt = "\n".join(f"{i + 1}: {lines[i]}" for i in range(63510 - 1, 63565))
archive("original-windows-log-lines-63510-63565.txt", (excerpt + "\n").encode())
for name in [
    "131-hosted-correction-command-receipt.cjs", "133-producer-hosted-correction-tsconfig.json",
    "145-correction-pr-original.json", "145-correction-refs-original.txt",
    "126-producer-recipient-final-review-454-original.md", "145-freeze-hosted-fixture-correction.py",
]:
    archive(name, (cache / name).read_bytes())
pr = json.loads((cache / "145-correction-pr-original.json").read_text())
assert pr["headRefOid"] == base and pr["state"] == "OPEN"
assert text("rev-parse", "HEAD") == source
assert not text("status", "--porcelain", "--untracked-files=no")
manifest = {
    "schema": 1, "capturedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": source, "sourceTree": text("rev-parse", source + "^{tree}"),
    "srcTree": text("rev-parse", source + ":src"), "base": base, "pr": pr,
    "publicationRef": "refs/heads/lane-3613-p2-routes/handoff-producer-hosted-correction",
    "selectedFiles": fixtures, "diffStat": text("diff", "--stat", base, source),
    "runs": runs, "archives": archives, "archiveCount": len(archives),
    "junitRows": sum(run.get("declarations", 0) for run in runs),
    "compilerInputs": {"rows": len(inputs), "trackedVerified": sum(row["tracked"] for row in inventory),
                       "dependencyObserved": sum(not row["tracked"] for row in inventory),
                       "timing": "AFTER execution; not a pre/atomic/full dynamic runtime seal"},
    "bridge": bridge,
    "sourceAttribution": "136 six-case runtime only at a0;140 two-case runtime only at dd508. Final c165 has same producer bytes and type-only skill delta/identical TS emission. No final-head aggregate runtime execution.",
    "originalHostedFailure": {"run": 45068217103, "attempt": 1, "proof":
                             "ab853c28ab03472425279bf159c370e16c27cc57", "conclusion": "failure"},
    "review": "45495858a176a5971494cef2cfc5ae67ffbf9b18",
    "unresolved": "Windows first5000ms body timeout phase remains UNKNOWN. Cleanup ownership red/green does not prove all36 Windows timeout closure. No producer full52/final-head runtime, fullhandoff, CI/update/landing acceptance.",
}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"archives": len(archives), "rows": manifest["junitRows"],
                  "source": source, "compilerInputs": manifest["compilerInputs"], "bridge": bridge}))
