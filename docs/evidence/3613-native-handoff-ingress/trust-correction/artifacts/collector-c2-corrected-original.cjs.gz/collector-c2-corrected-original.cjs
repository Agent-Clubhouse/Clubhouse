const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const zlib = require('node:zlib');
const ts = require('typescript');

const root = process.cwd();
const cache = path.join(root, 'node_modules/.cache/native-handoff-ingress');
const output = path.join(root, 'docs/evidence/3613-native-handoff-ingress/candidate');
const base = '70eff94e9042ccc304e68282e76afc9065497858';
const source = '940365ecde7ca2e9fb31abf48362a938445e1fe5';
const baseline = 'c06ba470326b72b41568950e6e6e44f8b690e9bf';
const git = (args, cwd = root) => execFileSync('git', ['--no-pager', ...args], { cwd, encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });
const hash = (bytes, algorithm = 'sha256') => crypto.createHash(algorithm).update(bytes).digest('hex');
const describe = (bytes) => ({
  bytes: bytes.length, sha256: hash(bytes),
  gitBlob: hash(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`), bytes]), 'sha1'),
});
const bytesAt = (file) => fs.readFileSync(path.join(root, file));
const tracked = (ref, file) => {
  const bytes = bytesAt(file), expected = git(['rev-parse', `${ref}:${file}`]).trim();
  assert.equal(describe(bytes).gitBlob, expected, `Current bytes differ from ${ref}:${file}`);
  return { path: file, ...describe(bytes) };
};
assert.equal(git(['rev-parse', 'HEAD']).trim(), source);
assert.equal(git(['status', '--porcelain']).trim(), '');
const changes = git(['diff', '--name-only', base, source]).trim().split('\n');
assert.deepEqual(changes.filter((p) => p.startsWith('src/') && !p.endsWith('.test.ts')).sort(), [
  'src/main/services/annex-server.ts', 'src/main/services/handoff-coordinator.ts',
  'src/main/services/handoff-host.ts', 'src/main/services/handoff-service.ts',
]);
const sourceInputs = [
  'src/main/services/annex-server.ts', 'src/main/services/handoff-host.ts',
  'src/main/services/handoff-coordinator.ts', 'src/main/services/handoff-service.ts',
  'src/main/services/handoff-host.test.ts', 'src/main/services/handoff-coordinator.test.ts',
  'src/main/services/handoff-service.test.ts', 'test/annex-v2/annex-native-handoff-admission.test.ts',
  'docs/annex-native-handoff-admission.md',
].map((file) => tracked(source, file));

const configPath = path.join(cache, 'changed-fixture-types.json');
const config = ts.readConfigFile(configPath, ts.sys.readFile);
assert.equal(config.error, undefined);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, path.dirname(configPath));
assert.equal(parsed.errors.length, 0);
const typeLog = fs.readFileSync(path.join(cache, '13-types-original.log'), 'utf8');
assert.match(typeLog, /END lane-p2 rc=0/);
assert.doesNotMatch(typeLog, /error TS\d+/);
const compilerPaths = typeLog.split(/\r?\n/).filter((line) => path.isAbsolute(line) && fs.existsSync(line));
assert.equal(new Set(compilerPaths).size, compilerPaths.length);
assert.equal(compilerPaths.length, 3960);
const typeInputs = compilerPaths.map((file) => ({
  path: path.relative(root, file), ...describe(fs.readFileSync(file)),
}));
const rootInputs = parsed.fileNames.map((file) => path.relative(root, file));
const changedFixtures = sourceInputs.filter((input) => input.path.endsWith('.test.ts')).map((input) => input.path);
for (const file of changedFixtures) {
  assert(rootInputs.includes(file), `Changed fixture absent from compiler roots: ${file}`);
  assert(typeInputs.some((input) => input.path === file), `Changed fixture absent from actual compiler inputs: ${file}`);
}

const lint = JSON.parse(fs.readFileSync(path.join(cache, '12-eslint-original.json'), 'utf8'));
const lintBase = JSON.parse(fs.readFileSync(path.join(cache, '11-server-baseline-eslint-original.json'), 'utf8'));
assert.equal(lint.length, 8);
assert.equal(lint.reduce((sum, file) => sum + file.errorCount, 0), 0);
assert.equal(lint.reduce((sum, file) => sum + file.warningCount, 0), 71);
assert.equal(lintBase[0].warningCount, 71);
const serverPatch = git(['diff', '--unified=0', base, source, '--', 'src/main/services/annex-server.ts']);
const hunks = [...serverPatch.matchAll(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/gm)].map((match) => ({
  old: Number(match[1]), oldCount: match[2] === undefined ? 1 : Number(match[2]),
  addedCount: match[4] === undefined ? 1 : Number(match[4]),
}));
const mapLine = (line) => {
  if (line === undefined) return undefined;
  let delta = 0;
  for (const hunk of hunks) {
    if (!hunk.oldCount) {
      if (line > hunk.old) delta += hunk.addedCount;
    } else if (line >= hunk.old + hunk.oldCount) delta += hunk.addedCount - hunk.oldCount;
    else if (line >= hunk.old) throw new Error(`Baseline warning intersects a changed source line: ${line}`);
  }
  return line + delta;
};
const warning = (message, map = (line) => line) => ({
  rule: message.ruleId, severity: message.severity, message: message.message,
  line: map(message.line), column: message.column, endLine: map(message.endLine), endColumn: message.endColumn,
});
const currentServer = lint.find((file) => file.filePath.endsWith('/src/main/services/annex-server.ts'));
assert.deepEqual(currentServer.messages.map((message) => warning(message)),
  lintBase[0].messages.map((message) => warning(message, mapLine)));

const baseFiles = git(['ls-tree', '-r', '--name-only', base]).trim().split('\n');
const fixtures = baseFiles.filter((file) => file.startsWith('test/') && file.includes('/fixtures/') && file.endsWith('.json')).map((file) => tracked(base, file));
const canonical = fixtures.filter((file) => file.path.startsWith('test/fixtures/annex-mobile/'));
assert.equal(fixtures.length, 106);
assert.equal(fixtures.reduce((sum, file) => sum + file.bytes, 0), 1547788);
assert.equal(canonical.length, 103);
assert.equal(canonical.reduce((sum, file) => sum + file.bytes, 0), 1529625);
const protectedNames = [
  'src/main/services/annex-client.ts', 'src/main/services/annex-control.ts',
  'src/shared/annex-control-protocol.ts', 'src/main/services/annex-control-bulk.ts',
  'src/main/services/annex-reach.ts', 'src/main/services/annex-peers.ts',
  'docs/annex-route-contract-3611.md', 'src/shared/handoffs.ts',
  'package.json', 'package-lock.json', 'tsconfig.json', 'eslint.config.mjs',
  ...baseFiles.filter((file) => file.startsWith('src/main/services/handoff-') && !changes.includes(file)),
];
const protectedInputs = [...new Set(protectedNames)].map((file) => tracked(base, file));
const lowerProof = baseFiles.filter((file) => file.startsWith('docs/evidence/3613-reverse-handoff/')
  || file.startsWith('docs/evidence/3613-handoff-reverse-sync/')
  || file === 'test/annex-v2/annex-reverse-handoff-sync.test.ts'
  || file === 'test/annex-v2/reverse-desktop-fixture.ts').map((file) => tracked(base, file));

const unescape = (value) => value.replaceAll('&amp;', '&').replaceAll('&quot;', '"').replaceAll('&apos;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>');
const tests = (name) => {
  const xml = fs.readFileSync(path.join(cache, name), 'utf8');
  const cases = [...xml.matchAll(/<testcase\b([^>]*)(?:\/>|>([\s\S]*?)<\/testcase>)/g)].map((match) => ({
    name: unescape(/(?:^|\s)name="([^"]*)"/.exec(match[1])[1]),
    class: unescape(/(?:^|\s)classname="([^"]*)"/.exec(match[1])[1]),
    status: /<(failure|error)\b/.test(match[2] ?? '') ? 'fail' : /<skipped\b/.test(match[2] ?? '') ? 'skipped' : 'pass',
  }));
  return { cases, pass: cases.filter((test) => test.status === 'pass').length,
    fail: cases.filter((test) => test.status === 'fail').length,
    skipped: cases.filter((test) => test.status === 'skipped').length };
};
const final = tests('14-native-final-original.xml');
const queue = tests('15-queue-mutant-original.xml'), postauth = tests('16-postauth-mutant-original.xml');
assert.deepEqual([final.pass, final.fail, final.skipped], [35, 0, 75]);
assert.deepEqual([queue.pass, queue.fail, queue.skipped], [1, 3, 27]);
assert.deepEqual([postauth.pass, postauth.fail, postauth.skipped], [1, 4, 39]);

fs.mkdirSync(path.join(output, 'artifacts'), { recursive: true });
const artifacts = [];
const preserve = (name, bytes) => {
  const compressed = zlib.gzipSync(bytes, { level: 9, mtime: 0 });
  fs.writeFileSync(path.join(output, 'artifacts', `${name}.gz`), compressed);
  artifacts.push({ name: `artifacts/${name}.gz`, raw: describe(bytes), stored: describe(compressed) });
};
for (const name of fs.readdirSync(cache).filter((name) => /^(0[4-9]|1[0-7])-.*original\.(log|json|xml|cjs)$/.test(name)).sort()) {
  preserve(name, fs.readFileSync(path.join(cache, name)));
}
assert(artifacts.some((file) => file.name.startsWith('artifacts/04-')), 'Original candidate gate refusal is absent');
preserve('changed-fixture-types-original.json', fs.readFileSync(configPath));
preserve('type-inputs-original.json', Buffer.from(`${JSON.stringify({ rootInputs, compilerInputs: typeInputs }, null, 2)}\n`));
preserve('server-source-patch-original.patch', Buffer.from(serverPatch));
preserve('parent-milestone-undelivered-original.json', fs.readFileSync(path.join(cache, 'parent-milestone-undelivered.json')));
preserve('collector-original.cjs', fs.readFileSync(__filename));
const mutants = [['queue', queue], ['postauth', postauth]].map(([name, result]) => {
  const directory = path.join(cache, `${name}-mutant-work`);
  assert.equal(git(['rev-parse', 'HEAD'], directory).trim(), source);
  assert.equal(git(['diff', '--name-only'], directory).trim(), 'src/main/services/handoff-service.ts');
  const patch = git(['diff', '--', 'src/main/services/handoff-service.ts'], directory);
  preserve(`${name}-mutant-source-original.patch`, Buffer.from(patch));
  return { name, source, file: 'src/main/services/handoff-service.ts',
    changedFile: describe(fs.readFileSync(path.join(directory, 'src/main/services/handoff-service.ts'))), result };
});
const boundaryReview = describe(fs.readFileSync(path.join(cache, '3e06-boundary-review.md')));
assert.equal(boundaryReview.gitBlob, 'cc7b465f4ae08f90d24c3b28c8795becadd4f16e');
const manifest = {
  schemaVersion: 1, observedAt: new Date().toISOString(), base, baseline, source,
  sourceTree: git(['rev-parse', `${source}^{tree}`]).trim(),
  branch: git(['branch', '--show-current']).trim(),
  boundaryReview: { commit: '3e06e4f4e6a3c7ce9bc290a889fc06a02bd46dac',
    path: 'docs/qa-transfer/2026-11-22/reports/native-handoff-ingress-70eff-boundary-review.md', ...boundaryReview },
  sourceInputs, final, mutants,
  types: { diagnostics: 0, inputs: compilerPaths.length, rootInputs: rootInputs.length, changedFixtures,
    identitiesAreAfterExecutionObservations: true },
  lint: { files: 8, errors: 0, warnings: 71, serverBaselineWarnings: 71,
    exactRuleMessageColumnAndMappedSourceLineEquality: true, wholeRepository160WarningBaselineStillUnmeasured: true },
  fixtures, canonical: { files: canonical.length, bytes: canonical.reduce((sum, file) => sum + file.bytes, 0) },
  protectedInputs, lowerProof,
  inheritedAcceptance: { lowerSource: 'a4074c7f5e76714bbe346ecee1acfc434307de0e',
    lowerProof: 'be01f8bd511dba2a625462021732c119ce6b170e',
    lowerReview: '74d2ed4f64c1e9d539339e5a75b7c3c31171e8b3',
    synchronizedSource: '9a5247cadf41756bc1c085a87c59493b34d5e99f',
    synchronizedReview: '6f15b83d35a86b25dd24cfac4289de3bc9440909',
    rerun: false, old81937BytesTransportEnvelopeOnly: true, fullHandoffAcceptance: false },
  limits: [
    'Native receiver route/router/control dispatch, TLS identities/pins, real authorizer implementation and real history/command stores.',
    'Dispatcher availability and absent runtime are fixture inputs; synthetic metadata, not an approved native MCP producer/preparation/grant execution.',
    'Host/service/coordinator fixtures have mocked policy/identity seams and are not native TLS permission proof.',
    'Native deadline and mixed outgoing lifetime use fake timeout timers with actual queue/save/native TLS work where specified.',
    'IO faults are injected at actual before-rename versus after-real-rename operations; ambiguous disk/cache divergence is not claimed rolled back.',
    'Retirement before queued/postauthorization admission refuses; after admission may commit with matching memory and normal retained-history notice.',
    'Separately admitted maintenance and retired outgoing POST lifetime remain unchanged; no global zero-write or all-network-operation drain promise.',
    'No protocol/capability/grant/shared-store/worker/preparation/apply/wake/provider/human-gate/two-host/full-duplex acceptance.',
    'No new PR/CI/hosted-E2E execution; exact independent implementation/proof review remains pending.',
    'Original fixture failures, candidate failures and gate refusal are preserved; failed-assertion downstream checks are uncredited.',
  ],
  artifacts,
};
fs.writeFileSync(path.join(output, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ source, sourceTree: manifest.sourceTree, final: [final.pass, final.fail, final.skipped],
  types: manifest.types, lint: manifest.lint, fixtures: fixtures.length, protectedInputs: protectedInputs.length,
  lowerProof: lowerProof.length, artifacts: artifacts.length,
  manifest: describe(fs.readFileSync(path.join(output, 'manifest.json'))) }, null, 2));
