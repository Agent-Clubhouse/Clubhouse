const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { execFileSync } = require('node:child_process');
const ts = require('typescript');
const source = 'ef5e2f53ea9c3af94e7f22e23d9f0c5432b7a596';
const oldProof = '0da6a65fa4973658efe9964a4971ad9bc85d1912';
const root = process.cwd(), cache = path.join(root, 'node_modules/.cache/native-handoff-ingress');
const output = path.join(root, 'docs/evidence/3613-native-handoff-ingress/trust-correction');
const git = (...args) => execFileSync('git', ['--no-pager', ...args], { encoding: 'utf8' }).trim();
const sha = (bytes, algorithm = 'sha256') => crypto.createHash(algorithm).update(bytes).digest('hex');
const identity = (bytes) => ({ bytes: bytes.length, sha256: sha(bytes),
  blob: sha(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`), bytes]), 'sha1') });
assert.equal(git('rev-parse', 'HEAD'), source);
const initialBytes = fs.readFileSync(path.join(output, 'manifest.json'));
assert.equal(sha(initialBytes), '9f6ee132af6ffb5bde8c695c1875d0efe5be748be8c9fbcdddbc7124905fe00b');
fs.writeFileSync(path.join(output, 'initial-c1-manifest.json'), initialBytes);
const initial = JSON.parse(initialBytes);
const sourceInputs = ['src/main/services/annex-server.ts',
  'test/annex-v2/annex-native-handoff-admission.test.ts', 'docs/annex-native-handoff-admission.md'].map((file) => {
  const entry = { path: file, ...identity(fs.readFileSync(file)) };
  assert.equal(entry.blob, git('rev-parse', `${source}:${file}`));
  return entry;
});
assert.equal(sourceInputs[0].blob, git('rev-parse', `222737575bba9a36af9ac9c626b92d8cdf23a86f:${sourceInputs[0].path}`));
const typeLog = fs.readFileSync(path.join(cache, '28-legacy-fixture-types-original.log'), 'utf8');
assert.match(typeLog, /END lane-p2 rc=0/);
assert.doesNotMatch(typeLog, /error TS\d+/);
const compilerInputs = typeLog.split(/\r?\n/).filter((line) => path.isAbsolute(line) && fs.existsSync(line));
assert.equal(compilerInputs.length, 3957);
const configFile = path.join(cache, 'trust-correction-types.json');
const config = ts.readConfigFile(configFile, ts.sys.readFile);
assert.equal(config.error, undefined);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, cache);
assert.equal(parsed.errors.length, 0);
assert.equal(parsed.fileNames.length, 2466);
assert(parsed.fileNames.includes(path.join(root, sourceInputs[1].path)));
const fixtureLint = JSON.parse(fs.readFileSync(path.join(cache, '29-legacy-fixture-eslint-original.json'), 'utf8'));
assert.equal(fixtureLint.length, 1);
assert.equal(fixtureLint[0].errorCount, 0);
assert.equal(fixtureLint[0].warningCount, 0);
const correctedBytes = fs.readFileSync(path.join(output, 'corrected-historical-case-manifest.json'));
const corrected = JSON.parse(correctedBytes);
assert.equal(corrected.caseNameCorrection.bindings.length, 185);
const oldManifest = JSON.parse(fs.readFileSync('docs/evidence/3613-native-handoff-ingress/candidate/manifest.json'));
const restored = JSON.parse(correctedBytes);
delete restored.caseNameCorrection;
restored.final.cases.forEach((entry, index) => { entry.name = oldManifest.final.cases[index].name; });
restored.mutants.forEach((mutant, index) => {
  mutant.result.cases.forEach((entry, ordinal) => { entry.name = oldManifest.mutants[index].result.cases[ordinal].name; });
});
assert.deepEqual(restored, oldManifest);
const originalReview = fs.readFileSync(path.join(cache, '1172-source-review.md'));
assert.equal(identity(originalReview).blob, '767036e93c31c22fc670685eaadcea69f152a241');
for (const entry of initial.preservedTrees) assert.equal(git('rev-parse', `${source}:${entry.path}`), entry.tree);
for (const entry of initial.protectedFiles) assert.equal(git('rev-parse', `${source}:${entry.path}`), entry.blob);
assert.deepEqual(git('diff', '--name-only', oldProof, source, '--', 'src').split('\n'), ['src/main/services/annex-server.ts']);
assert.deepEqual(git('diff', '--name-only', oldProof, source, '--', 'test').split('\n'), [sourceInputs[1].path]);
const artifacts = [...initial.artifacts];
const preserve = (name, bytes) => {
  const stored = zlib.gzipSync(bytes, { level: 9, mtime: 0 });
  fs.writeFileSync(path.join(output, 'artifacts', `${name}.gz`), stored);
  artifacts.push({ name: `artifacts/${name}.gz`, raw: identity(bytes), stored: identity(stored) });
};
for (const name of [
  '26-trust-correction-collector-original.log', '27-legacy-pairing-positive-original.log',
  '27-legacy-pairing-positive-original.xml', '28-legacy-fixture-types-original.log',
  '29-legacy-fixture-eslint-original.log', '29-legacy-fixture-eslint-original.json',
  '30-c2-case-derivation-original.log',
]) preserve(name, fs.readFileSync(path.join(cache, name)));
preserve('final-correction-inputs-original.json', Buffer.from(`${JSON.stringify({
  roots: parsed.fileNames.map((file) => path.relative(root, file)),
  inputs: compilerInputs.map((file) => ({ path: path.relative(root, file), ...identity(fs.readFileSync(file)) })),
}, null, 2)}\n`));
preserve('combined-collector-original.cjs', fs.readFileSync(__filename));
const fixedCollector = fs.readFileSync(path.join(output, 'artifacts/collector-c2-corrected-original.cjs.gz'));
const manifest = {
  schemaVersion: 2, source, sourceTree: git('rev-parse', `${source}^{tree}`), sourceInputs,
  originalReviewedSource: initial.reviewed, originalProof: oldProof, genuineRed: initial.red,
  initialCanonicalSource: initial.source, initialCanonicalManifest: identity(initialBytes),
  review: { commit: '1172df1dde737d8ab3be33be44252103683e98b6', ...identity(originalReview),
    fullyRead: true, verdict: 'BLOCK: C1 original pairing capture and C2 derived names', exactSuccessorReviewPending: true },
  C1: { productionDelta: 'One canonical trustOf(peer)+kind line; no shared-policy/grant/control change.',
    red: initial.redResult, green22: initial.greenResult, legacy27: { pass: 1, fail: 0, skipped: 19 },
    oldPeerUndefinedPairingIdAdmits: true, benignRouteAliasLastSeenAdmit: true,
    pemFixtureBoundary: 'Synthetic PEM-only saved-record mismatch, not a valid re-pairing or executed incident.',
    noAggregateExactSuccessorRunClaim: true },
  C2: { correctedHistoricalManifest: identity(correctedBytes), correctedNames: 185,
    groups: { final: 110, queue: 31, postauth: 44 }, sameRawXml: true, oldManifestCollectorPreserved: true,
    onlyHistoricalCaseNamesChanged: true, noExecutionRerunForPackaging: true,
    correctedCollector: { stored: identity(fixedCollector), raw: identity(zlib.gunzipSync(fixedCollector)) } },
  types28: { diagnostics: 0, actualInputs: 3957, totalRoots: 2466, productionRoots: 2465,
    explicitChangedFixtures: [sourceInputs[1].path], afterExecutionInputIdentities: true },
  originalTypes13Clarification: { totalRoots: 2469, productionRoots: 2465, explicitFixtures: 4 },
  lint29: { files: 1, errors: 0, warnings: 0, unchangedServerBaselineReusedFrom24: initial.lint },
  preservedTrees: initial.preservedTrees, protectedFiles: initial.protectedFiles,
  limits: initial.limits.filter((line) => !line.includes('full immutable original source verdict pending')),
  artifacts,
};
fs.writeFileSync(path.join(output, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
for (const entry of artifacts) {
  const stored = fs.readFileSync(path.join(output, entry.name));
  assert.equal(sha(stored), entry.stored.sha256);
  assert.equal(sha(zlib.gunzipSync(stored)), entry.raw.sha256);
}
console.log(JSON.stringify({ source, tree: manifest.sourceTree, originalReview: manifest.review,
  C1: manifest.C1, C2: manifest.C2, types28: manifest.types28, archives: artifacts.length,
  manifest: identity(fs.readFileSync(path.join(output, 'manifest.json'))) }, null, 2));
