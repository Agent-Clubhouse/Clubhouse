const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const zlib = require('node:zlib');
const ts = require('typescript');
const source = '222737575bba9a36af9ac9c626b92d8cdf23a86f';
const reviewed = '940365ecde7ca2e9fb31abf48362a938445e1fe5';
const inherited = '0da6a65fa4973658efe9964a4971ad9bc85d1912';
const red = '7be137c573314d76e7f206dd319a8ac7c08f25c7';
const root = process.cwd();
const cache = path.join(root, 'node_modules/.cache/native-handoff-ingress');
const output = path.join(root, 'docs/evidence/3613-native-handoff-ingress/trust-correction');
const git = (...args) => execFileSync('git', ['--no-pager', ...args], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 });
const sha = (bytes, algorithm = 'sha256') => crypto.createHash(algorithm).update(bytes).digest('hex');
const identity = (bytes) => ({ bytes: bytes.length, sha256: sha(bytes),
  blob: sha(Buffer.concat([Buffer.from(`blob ${bytes.length}\0`), bytes]), 'sha1') });
assert.equal(git('rev-parse', 'HEAD').trim(), source);
assert.equal(git('status', '--porcelain').trim(), '');
const changes = git('diff', '--name-only', inherited, source).trim().split('\n');
assert.deepEqual(changes.filter((file) => file.startsWith('src/')), ['src/main/services/annex-server.ts']);
const sourceInputs = ['src/main/services/annex-server.ts', 'test/annex-v2/annex-native-handoff-admission.test.ts',
  'docs/annex-native-handoff-admission.md'].map((file) => {
  const entry = { path: file, ...identity(fs.readFileSync(file)) };
  assert.equal(entry.blob, git('rev-parse', `${source}:${file}`).trim());
  return entry;
});
const fixture = sourceInputs.find((file) => file.path.endsWith('.test.ts'));
assert.equal(fixture.blob, git('rev-parse', `${red}:${fixture.path}`).trim());
const configFile = path.join(cache, 'trust-correction-types.json');
const config = ts.readConfigFile(configFile, ts.sys.readFile);
assert.equal(config.error, undefined);
const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, cache);
assert.equal(parsed.errors.length, 0);
const rawTypes = fs.readFileSync(path.join(cache, '23-canonical-trust-types-original.log'), 'utf8');
assert.match(rawTypes, /END lane-p2 rc=0/);
assert.doesNotMatch(rawTypes, /error TS\d+/);
const actualInputs = rawTypes.split(/\r?\n/).filter((line) => path.isAbsolute(line) && fs.existsSync(line));
assert.equal(actualInputs.length, 3957);
assert.equal(new Set(actualInputs).size, actualInputs.length);
assert(actualInputs.includes(path.join(root, fixture.path)));
const inputIdentities = actualInputs.map((file) => ({ path: path.relative(root, file), ...identity(fs.readFileSync(file)) }));
const lint = JSON.parse(fs.readFileSync(path.join(cache, '24-canonical-trust-eslint-original.json'), 'utf8'));
const oldLint = JSON.parse(fs.readFileSync(path.join(cache, '12-eslint-original.json'), 'utf8'));
assert.equal(lint.length, 2);
assert.equal(lint.reduce((sum, file) => sum + file.errorCount, 0), 0);
assert.equal(lint.reduce((sum, file) => sum + file.warningCount, 0), 71);
const server = 'src/main/services/annex-server.ts';
const before = git('show', `${reviewed}:${server}`), after = fs.readFileSync(server, 'utf8');
const line = before.indexOf('    return peer && JSON.stringify([peer.publicKey');
assert(line >= 0);
const end = before.indexOf('\n', line), byteDelta = after.length - before.length;
assert.equal(byteDelta, -69);
const expectedWarnings = JSON.parse(JSON.stringify(oldLint.find((file) => file.filePath.endsWith(`/${server}`)).messages,
  (key, value) => key === 'range' ? value.map((offset) => offset > end ? offset + byteDelta : offset) : value));
assert.deepEqual(lint.find((file) => file.filePath.endsWith(`/${server}`)).messages, expectedWarnings);
const preservedTrees = [
  'test/fixtures', 'docs/evidence/3613-native-handoff-ingress/baseline',
  'docs/evidence/3613-native-handoff-ingress/candidate',
  'docs/evidence/3613-reverse-handoff', 'docs/evidence/3613-handoff-reverse-sync',
].map((directory) => {
  const tree = git('rev-parse', `${source}:${directory}`).trim();
  assert.equal(tree, git('rev-parse', `${inherited}:${directory}`).trim());
  return { path: directory, tree };
});
const protectedFiles = ['src/main/services/annex-peers.ts', 'src/main/services/annex-client.ts',
  'src/main/services/annex-authorizer.ts', 'src/main/services/annex-control.ts',
  'src/shared/annex-control-protocol.ts', 'src/main/services/handoff-service.ts',
  'src/main/services/handoff-coordinator.ts', 'src/main/services/handoff-host.ts',
  'docs/annex-route-contract-3611.md', 'package.json', 'package-lock.json', 'tsconfig.json', 'eslint.config.mjs'].map((file) => {
  const blob = git('rev-parse', `${source}:${file}`).trim();
  assert.equal(blob, git('rev-parse', `${inherited}:${file}`).trim());
  return { path: file, blob };
});
const artifacts = [];
const preserve = (name, bytes) => {
  const stored = zlib.gzipSync(bytes, { level: 9, mtime: 0 });
  fs.writeFileSync(path.join(output, 'artifacts', `${name}.gz`), stored);
  artifacts.push({ name: `artifacts/${name}.gz`, raw: identity(bytes), stored: identity(stored) });
};
for (const name of [
  '22-canonical-trust-green-original.log', '22-canonical-trust-green-original.xml',
  '23-canonical-trust-types-original.log', '24-canonical-trust-eslint-original.log',
  '24-canonical-trust-eslint-original.json', '25-warning-comparison-original.log',
]) preserve(name, fs.readFileSync(path.join(cache, name)));
preserve('trust-correction-types-original.json', fs.readFileSync(configFile));
preserve('trust-correction-inputs-original.json', Buffer.from(`${JSON.stringify({
  rootInputs: parsed.fileNames.map((file) => path.relative(root, file)), compilerInputs: inputIdentities,
}, null, 2)}\n`));
preserve('trust-correction-source-original.patch', Buffer.from(git('diff', reviewed, source, '--', server)));
preserve('trust-correction-collector-original.cjs', fs.readFileSync(__filename));
const manifest = {
  schemaVersion: 1, source, sourceTree: git('rev-parse', `${source}^{tree}`).trim(), reviewed, inherited, red,
  sourceInputs, trigger: 'Parent-conveyed independent pairingId/canonical-PEM source finding; full immutable original source verdict pending.',
  redResult: { pass: 4, fail: 2, skipped: 13 }, greenResult: { pass: 8, fail: 0, skipped: 11 },
  tests: ['pairingId-only', 'stored certificate PEM-only', 'unchanged/current', 'route-only', 'alias-only',
    'lastSeen-only', 'prior pairedAt-only', 'prior pin-mismatch'],
  types: { diagnostics: 0, actualInputs: actualInputs.length, roots: parsed.fileNames.length,
    changedFixtures: [fixture.path], inputIdentitiesAreAfterExecutionObservations: true },
  lint: { files: 2, errors: 0, warnings: 71, exact940WarningObjectsWithMappedSuggestionOffsetsEqual: true, byteDelta },
  preservedTrees, protectedFiles, artifacts,
  limits: [
    'Actual native router/control/TLS pins/real authorizer and real held history queue; synthetic metadata and Dispatcher/absent-runtime fixture inputs unchanged.',
    'Before release, original principal remains authorized and original manual receiver-opened link stays accepted; no kept-plan or debounce timing assumption.',
    'PEM-only mutation substitutes a valid fixture PEM while saved pin/public key remain fixed: a synthetic saved-record mismatch, not a valid re-pairing or executed incident.',
    'Four matched unchanged/current and benign route/alias/lastSeen controls; unrelated admitted transaction survives, incoming ownership releases.',
    'Reuse existing trustOf plus kind field identity; no change to shared sameTrust, grants, control, route or cache policy.',
    'Original940/0da and all earlier source/proof/failures remain immutable; no unaffected35/lower/sync rerun or aggregate41 exact-head claim.',
    'Only source-derived correction checks, source-bound types6 and scoped lint4; no PR/CI/install/E2E/release/full-handoff acceptance.',
    'Metadata comparison25 failure incorrectly demanded unchanged suggestion byte offsets; original tool output preserved, corrected mapping verified without rerunning checks.',
    'Exact successor source/proof review remains pending; coordinate further substantive findings before PR.',
  ],
};
fs.writeFileSync(path.join(output, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ source, tree: manifest.sourceTree, types: manifest.types, lint: manifest.lint,
  protectedTrees: preservedTrees.length, protectedFiles: protectedFiles.length, artifacts: artifacts.length,
  manifest: identity(fs.readFileSync(path.join(output, 'manifest.json'))) }, null, 2));
