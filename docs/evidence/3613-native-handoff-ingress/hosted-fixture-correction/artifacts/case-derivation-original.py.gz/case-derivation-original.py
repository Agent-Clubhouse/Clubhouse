import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path("node_modules/.cache/native-handoff-ingress")
rows = []
for run in ("45-fixture-red-original.xml", "46-fixture-green-original.xml"):
    raw = (root / run).read_bytes()
    tree = ET.fromstring(raw)
    cases = []
    for case in tree.iter("testcase"):
        failed = case.find("failure")
        error = case.find("error")
        skipped = case.find("skipped")
        status = "failure" if failed is not None else "error" if error is not None else "skipped" if skipped is not None else "passed"
        item = {"name": case.get("name"), "classname": case.get("classname"), "status": status}
        if failed is not None:
            item["failure"] = {"attributes": failed.attrib, "text": failed.text}
        cases.append(item)
    counts = {status: sum(item["status"] == status for item in cases) for status in ("passed", "failure", "error", "skipped")}
    rows.append({"artifact": run, "rawBytes": len(raw), "rawSha256": hashlib.sha256(raw).hexdigest(), "rootAttributes": tree.attrib, "counts": counts, "cases": cases})
assert rows[0]["counts"] == {"passed": 0, "failure": 2, "error": 0, "skipped": 680}
assert rows[1]["counts"] == {"passed": 5, "failure": 0, "error": 0, "skipped": 677}
failed_names = {item["name"] for item in rows[0]["cases"] if item["status"] == "failure"}
passed_names = {item["name"] for item in rows[1]["cases"] if item["status"] == "passed"}
assert failed_names <= passed_names
(root / "52-fixture-cases-derived.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps({"red": rows[0]["counts"], "green": rows[1]["counts"], "matchedRedFailuresNowPass": sorted(failed_names)}))
