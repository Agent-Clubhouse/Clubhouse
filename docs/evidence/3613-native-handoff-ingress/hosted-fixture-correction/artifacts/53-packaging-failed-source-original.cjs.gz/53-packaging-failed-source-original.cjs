const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const source = '60ed5f77f76029681160f298bfe789fb1d884512';
const baseline = '206a88dcc93ecd7d2f5009d533894dd77e36e2ed';
const cache = 'node_modules/.cache/native-handoff-ingress';
const destination = 'docs/evidence/3613-native-handoff-ingress/hosted-fixture-correction';
const git = (...args) => execFileSync('git', args, { encoding:'utf8' }).trim();
assert.equal(git('rev-parse', 'HEAD'), source);
assert.equal(git('diff', '--name-only'), '');
assert.equal(git('diff', '--name-only', '--cached'), '');
assert.equal(git('ls-remote', 'origin', 'refs/heads/lane-3613-p2-routes/handoff-next-path').split(/\s+/)[0], baseline);
const metadata = JSON.parse(fs.readFileSync(`${cache}/51-fixture-correction-metadata.json`));
const cases = JSON.parse(fs.readFileSync(`${cache}/52-fixture-cases-derived.json`));
const artifacts = [];
fs.mkdirSync(`${destination}/artifacts`, { recursive:true });
const add = (name, raw) => {
  const stored = zlib.gzipSync(raw);
  assert.deepEqual(zlib.gunzipSync(stored), raw);
  const blob = crypto.createHash('sha1').update(Buffer.from(`blob ${stored.length}\0`)).update(stored).digest('hex');
  const receipt = {
    name:`artifacts/${name}.gz`,rawBytes:raw.length,storedBytes:stored.length,
    rawSha256:crypto.createHash('sha256').update(raw).digest('hex'),
    storedSha256:crypto.createHash('sha256').update(stored).digest('hex'),blob,
  };
  fs.writeFileSync(path.join(destination, receipt.name), stored);
  artifacts.push(receipt);
};
for (const name of fs.readdirSync(cache).filter(name => /^(?:45-|46-|47-|48-|49-|50-|51-|52-)/.test(name)).sort()) {
  const file = path.join(cache, name);
  if (fs.statSync(file).isFile()) add(name, fs.readFileSync(file));
}
for (const [name, file] of [
  ['changed-fixture-types-original.json','hosted-correction-types.json'],
  ['baseline-fixture-types-original.json','hosted-types-baseline-work/hosted-correction-types.json'],
  ['metadata-collector-original.cjs','collect-fixture-correction.cjs'],
  ['case-derivation-original.py','derive-fixture-correction.py'],
  ['packaging-original.cjs','package-fixture-correction.cjs'],
]) add(name, fs.readFileSync(`${cache}/${file}`));
const preservedTrees = JSON.parse(fs.readFileSync('docs/evidence/3613-native-handoff-ingress/trust-correction/manifest.json')).preservedTrees.map(tree => tree.path);
const identityPaths = [...new Set([
  'src/main/services/annex-server.ts','src/main/services/handoff-host.ts','src/main/services/handoff-coordinator.ts','src/main/services/handoff-service.ts',
  'src/main/services/annex-peers.ts','src/main/services/annex-client.ts','src/main/services/annex-authorizer.ts',
  'src/main/services/annex-control.ts','src/main/services/annex-control-protocol.ts','src/main/services/annex-control-bulk.ts',
  'docs/annex-native-handoff-admission.md','test/annex-v2/reverse-desktop-fixture.ts',
  'test/fixtures','docs/evidence/3613-native-handoff-ingress/baseline','docs/evidence/3613-native-handoff-ingress/candidate',
  'docs/evidence/3613-native-handoff-ingress/trust-correction',
  ...preservedTrees,
])];
const identities = identityPaths.map(file => {
  const original = git('rev-parse', `${baseline}:${file}`);
  const current = git('rev-parse', `${source}:${file}`);
  assert.equal(current, original);
  return {file,original,current,unchanged:true};
});
const files = ['src/main/services/annex-server.test.ts','test/annex-v2/annex-native-handoff-admission.test.ts'].map(file => ({
  file, original:git('rev-parse',`${baseline}:${file}`), red:git('rev-parse',`${metadata.redSource}:${file}`), current:git('rev-parse',`${source}:${file}`),
}));
assert.equal(files[0].original, files[0].red);
assert.equal(metadata.typing.wholeGraphPass, false);
assert.equal(metadata.typing.newDiagnostics, 0);
const manifest = {
  at:new Date().toISOString(),source,sourceTree:git('rev-parse',`${source}^{tree}`),baseline,redSource:metadata.redSource,
  previousReview:'7acf3f1adb93b71f21986e9b2fead93c78e1a837',hostedFailureProof:'13703fdf4270684c83c1c24e144f6ed3c73d6e4c',
  previousHostedRun:{id:45046385831,attempt:1,event:'pull_request',head:baseline,conclusion:'failure',counts:{success:30,skipped:4,failure:3}},
  files,identities,artifacts,
  executions:cases.map(run => ({artifact:run.artifact,counts:run.counts,selected:run.cases.filter(item=>item.status!=='skipped'),rawSha256:run.rawSha256})),
  typing:{...metadata.typing,currentInputs:metadata.currentGraph.count,baselineInputs:metadata.baselineGraph.count,roots:metadata.currentGraph.roots.length,productionRoots:2465,explicitCompleteFixtures:2,orderedInputGraphsMatched:true,optionsMatchedAfterCheckoutPathNormalization:true},
  lint:metadata.lint,
  limitations:'Fixture-only source; exact delta review pending. No established hosted reconnect cause/rejection code, full-graph types pass, broad suite or aggregate successor result. Other7acf/1172 evidence reused by unchanged identity. Real native grant/preparation/content/apply/wake/two-host/full-duplex acceptance remains deferred.',
};
fs.writeFileSync(`${destination}/manifest.json`,JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({source,artifacts:artifacts.length,typing:manifest.typing,lint:manifest.lint,changedFiles:files.map(file=>file.file)}));
