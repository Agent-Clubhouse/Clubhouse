const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const ts = require('typescript');
const { execFileSync } = require('node:child_process');
const root = process.cwd();
const cache = path.join(root, 'node_modules/.cache/native-handoff-ingress');
const baselineRoot = path.join(cache, 'hosted-types-baseline-work');
const source = '60ed5f77f76029681160f298bfe789fb1d884512';
const baseline = '206a88dcc93ecd7d2f5009d533894dd77e36e2ed';
const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).trim();
const read = name => fs.readFileSync(path.join(cache, name), 'utf8');
assert.equal(git('rev-parse', 'HEAD'), source);
assert.equal(git('status', '--porcelain'), '');
assert.equal(git('ls-remote', 'origin', 'refs/heads/lane-3613-p2-routes/handoff-next-path').split(/\s+/)[0], baseline);
const oldFixture = execFileSync('git', ['show', `${baseline}:src/main/services/annex-server.test.ts`], { encoding: 'utf8' });
const newFixture = fs.readFileSync('src/main/services/annex-server.test.ts', 'utf8');
const addedLine = "  trustOf: (await importOriginal<typeof import('./annex-peers')>()).trustOf,\n";
const insertion = newFixture.indexOf(addedLine);
assert(insertion >= 0);
assert.equal(newFixture.slice(0, insertion) + newFixture.slice(insertion + addedLine.length), oldFixture);
const insertedAtLine = newFixture.slice(0, insertion).split('\n').length;
const currentTypes = read('47-fixture-types-original.log');
const baselineTypes = read('49-original-fixture-types-original.log');
const diagnosticBody = text => {
  const start = text.search(/^.*\(\d+,\d+\): error TS/m);
  assert(start >= 0);
  const absoluteInput = text.slice(start).search(/^\//m);
  assert(absoluteInput >= 0);
  return text.slice(start, start + absoluteInput).trim();
};
const mappedTypes = diagnosticBody(currentTypes).replace(/src\/main\/services\/annex-server\.test\.ts\((\d+),/g, (all, line) =>
  `src/main/services/annex-server.test.ts(${Number(line) > insertedAtLine ? Number(line) - 1 : line},`);
assert.equal(mappedTypes, diagnosticBody(baselineTypes));
const diagnostics = currentTypes.match(/^.*\(\d+,\d+\): error TS\d+:.*$/gm);
assert.equal(diagnostics.length, 166);
assert(diagnostics.every(line => line.startsWith('src/main/services/annex-server.test.ts(')));
const currentLint = JSON.parse(read('48-fixture-eslint-original.json'));
const baselineLint = JSON.parse(read('50-original-fixture-eslint-original.json'))[0];
const legacyLint = currentLint.find(file => file.filePath.endsWith('/src/main/services/annex-server.test.ts'));
const nativeLint = currentLint.find(file => file.filePath.endsWith('/test/annex-v2/annex-native-handoff-admission.test.ts'));
assert.equal(legacyLint.errorCount, 0); assert.equal(nativeLint.errorCount, 0);
assert.equal(legacyLint.warningCount, 247); assert.equal(nativeLint.warningCount, 0);
const mapObject = input => {
  if (Array.isArray(input)) return input.map(mapObject);
  if (!input || typeof input !== 'object') return input;
  const out = {};
  for (const [key, value] of Object.entries(input)) {
    if ((key === 'line' || key === 'endLine') && typeof value === 'number') out[key] = value > insertedAtLine ? value - 1 : value;
    else if (key === 'range' && Array.isArray(value)) out[key] = value.map(offset => offset >= insertion + addedLine.length ? offset - addedLine.length : offset);
    else out[key] = mapObject(value);
  }
  return out;
};
assert.deepEqual(legacyLint.messages.map(mapObject), baselineLint.messages);
const track = new Set(git('ls-files').split('\n'));
const graph = (name, configPath, ownRoot) => {
  const graphSource = ownRoot === root ? source : baseline;
  const blobs = new Map(git('ls-tree', '-r', graphSource).split('\n').map(line => {
    const [metadata, file] = line.split('\t');
    return [file, metadata.split(' ')[2]];
  }));
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  assert(!config.error);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, path.dirname(configPath));
  assert.equal(parsed.errors.length, 0);
  const paths = read(name).split('\n').filter(line => path.isAbsolute(line) && fs.existsSync(line));
  const inputs = paths.map(absolute => {
    const relative = absolute.startsWith(ownRoot + path.sep) ? path.relative(ownRoot, absolute) : path.relative(root, absolute);
    const bytes = fs.readFileSync(absolute);
    const blob = crypto.createHash('sha1').update(Buffer.from(`blob ${bytes.length}\0`)).update(bytes).digest('hex');
    const tracked = track.has(relative);
    if (tracked) assert.equal(blob, blobs.get(relative));
    return { relative, tracked, bytes:bytes.length, sha256:crypto.createHash('sha256').update(bytes).digest('hex'), blob };
  });
  return {
    log:name, source:graphSource,
    config:config.config, options:parsed.options,
    roots:parsed.fileNames.map(file => path.relative(ownRoot, file)),
    count:inputs.length, tracked:inputs.filter(file => file.tracked).length, inputs,
    observation:'Input-content hashes collected after execution; no atomic read/executable/host seal.',
  };
};
const currentGraph = graph('47-fixture-types-original.log', path.join(cache, 'hosted-correction-types.json'), root);
const baselineGraph = graph('49-original-fixture-types-original.log', path.join(baselineRoot, 'hosted-correction-types.json'), baselineRoot);
assert.deepEqual(currentGraph.roots, baselineGraph.roots);
const normalizedOptions = (options, ownRoot) => JSON.parse(JSON.stringify(options).replaceAll(ownRoot, '<checkout>'));
assert.deepEqual(normalizedOptions(currentGraph.options, root), normalizedOptions(baselineGraph.options, baselineRoot));
assert.deepEqual(currentGraph.inputs.map(file => file.relative), baselineGraph.inputs.map(file => file.relative));
assert.equal(currentGraph.roots.length, 2467);
const changed = git('diff', '--name-only', baseline, source).split('\n');
assert.deepEqual(changed, ['src/main/services/annex-server.test.ts', 'test/annex-v2/annex-native-handoff-admission.test.ts']);
const result = {
  source, sourceTree:git('rev-parse', 'HEAD^{tree}'), baseline,
  redSource:read('45-red-source-original.txt').trim().split('\n')[0],
  changedFiles:changed, productionChanged:false, currentGraph, baselineGraph,
  typing:{currentExit:2,baselineExit:2,diagnostics:166,exactMappedBaseline:true,newDiagnostics:0,wholeGraphPass:false},
  lint:{currentErrors:0,legacyWarnings:247,nativeWarnings:0,exactMappedBaseline:true,insertedAtLine,insertedUtf16Length:addedLine.length},
  limitations:'Old explicit legacy test typing remains FAIL with166 unchanged diagnostics. No unrelated cleanup, weakened config, aggregate successor pass or established hosted reconnect-cause claim.',
};
fs.writeFileSync(path.join(cache, '51-fixture-correction-metadata.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({source,currentInputs:currentGraph.count,baselineInputs:baselineGraph.count,roots:currentGraph.roots.length,typing:result.typing,lint:result.lint}));
